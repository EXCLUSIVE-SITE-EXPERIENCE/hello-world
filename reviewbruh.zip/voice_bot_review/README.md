# Verigram voice-bot improvement review

## Status

| Work item | Result |
|---|---|
| Architecture guide/workbook | Reviewed |
| Active NLU/scenarios | 226 model labels; 170 scenarios audited |
| November calls | 150,837 calls and 635,683 client turns parsed locally |
| Detailed call sample | 50 calls reviewed and source-validated |
| YAML verification | Structural audit plus independent code-aware verification |
| OpenRouter research | Decisions, extraction, embeddings, rerankers, LLMs, pricing, privacy, and evaluation plan |
| Hosted model comparison | **Complete: 150/150 successful requests, 0 errors, $0.039107 measured cost** |
| Production changes | None |

No raw call was sent to an external service. Derived sample transcripts redact long digit sequences. The 50 qualitative annotation sets are AI-assisted, not human-adjudicated gold labels.

## Main conclusions

1. **System One / Decisions models can materially help.** They are well suited to per-turn intent adjudication, per-call failure tags, outcome classification, UX scoring, and uncertainty-based triage. They do not generate explanations or patches; use a generative LLM and humans for that.
2. **The bot's problems are not only NLU.** In the enriched 50-call sample, 25 calls had an NLU miss/wrong intent, 24 had a scenario/state issue, and 17 had both. Operator friction occurred in 30 and prompt UX issues in 23. These counts are not production rates.
3. **Fix deterministic P0 defects in parallel with NLU work.** Pre-service surveys, invalid rating acceptance, context-losing exits/interrupts, and operator-gate loops do not require a better model to diagnose.
4. **Unknowns are systemic.** November has 29.72% unknown client turns, stable around 28.10–30.53% per day. `00_06_reask_before_operator__second_ask` alone has 37,803 turns with 58.0% unknown.
5. **Scenario coverage is often too generic.** Thirty-five files have an entry-intent self-repeat pattern; 53 scenarios have only 1–3 states. Expand only where real follow-up failures justify it, not merely to make trees larger.
6. **Production source parity matters.** The supplied `MainIntentManager` omits 21 second/later OR alternatives from cross-scenario interruption and unwinds nested scenario frames. Verify both behaviors in actual v2.2.123 before remediation.
7. **The live Decisions pilot is complementary, not a single-model verdict.** Jev led cheap outcome triage (0.880 agreement), Clef led wrong-intent and operator tags, and Gemini led selected logic/calibration measures. Human review remains necessary for outcome relevance, silence severity, and model disagreements.

## Read these reports

- **[CALL_REVIEW.md](CALL_REVIEW.md)** — full-month metrics, all 50-call findings, confusion pairs, coverage backlog, and implementation order.
- **[YAML_REVIEW.md](YAML_REVIEW.md)** — structural audit, correct resume semantics, OR-registry risk, stack-unwind risk, self-repeats, and release gates.
- **[OPENROUTER_REVIEW.md](OPENROUTER_REVIEW.md)** — model roles/limitations/pricing, embeddings/reranking, generative-LLM candidates, architecture, evaluation, privacy, and sources.
- **[DECISION_PILOT_RESULTS.md](DECISION_PILOT_RESULTS.md)** — live 50×3 results, costs, latency, per-tag metrics, threshold sweep, disagreement cases, and recommended next pilot.

## Highest-priority engineering backlog

### P0

1. Gate surveys on completed service; require valid 1–5 input before thanks/goodbye; cover all 41 cloned survey states.
2. Replace context-losing default exits and separate `unable` from `wait`; add `request_identification` with original-goal resume.
3. Check v2.2.123 `MainIntentManager`: all 157 main alternatives must be registered, not only the first in each OR condition.
4. Simplify repeated explicit operator transfer; retain a reason when voluntarily supplied but do not require one.

### P1

1. Test and repair nested main-interrupt continuation with stack assertions.
2. Split transfer direction/status: how-to-send, normal timing, outgoing nonreceipt, incoming nonreceipt, refund timing, and no-bank/no-receipt.
3. Expand high-volume self-repeat states with concise repeat, expected follow-ups, done/thanks, and operator escape.
4. Make sustained-language detection govern every service/fallback/survey/operator prompt.
5. Build RU/KZ/code-mixed hard-negative regression data and test the existing LaBSE model in deployment/argmax mode.
6. Add explicit logging for NLU top-k/probabilities, state candidates, transition/fallback reason, ASR confidence, and final disposition.

### P2

1. Add reviewed coverage: greetings, missed bank call, app launch failure, flash-token/EDS, other-bank card at Halyk ATM, cannot-hear, and compound card/ATM reasons.
2. Resolve `other_bank` using `other_bank_general` if validated; review duplicate/small-talk labels without independently deleting config indices.
3. Improve long prompts, grammar, current-step repetition, and call-outcome observability.

## Recommended model workflow

```text
Local deterministic profiling
  -> human-reviewed discovery sample
  -> embeddings for unknown-turn clustering and intent/example retrieval
  -> reranker for top 3–8 candidates + other/unclear
  -> Jev / Gemini Decision 1 / Clef typed judgments with probabilities
  -> generative LLM only for uncertain/high-severity cases
  -> human adjudication
  -> NLU positives/hard negatives and reviewed YAML
  -> static checks + historical replay + shadow rollout
```

Start with Jev and Clef; include Gemini now that hosted use is authorized. Measure RU/KZ/code-mixed accuracy, abstention, failure-tag performance, latency, and actual cost. Do not select a model from generic benchmarks alone.

## Hosted comparison: results and rerun commands

The live comparison is complete: **50 calls × 3 models, 150/150 successful responses, $0.039107 total cost**. See `DECISION_PILOT_RESULTS.md` and the decision artifacts below. The API key was used only in the process environment and was not saved to the review files.

From `D:\Halyk\Decode\voice_bot_review`, with `OPENROUTER_API_KEY` set in the process environment:

### 1. Three-call smoke test (for future schema/model changes)

```powershell
python .\openrouter_decision_pilot.py `
  --input .\analysis\call_sample_50.json `
  --questions .\decision_questions.json `
  --models typesafe/jev-1.14 google/gemini-decision-1 cloudflare/clef `
  --limit 3 --workers 3 --allow-non-zdr --send-data
```

`--allow-non-zdr` relaxes strict zero-retention routing for Gemini but keeps `data_collection: deny` and disables fallback providers. Omit it for strict-ZDR-only runs; incompatible models should fail rather than reroute.

### 2. Full 50-call comparison (resumable)

```powershell
python .\openrouter_decision_pilot.py `
  --input .\analysis\call_sample_50.json `
  --questions .\decision_questions.json `
  --models typesafe/jev-1.14 google/gemini-decision-1 cloudflare/clef `
  --limit 0 --workers 4 --allow-non-zdr --send-data
```

Results append to `analysis/decision_results.jsonl`; successful model/sample pairs are skipped on rerun. Raw probabilities and `usage.cost` are preserved.

### 3. Compare against the AI-assisted annotations

```powershell
python .\compare_decision_results.py `
  --results .\analysis\decision_results.jsonl `
  --annotations .\analysis\call_annotations_50.json `
  --output-prefix .\analysis\decision_comparison
```

This produces `decision_comparison.md` and `.json`. It measures **agreement for triage, not true accuracy**. Human-label disagreements before model selection or threshold tuning.

```powershell
python .\summarize_decision_pilot.py `
  --results .\analysis\decision_results.jsonl `
  --annotations .\analysis\call_annotations_50.json `
  --sample .\analysis\call_sample_50.json `
  --output-dir .\analysis --queue-size 20
```

This adds the threshold sweep, full 50-call matrix, and prioritized human-review queue.

## Reproduce local analyses

```powershell
cd D:\Halyk\Decode\voice_bot_review

python .\analyze_calls.py `
  --calls-dir 'D:\Halyk\Verigram\data\calls\november_2026' `
  --output-dir '.\analysis' --sample-size 50

python .\audit_scenarios.py `
  --scenarios-dir 'D:\Halyk\Verigram\data\intents_and_scenarios_in_use\scenarios_in_use' `
  --intent-config 'D:\Halyk\Verigram\data\intents_and_scenarios_in_use\intent_configs_in_use\intent_config_v23.json' `
  --output-dir '.\analysis'

python .\combine_annotations.py
python -m py_compile .\analyze_calls.py .\audit_scenarios.py .\combine_annotations.py .\openrouter_decision_pilot.py .\compare_decision_results.py .\summarize_decision_pilot.py
```

## Important artifacts

| File | Purpose |
|---|---|
| `analysis/november_aggregate.json` | Full-month intent, scenario, state, daily, and feature statistics |
| `analysis/call_sample_50.{json,md}` | Redacted deterministic sample |
| `analysis/call_annotations_50.json` | Per-call goals, outcomes, tags, evidence, and fixes |
| `analysis/call_review_summary.json` | Validated 50-call counts |
| `analysis/yaml_audit_summary.json` | Structural counts and descriptive thin/repeat lists |
| `analysis/yaml_audit_issues.json` | Self-repeat and label findings |
| `analysis/yaml_scenario_stats.{json,csv}` | Per-scenario states/transitions/intents/coverage |
| `analysis/yaml_audit_review.md` | Independent verification and detailed source references |
| `decision_questions.json` | Initial call-level Decisions schema |
| `analysis/pilot_payload_preview.json` | Dry-run payload; no inference required |
| `analysis/decision_results.jsonl` | All 150 live typed model responses and usage/cost data |
| `analysis/decision_comparison.{md,json}` | Headline, per-tag, and latency metrics |
| `analysis/decision_threshold_sweep.csv` | Exploratory model/question/threshold metrics |
| `analysis/decision_call_matrix.md` | Side-by-side outcomes and UX scores for all 50 calls |
| `analysis/decision_review_queue.json` | Prioritized calls for human adjudication |

## Inputs needed next

You indicated all of these can be provided. Please supply their paths when ready:

1. **Audio + ASR details:** problematic-call audio, ASR confidence/n-best, and turn timings.
2. **NLU + engine logs:** top-k probabilities, state candidates, production `INTENT_CONFIDENCE_THRESHOLD`, model/checkpoint hash, selected transitions/fallback reasons, and exact scenario versions.
3. **Training + test data:** full `batch_wave3b.csv`, baseline final test set, group IDs, and training configuration.
4. **Call outcomes:** post-transfer disposition, agent notes, task resolution, and valid customer scores.
5. **Actual v2.2.123 source:** especially `MainIntentManager`, scenario-stack interruption/resumption, NLU candidate filtering, and repeat injection.

The next blockers are evidence quality rather than API access: human-adjudicate the disagreement queue, supply audio/logs/training data, verify production source parity, and only then tune thresholds or retrain. Local P0 fixes and scenario replay tests can proceed in parallel.
