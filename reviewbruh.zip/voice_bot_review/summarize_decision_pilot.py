#!/usr/bin/env python3
"""Generate threshold sweeps, a 50-call matrix, and a human-review queue."""

from __future__ import annotations

import argparse
import collections
import csv
import json
from pathlib import Path

from compare_decision_results import OUTCOME_MAP, SEVERITY_SCORE, TAG_MAP, prf

MODEL_ORDER = ["typesafe/jev-1.14", "google/gemini-decision-1", "cloudflare/clef"]
THRESHOLDS = [0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=Path, default=Path("analysis/decision_results.jsonl"))
    parser.add_argument("--annotations", type=Path, default=Path("analysis/call_annotations_50.json"))
    parser.add_argument("--sample", type=Path, default=Path("analysis/call_sample_50.json"))
    parser.add_argument("--output-dir", type=Path, default=Path("analysis"))
    parser.add_argument("--queue-size", type=int, default=20)
    args = parser.parse_args()

    annotations = {
        int(row["sample_id"]): row
        for row in json.loads(args.annotations.read_text(encoding="utf-8"))
    }
    sample = {
        int(row["sample_id"]): row
        for row in json.loads(args.sample.read_text(encoding="utf-8"))
    }
    rows = [json.loads(line) for line in args.results.read_text(encoding="utf-8").splitlines() if line.strip()]
    by_sample: dict[int, dict] = collections.defaultdict(dict)
    for row in rows:
        if row.get("ok"):
            by_sample[int(row["sample_id"])][row["model"]] = row
    models = [model for model in MODEL_ORDER if any(model in value for value in by_sample.values())]

    # Threshold-independent Brier score plus thresholded metrics for each Noul.
    sweep = []
    for model in models:
        for question, truth_tags in TAG_MAP.items():
            brier_values = []
            per_threshold = {threshold: [0, 0, 0] for threshold in THRESHOLDS}
            for sample_id, model_rows in by_sample.items():
                if model not in model_rows:
                    continue
                answer = model_rows[model]["response"].get("answers", {}).get(question, {})
                if answer.get("type") != "noul" or not isinstance(answer.get("noul"), (int, float)):
                    continue
                actual = bool(truth_tags & set(annotations[sample_id]["failure_tags"]))
                probability = float(answer["noul"])
                brier_values.append((probability - float(actual)) ** 2)
                for threshold in THRESHOLDS:
                    predicted = probability >= threshold
                    if predicted and actual:
                        per_threshold[threshold][0] += 1
                    elif predicted and not actual:
                        per_threshold[threshold][1] += 1
                    elif not predicted and actual:
                        per_threshold[threshold][2] += 1
            for threshold, (tp, fp, fn) in per_threshold.items():
                sweep.append({
                    "model": model,
                    "question": question,
                    "threshold": threshold,
                    **prf(tp, fp, fn),
                    "brier": sum(brier_values) / len(brier_values) if brier_values else None,
                    "support": len(brier_values),
                })

    args.output_dir.mkdir(parents=True, exist_ok=True)
    with (args.output_dir / "decision_threshold_sweep.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        fields = ["model", "question", "threshold", "tp", "fp", "fn", "precision", "recall", "f1", "brier", "support"]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(sweep)

    best = []
    for model in models:
        for question in TAG_MAP:
            candidates = [row for row in sweep if row["model"] == model and row["question"] == question and row["f1"] is not None]
            if candidates:
                best.append(max(candidates, key=lambda row: (row["f1"], row["precision"] or 0, -row["threshold"])))
    (args.output_dir / "decision_threshold_best_f1_in_sample.json").write_text(
        json.dumps(best, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    matrix = [
        "# Fifty-call model matrix",
        "",
        "Outcomes and 0–3 UX severity scores. `Ann.` is the AI-assisted annotation, not human gold.",
        "",
        "| Sample | Call | Ann. outcome | Jev outcome / UX | Gemini outcome / UX | Clef outcome / UX |",
        "|---:|---:|---|---|---|---|",
    ]
    queue = []
    for sample_id in sorted(by_sample):
        annotation = annotations[sample_id]
        model_rows = by_sample[sample_id]
        cells = []
        outcomes = {}
        ux_scores = {}
        for model in models:
            answers = model_rows[model]["response"]["answers"]
            outcome = answers["outcome"].get("choice", "refusal")
            ux = float(answers["ux_severity"]["score"])
            outcomes[model] = outcome
            ux_scores[model] = ux
            cells.append(f"{outcome} / {ux:.2f}")
        matrix.append(
            f"| {sample_id} | {sample[sample_id]['call_index']} | {annotation['outcome']} | "
            + " | ".join(cells)
            + " |"
        )

        reasons = []
        score = 0
        if annotation["severity"] == "high":
            reasons.append("AI-assisted annotation marks high severity")
            score += 3
        elif annotation["severity"] == "medium":
            score += 1
        if len(set(outcomes.values())) > 1:
            reasons.append("Models disagree on outcome")
            score += 2
        if ux_scores and max(ux_scores.values()) - min(ux_scores.values()) >= 1.5:
            reasons.append("UX severity range is at least 1.5")
            score += 2
        tag_disagreements = []
        for question in TAG_MAP:
            probabilities = [
                float(model_rows[model]["response"]["answers"][question]["noul"])
                for model in models
                if model_rows[model]["response"]["answers"].get(question, {}).get("type") == "noul"
            ]
            if probabilities and max(probabilities) >= 0.8 and min(probabilities) <= 0.3:
                tag_disagreements.append(question)
        if tag_disagreements:
            reasons.append("Large model disagreement on: " + ", ".join(tag_disagreements))
            score += min(3, len(tag_disagreements))
        if annotation["severity"] == "none" and ux_scores and max(ux_scores.values()) >= 2:
            reasons.append("Possible model false positive on an annotation-clean call")
            score += 2
        if annotation["severity"] in {"high", "medium"} and ux_scores and max(ux_scores.values()) < 1:
            reasons.append("Possible model miss on an annotation-problem call")
            score += 2
        if score > 0:
            queue.append({
                "sample_id": sample_id,
                "call_index": sample[sample_id]["call_index"],
                "call_id": sample[sample_id]["call_id"],
                "priority_score": score,
                "reasons": reasons,
                "annotation": annotation,
                "model_answers": {
                    model: model_rows[model]["response"]["answers"] for model in models
                },
            })
    queue.sort(key=lambda row: (-row["priority_score"], row["sample_id"]))
    queue = queue[: args.queue_size]
    (args.output_dir / "decision_call_matrix.md").write_text("\n".join(matrix) + "\n", encoding="utf-8")
    (args.output_dir / "decision_review_queue.json").write_text(
        json.dumps(queue, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    best_lines = [
        "# Best in-sample F1 thresholds",
        "",
        "**Exploratory only: thresholds were selected and measured on the same 50 AI-annotated calls. Re-fit on human training data and validate on a separate held-out set.**",
        "",
        "| Model | Question | Threshold | Precision | Recall | F1 | Brier |",
        "|---|---|---:|---:|---:|---:|---:|",
    ]
    for row in best:
        best_lines.append(
            f"| `{row['model']}` | `{row['question']}` | {row['threshold']} | "
            f"{row['precision']:.3f} | {row['recall']:.3f} | {row['f1']:.3f} | {row['brier']:.3f} |"
        )
    (args.output_dir / "decision_threshold_best_f1_in_sample.md").write_text(
        "\n".join(best_lines) + "\n", encoding="utf-8"
    )
    print(json.dumps({
        "matrix_rows": len(by_sample),
        "sweep_rows": len(sweep),
        "review_queue": [
            {"sample_id": row["sample_id"], "priority_score": row["priority_score"], "reasons": row["reasons"]}
            for row in queue
        ],
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
