# Live OpenRouter Decisions pilot: 50 calls × 3 models

## Execution

- Models: `typesafe/jev-1.14`, `google/gemini-decision-1`, `cloudflare/clef`.
- Input: the same redacted 50-call discovery sample used for the local AI-assisted annotations.
- Requests: **150 total, 150 successful, 0 errors**.
- Input tokens: **346,024**.
- Total measured cost: **$0.039107124**.
- Outputs: typed outcome, UX severity, review priority, and nine independent failure-tag probabilities per call.

**Interpretation limit:** agreement below is with AI-assisted annotations on an enriched sample, not human-gold production accuracy. Model disagreements can be correct, and threshold sweeps are exploratory because they use the same 50 calls for selection and measurement.

## Headline results

| Model | Successful | Cost | Outcome agreement | UX severity MAE ↓ | Mean latency | p95 latency |
|---|---:|---:|---:|---:|---:|---:|
| `typesafe/jev-1.14` | 50/50 | $0.005001 | **0.880** | **0.578** | **1.066s** | **1.430s** |
| `google/gemini-decision-1` | 50/50 | $0.010293 | 0.800 | 0.719 | 1.226s | 1.956s |
| `cloudflare/clef` | 50/50 | $0.023814 | 0.860 | 0.601 | 1.447s | 2.178s |

At this sample's lengths and question set, approximate cost per 1,000 calls is **$0.100 Jev**, **$0.206 Gemini**, and **$0.476 Clef**. Naively scaling to all 150,837 November calls gives roughly **$15 / $31 / $72 per model**, before retries or new features. This is an estimate, not a budget quote.

Pairwise outcome agreement:

- Jev ↔ Clef: **0.920**
- Jev ↔ Gemini: **0.840**
- Clef ↔ Gemini: **0.820**

Jev is therefore the cheapest broad triage option in this run, but its secondary tags need tighter thresholds. Clef and Jev agree strongly on outcome; Gemini supplies useful independent judgments.

## Failure-tag results at the initial 0.5 threshold

| Question | Jev F1 | Gemini F1 | Clef F1 | Main observation |
|---|---:|---:|---:|---|
| Clear request missed | 0.561 | **0.647** | 0.571 | Jev/Clef recall 1.0 but precision only ~0.40 |
| Wrong intent/route | 0.667 | 0.500 | **0.783** | Clef leads; Gemini high precision but only 0.333 recall |
| Scenario coverage gap | 0.627 | 0.424 | 0.514 | All need YAML/context grounding; Jev over-tags |
| Scenario logic/context | 0.500 | **0.733** | 0.549 | Gemini leads; Jev recall 1.0 with 30 false positives |
| Prompt UX | **0.633** | 0.438 | 0.571 | All are borderline and need better definitions |
| Operator friction | 0.866 | 0.792 | **0.933** | Strong, useful signal |
| Language mismatch | 0.571 | **0.714** | 0.706 | Gemini precision 1.0; Clef better recall |
| ASR suspected | 0.500 | **0.571** | 0.529 | Text-only suspicion; audio remains necessary |
| No-progress loop | 0.286 | **0.412** | 0.286 | Not production-ready; Jev/Clef each produce 38 false positives |

## Exploratory threshold sweep

These thresholds were selected and evaluated on the same small sample. **Do not deploy them without human training labels and held-out validation.**

| Task | Best exploratory result | Interpretation |
|---|---|---|
| Wrong intent | Clef at 0.4: precision 0.786, recall 0.917, **F1 0.846**, Brier 0.085 | Best current wrong-intent candidate |
| Operator friction | Gemini at 0.2: **F1 0.951**; Clef at 0.4: F1 0.933, Brier 0.074 | Both useful; choose operating point on human labels |
| Language mismatch | Clef at 0.3: **F1 0.800**, Brier 0.070 | Stronger than the initial threshold |
| Scenario logic/context | Gemini at 0.4: **F1 0.750**, Brier 0.149 | Best current logic candidate |
| Clear request missed | Jev at 0.9 and Clef at 0.8: **F1 0.718** | Higher thresholds reduce over-tagging |
| ASR suspected | Gemini at 0.6: **F1 0.667**, Brier 0.107 | Best text-only candidate, still requires audio |
| No-progress loop | Gemini at 0.8: F1 0.571; Jev/Clef remain poor | Redesign/decompose rather than tune alone |

The full sweep is in `analysis/decision_threshold_sweep.csv` and `analysis/decision_threshold_best_f1_in_sample.{json,md}`.

## What the models caught well

- **S47:** all three identify transfer and high operator friction (0.85–0.91); Jev/Clef also strongly flag wrong intent/route.
- **S50:** all three strongly flag wrong intent and scenario/context failure. Jev/Clef say abandoned; Gemini says unresolved without transfer—an understandable boundary disagreement.
- **S37:** all three say unresolved and strongly flag scenario/context failure.
- **S11:** Jev/Clef correctly identify a clean resolved call and all three give low UX severity.

These examples show real potential for prioritizing human review and finding systemic defects cheaply.

## Where human review is indispensable

- **S48:** Jev/Gemini say unresolved; Clef says resolved. This is a material outcome disagreement, not a harmless label difference.
- **S9:** Jev says unresolved, Clef partially resolved, Gemini resolved, despite the caller receiving irrelevant transfer guidance. Models need explicit answer-relevance checks.
- **S4:** all correctly say abandoned, but UX scores of 1.81–2.34 inflate a silence-only call that had no stated service goal. Severity instructions need a no-service-request exception.
- **S44:** an annotation-clean transferred call receives elevated friction/severity, showing that operator choice must not automatically be penalized.

A 20-call prioritized human-review queue was generated in `analysis/decision_review_queue.json`. The complete outcome/severity table is in `analysis/decision_call_matrix.md`.

## Recommended role-specific ensemble—pending human validation

Do not majority-vote every question. Use the best validated model per task and escalate disagreement:

- **Broad outcome triage:** Jev, constrained by deterministic transfer/silence/final-state features.
- **Wrong intent:** Clef.
- **Operator friction:** Clef or Gemini with task-specific thresholds.
- **Scenario logic/context:** Gemini, supplied with the relevant YAML state in the next iteration.
- **Language mismatch:** Clef, with deterministic language features as supporting evidence.
- **ASR suspicion:** Gemini, followed by audio review.
- **No-progress:** deterministic repeat features plus targeted review; do not use the current Noul alone.
- **Final model choice if only one is allowed:** Jev for cheap outcome screening; Clef for broader bot-improvement diagnosis. This is tentative until human-gold evaluation.

## Changes for the next pilot

1. Separate `abandoned` from `unresolved_no_transfer` using explicit terminal-event definitions.
2. Add “no stated service request” and “caller freely chose a correct operator path” exceptions to UX severity.
3. Split no-progress into bot-identical-repeat, caller-repeat, and stuck-without-new-information.
4. Evaluate answer relevance separately from outcome; a transfer or any bot answer is not resolution.
5. Supply the active YAML state and intent shortlist for scenario judgments; transcript-only coverage labels are too speculative.
6. Move to per-turn intent evaluation before per-call aggregation, preserving previous prompt and state candidates.
7. Human-label the disagreement queue, then build a 300–500-call random-plus-enriched gold set with a time-based holdout.
8. Keep these models offline for analysis/triage until calibrated; do not make them unreviewed production routers.

## Files

- `analysis/decision_results.jsonl` — all raw model answers, probabilities, providers, usage, and latency.
- `analysis/decision_comparison.{md,json}` — headline and per-tag metrics.
- `analysis/decision_threshold_sweep.csv` — every model/question/threshold result.
- `analysis/decision_threshold_best_f1_in_sample.{md,json}` — exploratory best F1 points.
- `analysis/decision_call_matrix.md` — all 50 outcomes and UX scores side by side.
- `analysis/decision_review_queue.json` — prioritized disagreements and high-severity calls for humans.
