#!/usr/bin/env python3
"""Compare Decisions API results with the AI-assisted 50-call annotations.

This measures agreement/triage behavior, not true production accuracy. Final model
selection requires human-adjudicated labels and a separate held-out test set.
"""

from __future__ import annotations

import argparse
import collections
import json
import math
import statistics
from pathlib import Path

OUTCOME_MAP = {
    "resolved": "resolved",
    "partially_resolved": "partially_resolved",
    "transferred": "transferred",
    "abandoned": "abandoned",
    "unresolved": "unresolved_no_transfer",
    "unclear": "unclear",
}
SEVERITY_SCORE = {"none": 0, "low": 1, "medium": 2, "high": 3}
TAG_MAP = {
    "clear_request_missed": {"nlu_miss"},
    "wrong_intent_or_route": {"nlu_wrong_intent"},
    "scenario_coverage_gap": {"scenario_missing", "scenario_state_coverage"},
    "scenario_logic_or_context_failure": {"scenario_logic", "state_context"},
    "prompt_ux_problem": {"prompt_ux"},
    "operator_friction": {"operator_friction"},
    "language_mismatch": {"language_mismatch"},
    "asr_suspected": {"asr_suspected"},
    "no_progress_loop": {"no_progress"},
}


def percentile(values: list[float], p: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    position = (len(ordered) - 1) * p
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return ordered[lower]
    return ordered[lower] + (ordered[upper] - ordered[lower]) * (position - lower)


def prf(tp: int, fp: int, fn: int) -> dict:
    precision = tp / (tp + fp) if tp + fp else None
    recall = tp / (tp + fn) if tp + fn else None
    f1 = 2 * precision * recall / (precision + recall) if precision is not None and recall is not None and precision + recall else None
    return {"tp": tp, "fp": fp, "fn": fn, "precision": precision, "recall": recall, "f1": f1}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=Path, default=Path("analysis/decision_results.jsonl"))
    parser.add_argument("--annotations", type=Path, default=Path("analysis/call_annotations_50.json"))
    parser.add_argument("--output-prefix", type=Path, default=Path("analysis/decision_comparison"))
    parser.add_argument("--threshold", type=float, default=0.5)
    args = parser.parse_args()

    annotations = {
        int(row["sample_id"]): row
        for row in json.loads(args.annotations.read_text(encoding="utf-8"))
    }
    rows = []
    with args.results.open("r", encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                rows.append(json.loads(line))
    if not rows:
        raise ValueError("No Decisions results found")

    models = sorted({row["model"] for row in rows})
    success = [row for row in rows if row.get("ok")]
    errors = [row for row in rows if not row.get("ok")]
    summary: dict[str, dict] = {}
    tag_metrics: dict[str, dict] = {}
    disagreement_ids: dict[str, set[int]] = {model: set() for model in models}

    for model in models:
        model_rows = [row for row in success if row["model"] == model]
        outcome_matches = 0
        outcome_compared = 0
        severity_errors = []
        costs = []
        input_tokens = []
        for row in model_rows:
            sample_id = int(row["sample_id"])
            truth = annotations[sample_id]
            answers = row["response"].get("answers", {})
            usage = row["response"].get("usage", {})
            if isinstance(usage.get("cost"), (int, float)):
                costs.append(usage["cost"])
            if isinstance(usage.get("input_tokens"), int):
                input_tokens.append(usage["input_tokens"])
            outcome = answers.get("outcome", {})
            if outcome.get("type") == "choice":
                outcome_compared += 1
                predicted = outcome.get("choice")
                expected = OUTCOME_MAP[truth["outcome"]]
                if predicted == expected:
                    outcome_matches += 1
                else:
                    disagreement_ids[model].add(sample_id)
            severity = answers.get("ux_severity", {})
            if severity.get("type") == "score" and isinstance(severity.get("score"), (int, float)):
                severity_errors.append(abs(severity["score"] - SEVERITY_SCORE[truth["severity"]]))

        elapsed = [float(row["elapsed_seconds"]) for row in model_rows]
        summary[model] = {
            "successful_calls": len(model_rows),
            "errors": len([row for row in errors if row["model"] == model]),
            "total_cost_usd": sum(costs),
            "cost_measurements": len(costs),
            "input_tokens": sum(input_tokens),
            "outcome_agreement_with_ai_annotations": outcome_matches / outcome_compared if outcome_compared else None,
            "outcome_compared": outcome_compared,
            "ux_severity_mae": statistics.mean(severity_errors) if severity_errors else None,
            "elapsed_mean_seconds": statistics.mean(elapsed) if elapsed else None,
            "elapsed_p95_seconds": percentile(elapsed, 0.95),
        }

        tag_metrics[model] = {}
        for question, truth_tags in TAG_MAP.items():
            tp = fp = fn = 0
            compared = 0
            for row in model_rows:
                answer = row["response"].get("answers", {}).get(question, {})
                if answer.get("type") != "noul" or not isinstance(answer.get("noul"), (int, float)):
                    continue
                actual = bool(truth_tags & set(annotations[int(row["sample_id"])]["failure_tags"]))
                predicted = answer["noul"] >= args.threshold
                compared += 1
                if predicted and actual:
                    tp += 1
                elif predicted and not actual:
                    fp += 1
                elif not predicted and actual:
                    fn += 1
                if predicted != actual:
                    disagreement_ids[model].add(int(row["sample_id"]))
            tag_metrics[model][question] = {**prf(tp, fp, fn), "compared": compared}

    pairwise = {}
    for index, left in enumerate(models):
        for right in models[index + 1:]:
            left_rows = {int(row["sample_id"]): row for row in success if row["model"] == left}
            right_rows = {int(row["sample_id"]): row for row in success if row["model"] == right}
            common = set(left_rows) & set(right_rows)
            compared = 0
            matched = 0
            for sample_id in common:
                a = left_rows[sample_id]["response"].get("answers", {}).get("outcome", {})
                b = right_rows[sample_id]["response"].get("answers", {}).get("outcome", {})
                if a.get("type") == "choice" and b.get("type") == "choice":
                    compared += 1
                    matched += a.get("choice") == b.get("choice")
            pairwise[f"{left} <> {right}"] = {
                "outcome_agreement": matched / compared if compared else None,
                "compared": compared,
            }

    report = {
        "scope": "Agreement with AI-assisted annotations, not human-gold accuracy; use for triage only",
        "noul_threshold": args.threshold,
        "result_rows": len(rows),
        "successful_rows": len(success),
        "error_rows": len(errors),
        "models": summary,
        "tag_metrics": tag_metrics,
        "pairwise_outcome_agreement": pairwise,
        "sample_ids_with_any_outcome_or_tag_disagreement": {
            model: sorted(values) for model, values in disagreement_ids.items()
        },
        "errors": [
            {key: row.get(key) for key in ("sample_id", "call_id", "model", "error")}
            for row in errors
        ],
    }
    args.output_prefix.parent.mkdir(parents=True, exist_ok=True)
    args.output_prefix.with_suffix(".json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    lines = [
        "# Decisions model comparison",
        "",
        "**Agreement with AI-assisted annotations, not human-gold accuracy. Do not select a production model from this table alone.**",
        "",
        f"Noul threshold: {args.threshold}. Successful rows: {len(success)}; errors: {len(errors)}.",
        "",
        "| Model | Calls | Errors | Cost USD | Outcome agreement | UX severity MAE | Mean seconds | p95 seconds |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for model, stats in summary.items():
        def fmt(value, digits=3):
            return "—" if value is None else f"{value:.{digits}f}"
        lines.append(
            f"| `{model}` | {stats['successful_calls']} | {stats['errors']} | "
            f"{stats['total_cost_usd']:.6f} | {fmt(stats['outcome_agreement_with_ai_annotations'])} | "
            f"{fmt(stats['ux_severity_mae'])} | {fmt(stats['elapsed_mean_seconds'])} | {fmt(stats['elapsed_p95_seconds'])} |"
        )
    lines.extend(["", "## Pairwise outcome agreement", "", "| Models | Agreement | Compared |", "|---|---:|---:|"])
    for pair, stats in pairwise.items():
        agreement = stats["outcome_agreement"]
        lines.append(f"| `{pair}` | {'—' if agreement is None else f'{agreement:.3f}'} | {stats['compared']} |")
    for model in models:
        lines.extend([
            "", f"## {model}: independent failure tags", "",
            "| Question | TP | FP | FN | Precision | Recall | F1 |",
            "|---|---:|---:|---:|---:|---:|---:|",
        ])
        for question, stats in tag_metrics[model].items():
            def metric(value):
                return "—" if value is None else f"{value:.3f}"
            lines.append(
                f"| `{question}` | {stats['tp']} | {stats['fp']} | {stats['fn']} | "
                f"{metric(stats['precision'])} | {metric(stats['recall'])} | {metric(stats['f1'])} |"
            )
    if errors:
        lines.extend(["", "## Errors", ""])
        for row in errors:
            lines.append(f"- Sample {row['sample_id']}, `{row['model']}`: {row.get('error', '')[:500]}")
    args.output_prefix.with_suffix(".md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"models": summary, "errors": len(errors)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
