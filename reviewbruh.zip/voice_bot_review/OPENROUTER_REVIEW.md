# OpenRouter and System One review for the Verigram voice bot

**Research date:** 2026-11-18  
**Scope:** offline call analysis and bot improvement, not unreviewed autonomous banking responses.

## Bottom line

Yes—System One / Decisions models are a good fit for **structured call tagging, triage, intent shortlist adjudication, failure detection, and UX scoring**. They are not a complete replacement for a generative LLM, human review, the existing NLU, or scenario engineering.

Use a cascade:

```text
Local transcript parser and deterministic signals
  -> embeddings for cluster discovery and candidate retrieval
  -> reranker for a small intent/context shortlist
  -> Decisions model for typed labels and probabilities
  -> generative LLM only for difficult diagnosis and rewrite proposals
  -> human adjudication
  -> NLU positives/hard negatives + reviewed YAML changes
  -> static checks, historical replay, shadow evaluation, controlled rollout
```

Do not use a decision model's output as ground truth. Do not let an LLM autonomously write production banking answers or deploy YAML.

## What the named models actually do

Prices below are public catalog/list prices observed on 2026-11-18, in USD per million input tokens. Endpoint discounts and provider routing can change them. Decisions output tokens are listed as free. Always reconcile actual `usage.cost`.

| Model | Best role here | Context/modality | Input price | Important limitations |
|---|---|---|---:|---|
| `typesafe/jev-1.14` | Cheap per-turn and per-call Choice/Noul/Score labels; first text-model candidate | 262k; text + images | $0.042 | No prose or explanation. TypeSafe says requests above roughly 32 KB of text enter slower, less accurate long-context mode. Recalibrate on Halyk data. |
| `google/gemini-decision-1` | Full-call judgments and future audio-assisted review | 262k; text, images, files, audio, video | $0.10 | No prose. It was **not present in OpenRouter's ZDR endpoint list when checked**, so strict-ZDR requests should fail rather than fall back. Check current policy before use. |
| `cloudflare/clef` | Strong general decision-model candidate for full calls | ~65k; text + images | $0.192 current top endpoint; $0.24 direct Cloudflare | No prose. Public BANKING77 results do not establish Kazakh/Russian mixed-speech performance. |
| `cloudflare/clef-flash` | Cheap per-turn labels and high-volume screening | ~24k hosted; text + images | $0.019 current discounted endpoint; $0.038 direct Cloudflare | OpenRouter documents that Workers AI reads roughly only the first 2,000 text tokens in `state` and drops the rest without an error. Avoid unsegmented full calls on that endpoint. |
| `cloudflare/clef-omni` | Future audio + transcript review; text decisions | 65k; text, images, audio, video | $0.15 | Audio limits apply (OpenRouter documents up to 4 clips, 8 MiB/300 seconds each, and combined media limits). It returns decisions, not a corrected transcript. |
| `cloudflare/clairic` | Typed evidence extraction: exact caller-goal spans, lists of mentioned topics, dates/amounts when needed | 65k; text + images via `/api/alpha/extractions` | $0.10 | This is an extraction/computation/estimation model, **not the primary classifier**. Multiple field passes can repeat state billing. Deterministic fields should remain in code. |
| `respan/span-01` | Additional bake-off candidate for behavior scoring over conversation spans | Text; model-specific state contract | $0.02 | Promising for UX behaviors, but evaluate its exact request shape and Halyk-language accuracy before inclusion. |

Jev's `confidence` summarizes the shape of the answer distribution; it is not a guarantee that an individual answer is correct. TypeSafe recommends acting on option/Noul probabilities and using an uncertainty band. Thresholds must be fitted separately for each model, question, language, and risk level.

### Generative LLM candidates for the escalation stage

These models should explain already-retrieved evidence and draft changes; they should not make ungrounded banking policy decisions. Prices are input/output per million tokens at the current default endpoint.

| Candidate | Role | Price | Policy/fit notes |
|---|---|---:|---|
| `anthropic/claude-haiku-5.5` | Low-cost structured diagnosis and prompt/YAML draft generation | $0.10 / $0.50 below 100k context | Bedrock and Google endpoints appeared in the ZDR list. Benchmark RU/KZ quality rather than assuming it from general reputation. |
| `qwen/qwen3.8-27b` | Open-weight multilingual candidate, including possible self-hosting | $0.06 / $2.20 current top endpoint; varies widely | Many providers appeared in the ZDR list. Open weights provide an on-prem path; output-heavy analysis can cost more than decision labels. |
| `anthropic/claude-sonnet-5.5` | Strong reviewer for difficult, high-severity disagreements | $2 / $10 | Bedrock and Google endpoints appeared in the ZDR list. Use only after cheaper stages to control cost. |
| `google/gemini-4-argon` | Strong multimodal alternative if audio and generative explanation are both required | $2 / $10, plus reasoning/audio charges where applicable | Current listed endpoints had `safety_retention=true`; do not use under a strict ZDR-only requirement unless an approved BYOK arrangement changes that. |

`qwen/qwen3.8-flash` is inexpensive and supports structured output, but did not appear in the strict ZDR list when checked. It can join the bake-off only if the bank approves its available endpoint policy.

### Useful vendor evidence—but not a selection decision

- Cloudflare reports BANKING77 macro-F1 of 94.8 for Clef-omni, 94.2 for Clef, 90.9 for Clef-flash, and 79.7 for Jev. This is encouraging for banking-topic classification but does **not** test this bot, Kazakh, code-switching, ASR noise, state-dependent routing, or UX failure tags.
- OpenRouter's catalog showed Decision Index values around 66.2 for Jev 1.14, 66.0 for Gemini Decision 1, 60.3 for Clef, and 57.8 for Clef-omni. These are general aggregate indicators, not evidence of superiority on Halyk calls.
- Clef is open-weight and can be self-hosted. Clef-omni's model card describes an H200/bfloat16 setup requiring about 64 GB GPU memory. Self-hosting is a valid option if external bank-data processing is rejected.

## Where embeddings and rerankers fit

### Embeddings: discovery and retrieval, not explanations

Start with `qwen/qwen3-embedding-8b` and a cheaper/smaller baseline such as multilingual E5 or Qwen3-Embedding-0.6B/4B. Qwen's model card reports 100+ languages and strong general multilingual benchmarks; Kazakh-specific performance still needs a local test.

Use embeddings on **individual caller turns**, with the previous bot prompt and current state as metadata:

1. Cluster meaningful `unknown` turns to discover missing intents and synonyms.
2. Find nearest neighbors of known failures to estimate their recurrence.
3. Deduplicate near-identical examples before annotation and training.
4. Retrieve candidate intent descriptions and real approved examples for the next stage.
5. Mine hard negatives: semantically close utterances that must not fire an intent.

Do not treat cluster boundaries as new intents automatically. A human must distinguish a new product/topic, an entity, an ASR artifact, and a state-local answer such as “Kazakhstan card.”

### Reranker: improve the shortlist

Candidates: `qwen/qwen3-reranker-8b` or a multilingual Cohere reranker, compared against embedding-only retrieval.

For each utterance:

```text
current NLU top-k (if available)
  + top 10–20 embedding-retrieved intent cards
  -> rerank (utterance + previous bot prompt + state)
  -> top 3–8 intent candidates + other/unclear
  -> Decisions adjudication or human annotation
```

An intent card should contain the workbook description, state restrictions, a few approved RU/KZ examples, and explicit hard-negative boundaries. Reranking is useful for annotation assistance and retrieval; it is not automatically a safe production intent classifier. Rerank scores need their own calibration and abstention test.

Do not use real calls as an authoritative banking knowledge base. They contain wrong bot answers and ASR errors. Use calls for discovery, and approved documentation/scenario content for grounded answer rewrites.

## Recommended analysis units

### Per turn

- `asr_unintelligible_suspected` (only a suspicion without audio)
- true intent among a small shortlist plus `other/unclear`
- answer type expected by the current state
- language and code-switch
- whether the logged intent is semantically supported
- whether the selected transition addressed the previous bot prompt

### Per call

Use independent Noul questions rather than one overloaded “root cause” label:

- clear request missed
- wrong intent/route
- scenario coverage gap
- scenario logic/context failure
- prompt UX problem
- operator friction
- language mismatch
- no-progress loop
- caller goal answered / partially answered / unanswered
- observed outcome and review priority

The local `decision_questions.json` implements an initial schema. A generative LLM can then receive only uncertain/high-priority cases plus the relevant YAML state and retrieved intent cards to explain the issue and propose a patch.

### With audio (when available)

Gemini Decision 1 or Clef-omni can judge narrow propositions such as:

- caller audio is intelligible;
- transcript omits or materially changes the request;
- caller language differs from bot language;
- long silence or repeated interruption occurred;
- caller repeated the same request.

They do not replace STT when corrected text is needed. Keep audio segment-level and align it to turns. Audio is more sensitive than redacted text and requires separate approval.

## Evaluation design

### 1. Build a gold set, not just a model demo

The current 50 calls are a discovery set enriched for failures. For model selection, create at least 300–500 calls with:

- random baseline calls;
- RU, KZ, and mixed-language strata;
- high-volume scenarios and rare/high-risk scenarios;
- unknown, wrong-route, repetition, silence, and successful cases;
- turn-level true intent and expected answer type;
- call-level outcome and independent failure tags;
- dual annotation of 15–20% with adjudication.

Keep an untouched time-based test set. Split utterances by `call_id`/`group_id`, not randomly, so repeated wording from one call cannot leak into train and test.

### 2. Compare against the production baseline

Measure per model and per language:

- turn intent top-1 and top-k accuracy, macro-F1, and confusion pairs;
- unknown/OOS precision and recall;
- state-conditional routing accuracy using the same candidate intents as the engine;
- failure-tag precision/recall and call-outcome accuracy;
- Brier score/reliability by probability band and review rate;
- wrong high-risk route rate;
- p50/p95 latency, failures, actual cost per 1,000 turns/calls.

Select thresholds for the required operating point. For example, card blocking or antifraud needs a different false-acceptance budget from generic information. Evaluate abstention, not only forced-choice accuracy.

### 3. Feed improvements back safely

1. Human-approved examples become universal-CSV positives and hard negatives.
2. Retrain/evaluate the existing LaBSE model in **deployment/argmax** mode, including old-intent regression tests.
3. LLM proposals for YAML remain drafts until reviewed.
4. Run structural lint: local/cross-scenario targets, unreachable transitions, model-label coverage, and route tests.
5. Replay historical turns through the changed scenario and compare the resulting path.
6. Shadow the new NLU/router online without affecting callers; then run a controlled rollout with rollback.

## North-star metrics

Do not optimize containment alone. A bot can improve containment by trapping callers.

Track jointly:

- verified task-resolution rate;
- median time to first useful answer;
- meaningful-unknown rate (excluding silence and unintelligible ASR);
- wrong-scenario and wrong-financial-guidance rates;
- no-progress loop rate;
- operator-request, operator-friction, transfer, and abandonment rates;
- language-mismatch rate;
- per-state confusion and fallback reasons;
- customer score, while accounting for missing/invalid ratings.

## Privacy and deployment

- Keep raw data local by default. The artifacts here redact long digit sequences in derived transcripts and do not send calls externally.
- Obtain bank approval before any hosted inference. Minimize content, remove direct identifiers where possible, disable optional OpenRouter input/output logging and plugins, and verify endpoint policies at run time.
- The pilot sets `provider.zdr: true`, `data_collection: deny`, and `allow_fallbacks: false`. A policy-incompatible model must fail, not reroute.
- OpenRouter says prompt content is not routinely retained unless opted in, with legal/CSAM exceptions, but it retains request metadata and providers have separate policies. ZDR reduces retention; it does not make processing on a third-party system compliant by itself.
- Jev, Clef, Clairic, Qwen embeddings, and Qwen rerankers appeared in the ZDR-capable endpoint list when checked. Gemini Decision 1 did not. Recheck immediately before a pilot.
- If external processing is not approved, use open-weight embedding/reranker/Clef models or the existing LaBSE stack on premises.

## Pilot scope and cost discipline

Run 50 calls × Jev + Clef first; add Gemini only if its data policy is approved. Inspect raw probabilities, not just selected labels. Escalate disagreement, low top probability, small top-two margin, or high severity to a generative LLM/human.

Illustrative arithmetic only: at 2,000 billed input tokens per call, 50 calls cost approximately $0.0042 on Jev, $0.010 on Gemini, and $0.0192–$0.024 on Clef, before retries. At 10,000 tokens per call, multiply by five. This excludes generative LLM, embeddings, reranking, and audio. Use actual returned usage rather than this estimate for budgeting.

## Sources

- OpenRouter model catalog and per-model metadata: <https://openrouter.ai/api/v1/models?output_modalities=all>
- OpenRouter model filtering (decisions/embeddings/rerank are omitted from the default text list): <https://openrouter.ai/docs/guides/overview/models>
- Decisions API: <https://openrouter.ai/docs/api/api-reference/alphadecisions/submit-a-decisions-request.md>
- Multimodal decisions and provider limits: <https://openrouter.ai/docs/guides/community/multimodal-decisions.md>
- Jev/System One: <https://openrouter.ai/docs/guides/community/jev.md> and <https://docs.typesafe.ai/concepts/system-one>
- Jev confidence semantics: <https://docs.typesafe.ai/confidence>
- Jev classification and threshold workflow: <https://openrouter.ai/docs/cookbook/evaluate-and-optimize/jev-classification.md>
- Cloudflare Clef-omni model card and evaluations: <https://huggingface.co/Cloudflare/clef-omni>
- Cloudflare Clef announcement and latency/context notes: <https://blog.cloudflare.com/clef-faster-cheaper-multimodal>
- Cloudflare Clairic documentation: <https://developers.cloudflare.com/workers-ai/models/clairic/>
- OpenRouter Extractions API: <https://openrouter.ai/docs/guides/community/extractions.md>
- Qwen3-Embedding model card: <https://huggingface.co/Qwen/Qwen3-Embedding-8B>
- Embeddings and rerank pipeline: <https://openrouter.ai/docs/cookbook/evaluate-and-optimize/rag.md>
- OpenRouter data collection: <https://openrouter.ai/docs/guides/privacy/data-collection.md>
- Provider logging: <https://openrouter.ai/docs/guides/privacy/provider-logging.md>
- ZDR semantics and endpoint list: <https://openrouter.ai/docs/guides/features/zdr.md> and <https://openrouter.ai/api/v1/endpoints/zdr>
