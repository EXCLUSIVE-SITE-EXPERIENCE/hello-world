# Qualitative review: SAMPLE 26–50

## Scope and interpretation

This review covers all 25 assigned calls. The source is an enriched deterministic sample with targeted unknown, repetition, language, multi-topic, and unresolved strata; **these counts describe only SAMPLE 26–50 and must not be extrapolated to all calls**. Outcome `transferred` means a transfer prompt was reached, not that the caller's problem was resolved.

Active YAML was checked before making scenario claims, especially `00_00_continuity`, `00_06_reask_before_operator`, `08_05_how_transfer`, `08_02_international_transfer`, `25_15_recipient_not_received`, `24_04_hsa_certificates`, `03_08_change_payment_date`, and `00_01_identification`. No audio was available: `asr_suspected` is used only for garbled text and never as a proven ASR diagnosis.

## Counts from the annotation JSON

### Outcomes and severity

| Outcome | Calls |
|---|---:|
| transferred | 20 |
| unresolved | 3 |
| partially_resolved | 1 |
| abandoned | 1 |
| resolved / unclear | 0 / 0 |

| Severity | Calls |
|---|---:|
| high | 6 |
| medium | 12 |
| low | 6 |
| none | 1 |

Confidence is high for 21 annotations, medium for 3, and low for 1 (SAMPLE 49, where the caller's goal is genuinely ambiguous in the transcript).

### Failure tags

Tags are multi-label, so their total exceeds 25.

| Tag | Calls |
|---|---:|
| operator_friction | 17 |
| prompt_ux | 14 |
| nlu_miss | 8 |
| language_mismatch | 6 |
| nlu_wrong_intent | 6 |
| scenario_logic | 5 |
| scenario_missing | 5 |
| state_context | 5 |
| scenario_state_coverage | 4 |
| asr_suspected | 4 |
| no_progress | 4 |
| none | 1 |

Twelve distinct calls have either `nlu_miss` or `nlu_wrong_intent`; SAMPLES 46 and 47 have both tags.

## Cross-call findings

### 1. Correct final operator classification must be separated from earlier NLU failures

Several calls ended with a valid service intent that the active `00_06` router explicitly maps to a specialist queue. Examples include card requisites in SAMPLES 26 and 29, balance in 27, deposit in 30, credit in 35 and 41, pension in 40, and inbound card transfer in 43. These final classifications are successes; they are not evidence of missing scenarios or failed NLU. They also do **not** show resolution, because the bot transferred rather than answering the service question.

Operator recognition itself was often robust across languages: SAMPLES 39 and 45 correctly recognized every explicit operator request, including Kazakh wording. SAMPLE 31 also shows useful confirmation recovery from an ambiguous objectless “заблокировался” to card unblock and then `why_card_blocked`.

### 2. Premature surveying is the clearest systemic state/logic defect

SAMPLES 47, 48, and 50 expose the same active rule: `00_00_continuity.main` sends `disagree` or `dont_know` directly to `score_the_conversation`, even when no service has been delivered. Consequences differ but are all harmful:

- SAMPLE 47: an explicit operator request became `disagree`, and survey text later contaminated the operator flow.
- SAMPLE 48: a caller returning a bank call was asked for a rating, then the catch-all score transition accepted “пять пять” despite `intent=unknown` and ended the call.
- SAMPLE 50: a clear app-open complaint became `dont_know`; three survey prompts and silences ended in abandonment.

Survey entry should require a completed service interaction and an explicit end-of-help signal. A main-state `dont_know` should instead clarify the service goal. Score states should validate a rating and should not inherit into operator transfer.

### 3. State coverage causes loops even when an intent is recognized

- **SAMPLES 37 and 42 — transfer direction and receipt loop:** `25_15.answer` repeats its sender-side receipt answer on `recipient_not_received`. SAMPLE 37 had no bank-selected/no-receipt branch, while SAMPLE 42 initially ignored the caller's explicit recipient role. The answer is not interchangeable for sender and recipient.
- **SAMPLE 43 — same-intent dead end:** after `hsa_certificates` incorrectly fired, `24_04_hsa_certificates.start` had no same-intent recovery transition. Repeated `hsa_certificates` turns therefore produced fallback instead of returning to the original missing-money context.
- **SAMPLE 46 — no resumable steps:** `03_08.start` maps `repeat` to the same long answer. It has no current-step repeat or closing/thanks path, which contributed to a later context loss and wrong `update_personal_data` answer.
- **SAMPLE 36 is different:** `08_05.start` already covers `international_transfer`, and `08_02` already covers Western Union. The observed `unknown` labels therefore point first to contextual NLU recognition, not a missing international-transfer scenario.

### 4. NLU fixes should be narrow and context-aware

Clear misses include call-center wording (30), received-amount wording in Kazakh (33), Kazakh restriction/consultation wording (32 and 35), and direct answers “международный” / “вестерн юнион” after the transfer-type prompt (36). High-impact wrong intents include:

- flash-key code → `withdraw_without_card` (34), potentially sending the caller to the wrong queue;
- inbound transfer → `recipient_not_received` (42);
- missing money/account lookup → `hsa_certificates` (43);
- payment-date follow-up → `update_personal_data` (46);
- operator request → `disagree` (47);
- app will not open → `dont_know` (50).

Use these as regression examples with hard negatives, especially direction, card-requisites/certificates, payment-date/personal-data, and flash-key/PIN/withdrawal distinctions. SAMPLE 49 should not become training data until audio or a reliable transcript confirms its meaning.

### 5. Operator gating creates avoidable delay and repeated prompts

Seventeen calls have `operator_friction`. The common sequence is deflection → first reason request → overload/second reason request, sometimes repeated on silence. This is particularly poor when the caller repeatedly asks only for an operator (39 and 45), has already supplied a reason (27 and 33), or explicitly says they do not understand Russian (35).

After a repeated explicit operator request, allow a general-queue transfer and use a voluntarily supplied topic for routing. Do not replay the same prompt after silence, and do not show an overload warning after a valid routing reason has already been recognized. Keep the valid specialist mappings in `00_06`; the problem is the gate and retry behavior, not those mappings.

### 6. Language mismatch needs behavioral evidence, not just the heuristic label

Six calls were tagged `language_mismatch`: 32, 34, 35, 37, 40, and 45. Sustained Kazakh input repeatedly received Russian fallback/operator prompts. SAMPLE 35 is especially clear because the caller explicitly said they did not understand Russian.

SAMPLES 38 and 39 were deliberately **not** tagged: 38 explicitly selected Russian, and 39 had one Kazakh consultant request amid Russian operator requests without a clear switch preference. Repeated Kazakh speech should trigger a language offer or switch, with all subsequent states honoring that context immediately.

### 7. Highest-value new intents/scenarios and prompt fixes

The five `scenario_missing` annotations reduce to four concrete gaps: greeting/small-talk handling (29 and 40), flash-token/EDS support (34), missed-bank-call handling (48), and general app-launch troubleshooting (50). Separately, SAMPLE 37 needs a bank-not-selected/no-receipt transfer branch, and SAMPLE 29 motivates a safe card-requisite-sharing extension.

Prompt improvements with direct payoff are: remove the stray `§` in SAMPLE 36's transfer prompt; rewrite the grammatically broken Russian arrest prompt in SAMPLE 38; replace generic repeated fallback with targeted clarifiers (28, 33, and 49); make identification wait genuinely wait instead of immediately reasking (42); and provide step-by-step resume rather than full-answer replay (46).

## Notable observations by call

| Sample / call | Actual outcome and most important observation |
|---|---|
| 26 / 85493 | Transferred; `card_requisites_info` routing succeeded, with only operator-gating friction and no card-number answer. |
| 27 / 86479 | Transferred; initial account-withdrawal reason was missed, while final `check_balance` routing was correct. |
| 28 / 109337 | Transferred; vague “about cards” was not enough to assert an NLU error, but repeating the same reason request was poor UX. |
| 29 / 123137 | Transferred; greetings consumed retries, then the requisite topic was correctly classified and routed. |
| 30 / 150165 | Transferred; explicit call-center request was missed, while final `deposit__otkrit` routing succeeded. |
| 31 / 12998 | Transferred; ambiguous app/card start recovered through confirmation, but generic unblock guidance preceded the real bank-block goal. |
| 32 / 22537 | Transferred; intelligible Kazakh restriction explanations remained unknown and Russian prompts persisted. |
| 33 / 60921 | Transferred after no progress; four Kazakh received-amount variants were unknown instead of triggering balance/history clarification. |
| 34 / 62893 | Transferred; flash-key code problem was wrongly routed as `withdraw_without_card`; dedicated EDS coverage is absent. |
| 35 / 124149 | Transferred; an explicit Kazakh statement of not understanding Russian was ignored, although final `cash_credit` routing was correct. |
| 36 / 145410 | Transferred; both international and Western Union answers failed despite existing scenario coverage. |
| 37 / 37058 | Unresolved; bank-not-selected/no-receipt problem received the same irrelevant receipt advice twice. |
| 38 / 51365 | Partially resolved; arrest guidance was relevant but generic and ungrammatical, with no account-specific outcome. |
| 39 / 69031 | Transferred; operator NLU worked, while repeated reason prompts and silence replay caused the friction. |
| 40 / 99503 | Transferred; greeting/language failures preceded a correct `pension_receipt` classification and route. |
| 41 / 126365 | Transferred; `cash_credit` routing succeeded and the only material defect was operator friction. |
| 42 / 3452 | Unresolved; inbound/outbound direction was initially wrong, later recovered to identification, but no trace result was reached. |
| 43 / 79604 | Transferred; incorrect HSA state persisted despite rejection, then final `pin__ne_perevod_dengi` routing recovered. |
| 44 / 91923 | Transferred; positive case with `none`: Kazakh payment-amount recognition and relevant app guidance worked, though no actual amount was supplied. |
| 45 / 130989 | Transferred; every Kazakh operator request was recognized, yet Russian prompts and duplicated overload messages continued. |
| 46 / 146583 | Transferred; strong initial payment-date answer degraded through full replay, missed thanks, and a wrong personal-data follow-up. |
| 47 / 32717 | Transferred; premature survey, operator-as-`disagree`, stale survey context, and missed card-number intent compounded. |
| 48 / 77285 | Unresolved; a missed-bank-call goal was converted directly into a survey and goodbye. |
| 49 / 93548 | Transferred; goal and failure cause remain uncertain because multiple turns are garbled; audio review is required before NLU changes. |
| 50 / 109684 | Abandoned; app-open complaint triggered the survey path, repeated three times, then silence hangup without service. |

## Recommended implementation order

1. Fix main-state survey gating, score validation, and survey/operator context isolation (47, 48, 50).
2. Repair transfer-direction and no-receipt handling (37, 42), then HSA recovery (43) and resumable payment-date steps (46).
3. Preserve correct `00_06` mappings while simplifying repeated-operator transfer and silence behavior (17 tagged calls).
4. Deploy the narrowly scoped NLU regression set with hard negatives, prioritizing wrong-queue/wrong-answer cases (34, 42, 43, 46, 47, 50).
5. Add sustained-language detection and prompt localization (32, 34, 35, 37, 40, 45).
6. Add greeting, EDS/flash-key, missed-call, and app-launch coverage only after transcript review where flagged; do not use the four `asr_suspected` labels as proof of ASR defects.
