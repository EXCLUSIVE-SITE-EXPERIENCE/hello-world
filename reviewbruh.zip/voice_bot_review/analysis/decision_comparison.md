# Decisions model comparison

**Agreement with AI-assisted annotations, not human-gold accuracy. Do not select a production model from this table alone.**

Noul threshold: 0.5. Successful rows: 150; errors: 0.

| Model | Calls | Errors | Cost USD | Outcome agreement | UX severity MAE | Mean seconds | p95 seconds |
|---|---:|---:|---:|---:|---:|---:|---:|
| `cloudflare/clef` | 50 | 0 | 0.023814 | 0.860 | 0.601 | 1.447 | 2.178 |
| `google/gemini-decision-1` | 50 | 0 | 0.010293 | 0.800 | 0.719 | 1.226 | 1.956 |
| `typesafe/jev-1.14` | 50 | 0 | 0.005001 | 0.880 | 0.578 | 1.066 | 1.430 |

## Pairwise outcome agreement

| Models | Agreement | Compared |
|---|---:|---:|
| `cloudflare/clef <> google/gemini-decision-1` | 0.820 | 50 |
| `cloudflare/clef <> typesafe/jev-1.14` | 0.920 | 50 |
| `google/gemini-decision-1 <> typesafe/jev-1.14` | 0.840 | 50 |

## cloudflare/clef: independent failure tags

| Question | TP | FP | FN | Precision | Recall | F1 |
|---|---:|---:|---:|---:|---:|---:|
| `clear_request_missed` | 16 | 24 | 0 | 0.400 | 1.000 | 0.571 |
| `wrong_intent_or_route` | 9 | 2 | 3 | 0.818 | 0.750 | 0.783 |
| `scenario_coverage_gap` | 9 | 5 | 12 | 0.643 | 0.429 | 0.514 |
| `scenario_logic_or_context_failure` | 14 | 22 | 1 | 0.389 | 0.933 | 0.549 |
| `prompt_ux_problem` | 14 | 12 | 9 | 0.538 | 0.609 | 0.571 |
| `operator_friction` | 28 | 2 | 2 | 0.933 | 0.933 | 0.933 |
| `language_mismatch` | 6 | 2 | 3 | 0.750 | 0.667 | 0.706 |
| `asr_suspected` | 9 | 15 | 1 | 0.375 | 0.900 | 0.529 |
| `no_progress_loop` | 8 | 38 | 2 | 0.174 | 0.800 | 0.286 |

## google/gemini-decision-1: independent failure tags

| Question | TP | FP | FN | Precision | Recall | F1 |
|---|---:|---:|---:|---:|---:|---:|
| `clear_request_missed` | 11 | 7 | 5 | 0.611 | 0.688 | 0.647 |
| `wrong_intent_or_route` | 4 | 0 | 8 | 1.000 | 0.333 | 0.500 |
| `scenario_coverage_gap` | 7 | 5 | 14 | 0.583 | 0.333 | 0.424 |
| `scenario_logic_or_context_failure` | 11 | 4 | 4 | 0.733 | 0.733 | 0.733 |
| `prompt_ux_problem` | 7 | 2 | 16 | 0.778 | 0.304 | 0.438 |
| `operator_friction` | 21 | 2 | 9 | 0.913 | 0.700 | 0.792 |
| `language_mismatch` | 5 | 0 | 4 | 1.000 | 0.556 | 0.714 |
| `asr_suspected` | 6 | 5 | 4 | 0.545 | 0.600 | 0.571 |
| `no_progress_loop` | 7 | 17 | 3 | 0.292 | 0.700 | 0.412 |

## typesafe/jev-1.14: independent failure tags

| Question | TP | FP | FN | Precision | Recall | F1 |
|---|---:|---:|---:|---:|---:|---:|
| `clear_request_missed` | 16 | 25 | 0 | 0.390 | 1.000 | 0.561 |
| `wrong_intent_or_route` | 10 | 8 | 2 | 0.556 | 0.833 | 0.667 |
| `scenario_coverage_gap` | 21 | 25 | 0 | 0.457 | 1.000 | 0.627 |
| `scenario_logic_or_context_failure` | 15 | 30 | 0 | 0.333 | 1.000 | 0.500 |
| `prompt_ux_problem` | 19 | 18 | 4 | 0.514 | 0.826 | 0.633 |
| `operator_friction` | 29 | 8 | 1 | 0.784 | 0.967 | 0.866 |
| `language_mismatch` | 6 | 6 | 3 | 0.500 | 0.667 | 0.571 |
| `asr_suspected` | 9 | 17 | 1 | 0.346 | 0.900 | 0.500 |
| `no_progress_loop` | 8 | 38 | 2 | 0.174 | 0.800 | 0.286 |
