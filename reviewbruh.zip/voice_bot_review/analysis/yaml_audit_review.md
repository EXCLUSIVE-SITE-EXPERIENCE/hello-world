# YAML audit verification and focused additions

## Scope and confidence

Verified all 170 active scenario YAMLs, `intent_config_v23.json`, the three generated audit JSONs, the supplied dialog-engine core, November aggregates, and only the annotated/raw calls needed for the requested checks. No production file or audit script was changed.

The production calls are from **v2.2.123**, while the supplied engine may be older. Accordingly:

- **YAML/config fact** means deterministic for the supplied active snapshot.
- **Supplied-source risk** means proven for the supplied code, but requiring a source-parity check before being called a v2.2.123 defect.
- November values are **client-turn counts**, not call counts, loop counts, or quality judgments.

Paths below are relative to:

- `YAML = D:\Halyk\Verigram\data\intents_and_scenarios_in_use\scenarios_in_use`
- `CORE = D:\Halyk\Decode\projects\verigram-voicebot-standalone\extracted\verigram-voicebot-standalone\dialogengine\src\dialogengine\core`
- `ANALYSIS = D:\Halyk\Decode\voice_bot_review\analysis`

## 1. Corrected `>>target|resume_state` semantics: confirmed

The corrected interpretation is right for the supplied engine:

1. `CORE\engine.py:46-52` splits `>>target|resume_state` and calls `context.enter_scenario(target, resume_state=resume_state)` without overriding `start_state`.
2. `CORE\managers.py:83-87` first updates the **current/source** stack frame to `resume_state`, then pushes the target scenario at **`start`**.
3. `CORE\dialog_context.py:147-151` delegates to exactly that stack operation.

Thus `>>03_07_credit_closing_certificate|what_can_i_help_you_with` at `00_00_continuity.main` (`00_00_continuity.yaml:277-278`) enters `03_07...__start` and saves `what_can_i_help_you_with` on the continuity/source frame. It does **not** enter the target at `what_can_i_help_you_with`.

Independent static validation reproduced the audit totals: 170 scenarios, 1,113 states, 3,094 flattened rules, 275 cross-scenario rules, 2,180 intent mentions, 1,106 scenario/intent pairs, 225 YAML intent labels, and 136 `continuity.main` cross-scenario routes. All 275 cross-scenario targets exist, all targets have `start`, and every `resume_state` exists in the **source** scenario. The 37 reported entry-intent/self-transition pairs also all exist (35 unique scenarios; two scenarios have two entry labels).

### Audit wording that should be narrowed

- The 37 `entry_intent_self_repeat` records are valid **structural review candidates**, not 37 proven high-severity call failures. A same-intent repetition can be an intentional answer repeat; a different follow-up misclassified as the entry intent is the harmful case. The JSON already says `confidence: medium`, so blanket `severity: high` is stronger than the evidence.
- `scenarios_without_repeat_handler` means **without an explicit YAML repeat condition**, not necessarily without a runtime repeat. The supplied loader injects repeat handling into most ordinary states (`scenario_loader.py:152-183`) and operator/language routes (`:152-190`). Rename the field to `scenarios_without_explicit_yaml_repeat_handler` or document this prominently.
- `thin_scenarios_1_to_3_states` is a valid descriptive list of 53 scenarios, not a defect list. Utility flows such as `00_03_operator` and `00_04_language_switch` should not be remediation candidates merely for being thin.
- `_audit_raw.json` calls the two nested transition lists in `00_06_reask_before_operator` “malformed”; they are valid for the supplied loader, which deliberately flattens nested lists (`scenario_loader.py:128-139`). Do not report them as syntax/runtime errors.
- For the three unreferenced model labels, the fact of no positive YAML reference is correct. The recommendation to remove them “to reduce argmax competition” is not supported by the supplied NLU: it takes argmax only over state/main candidate subsets (`nlu_service.py:361-395`), and an unreferenced label is not in those subsets. Do not edit `id2label`/`label2id` independently of the trained model.

## 2. Addition: OR alternatives omitted by the supplied `MainIntentManager`

**Supplied-source risk, with exact YAML exposure.** `main_intent_manager.py:67` compiles the intent regex, but `:72-98` performs one `search` per transition and registers only that first label. The YAML has **136** `main` cross-scenario transitions containing **157 distinct intent alternatives**. The supplied loader would register 136 and omit the following 21; none is registered by another `main` cross-scenario transition.

Counts in parentheses are November `client_intent_counts`; they indicate priority, not proven failed interruptions.

| `00_00_continuity.yaml` | Target and source resume | Second/later labels omitted by the supplied loader |
|---|---|---|
| `:359-360` | `03_06_new_credit|resume` | `cash_credit` (8,860) |
| `:389-390` | `07_01_applying_for_ipoteka|resume` | `halyk_sale` (4), `bazis_a` (0), `bi_group` (89), `halyk_ipoteka` (127) |
| `:397-398` | `07_05_where_to_consult_car_loan|resume` | `digital_avtokredit` (31), `avtokredit` (497) |
| `:401-402` | `08_02_international_transfer|resume` | `send_western_union_transfer` (90), `uz_transfer` (31), `receive_swift_transfer` (636), `receive_western_union_transfer` (78), `international_transfer` (592) |
| `:403-404` | `08_03_what_limit|resume` | `limit__ne_prohodit_perevod` (292) |
| `:405-406` | `08_05_how_transfer|resume` | `transfer_by_phone_number` (601), `halyk_client` (473), `other_bank_general` (529), `account_transfer` (984) |
| `:417-418` | `09_06_deposit_open|resume` | `deposit__zakrit` (185) |
| `:523-524` | `20_04_card_contactless_binding_issue|resume` | `apple_pay` (147), `google_pay` (20), `samsung_pay` (4) |

Why the scope matters:

- At `continuity.main` itself, the explicit YAML OR conditions still work. `scenario_loader.py:197-224` uses `findall` for state-intent candidates, and normal transition evaluation checks the whole OR expression. This finding must **not** be described as “these intents cannot enter from main.”
- Away from main, `engine.py:217-227` supplies `MainIntentManager.get_intent_list()` as the main-intent NLU candidates. `nlu_service.py:379-422` scores only that registry, and `main_intent_manager.py:120-162` also requires registry membership for interruption. An omitted label therefore cannot win as a main interruption in the supplied implementation unless a separate/local route handles it.
- The 50 annotations do not expose the manager registry and cannot establish whether v2.2.123 has fixed this. Direct entries through `continuity.main` are not counterevidence.

## 3. Addition: main-intent interruption discards suspended stack frames

**Supplied-source behavior.** After no specific local transition matches (`engine.py:446-476`), `_handle_main_intent_interruption`:

- pops every non-root frame with `while stack.size() > 1` (`engine.py:540-543`);
- enters the target at `start`, applying the main route's `resume_state` to the remaining root frame (`:544-553` and `managers.py:83-87`).

For a stack `root -> service A -> identification B -> new target C`, both B and A are removed. C's eventual `<<` can return only to the root resume/main flow, not to B or A. This loses the **scenario-stack continuation**, including a partially completed identification/service flow. It does not clear `context.data`, transcript history, or user utterances; “all context is erased” would be an overclaim.

Two guards are relevant:

- Main interruption is attempted only after specific local transitions fail (`engine.py:446-476`).
- `MainIntentManager.should_interrupt` suppresses interruption if the target scenario is already anywhere in the stack (`main_intent_manager.py:124-162`), so same-scenario re-entry is not the concern here.

### Readily available call evidence

The annotations/raw turns are **consistent with context replacement**, but contain no stack dump and do not prove that v2.2.123 executed this exact unwind:

- **S9**, `bc55dcf2-3075-437c-9f07-c38c6bf02c8a`, 16:50:43: `25_15_recipient_not_received__start` jumped to `25_05_card_refund_timing__start` on the misclassified confirmation “да не поступили”; the original nonreceipt confirmation was not resumed.
- **S46**, `b315c51e-63fd-44fa-9fa7-72ead7859e67`, 13:37:51: `03_08_change_payment_date__start` jumped to `25_09_update_personal_data__start` on a deictic follow-up, replacing the payment-date continuation with unrelated branch-visit advice.
- **S16**, `ea3dcfe9-9de0-4f71-bf00-c47d52ef6dd1`: `25_15.start -> confirmation__20_05.start` at 14:48:41, then `25_15.start` again at 14:48:51 after a new `recipient_not_received` classification. This is compatible with a fresh start rather than restoration of the suspended frame.

I found no annotation that directly proves unwinding of a **nested** stack. Treat these as regression cases, not code-version proof.

A safe remediation needs an explicit interruption/resumption policy. Merely deleting the unwind loop is unsafe: main-route values such as `resume` and `what_can_i_help_you_with` belong to continuity and need not exist in an arbitrary interrupted source scenario. Preserve suspended frames/return states separately, or define per-source valid resume mappings.

## 4. Addition: continuity can survey before service, and its survey accepts non-ratings

**YAML fact and observed-call failure.**

- `00_00_continuity.yaml:535-538` sends bare `disagree` or `dont_know` from `main` directly to `score_the_conversation`; there is no completed-service guard.
- `score_the_conversation` disables cross-scenario interruption and has only `True == True -> thanks_for_score` (`:621-637`). `thanks_for_score` then goes immediately to `goodbye` (`:638-653`). No 1–5/digits validation is declared.
- In the supplied engine, this catch-all accepts **any turn that reaches transition selection**, not literally every possible input: silence and low-confidence NLU fallback are handled earlier (`engine.py:181-185`, `:413-418`), and specific operator handling can precede the default. Nevertheless, no rating intent/value is required.
- The same catch-all pattern occurs in all **41** scenarios that declare a `score_the_conversation` state, so regression coverage should include the shared clones as well as continuity.

Direct annotated evidence:

- **S47** (`3f7c2ece-2d6d-40bd-ab48-6e2706844700`): the opening operator request was classified `disagree` and produced a survey before any service; a later operator turn retained survey context.
- **S48** (`03ef1857-660b-4a14-a836-b7d0a3480c08`): “не знаю звонили я поэтому перезваниваю” triggered a pre-service survey; “пять пять” was logged `unknown` yet accepted with thanks/goodbye.
- **S50** (`dce2446b-62a7-4451-a03d-8fe4c3231993`): a Kazakh app-launch complaint was reduced to `dont_know`, causing a survey and eventual silence hangup without addressing the app problem.

November has 6,570 client turns attributed to `00_00_continuity__score_the_conversation` (including 3,599 `disagree`, 706 `dont_know`, 1,895 silence, and 370 operator requests). This establishes volume, not the number of unjustified surveys.

## 5. `other_bank`: exact missing label, but not a wholly impossible branch

The critical issue is correct only in its narrow form:

- `22_01_push_checking.yaml:49-50`, state `ask_how_to_help`, has `intent == "otherway" or intent == "other_bank" -> explain_alternative_payment_methods`.
- The active v23 config contains `other_bank_general` and `otherway` (`intent_config_v23.json:105-106`) but no exact `other_bank` in `intent_names`, `id2label`, or `label2id`. The supplied NLU skips state candidates absent from `label2id` (`nlu_service.py:361-377`).

Therefore the **`other_bank` disjunct is unproducible from this model snapshot**, but the transition remains reachable through `otherway`. The audit phrase “remove/replace the impossible transition” overstates the blast radius, and `critical` is not justified statically for the whole alternative-payment route. Prefer testing `other_bank_general` as the replacement/alias for this state, or deliberately add/train `other_bank` if a distinct class is required.

Related label cleanup: both `prosroch_zadol__minimalni` and `prosroch_zadol_minimalni` exist in v23, but only the double-underscore form is wired (`22_01_push_checking.yaml:65-66`). `are_you_robot` and `what_is_your_name` have only commented-out special handlers (`__extra.yaml:1-14`). These three unreferenced labels, and the wired double-underscore minimal-payment label, each have zero appearances in November `client_intent_counts`; this supports review, not hasty config deletion.

## 6. Data-informed scenario priority

### First self-repeat replay/sample set

The following are the largest `__start` state volumes among the 37 findings. “Entry-label turns” includes initial entry and possible repeats; it is **not** a measured self-loop count.

| State | Start turns | Entry-label turns at start | Unknown turns (rate) |
|---|---:|---:|---:|
| `26_05_insurance_info__start` | 7,151 | `insurance_info`: 4,757 | 1,507 (21.1%) |
| `25_05_card_refund_timing__start` | 2,255 | `card_refund_timing`: 1,239 | 775 (34.4%) |
| `25_04_transfer_history__start` | 1,955 | `transfer_history`: 1,081 | 579 (29.6%) |
| `25_08_atm_cash_limit__start` | 1,901 | `atm_cash_limit`: 1,133 | 515 (27.1%) |
| `26_06_new_credit_status__start` | 1,839 | `new_credit_status`: 1,040 | 544 (29.6%) |
| `25_07_deposit_withdrawal__start` | 1,753 | `deposit_withdrawal`: 1,079 | 460 (26.2%) |
| `25_03_forgot_app_password__start` | 1,276 | `forgot_app_password`: 666 | 438 (34.3%) |
| `25_19_sms_push_banking__start` | 1,185 | `sms_push_banking`: 665 | 323 (27.3%) |
| `25_06_sms_code_not_received__start` | 1,145 | `sms_code_not_received`: 586 | 340 (29.7%) |
| `26_23_card_requisites__start` | 1,014 | `card_requisites_info`: 548; `get_card_requisites`: 0 in top intents | 299 (29.5%) |

Start with turn-pair replay around repeated labels and unknowns; split initial answer, a concise intentional repeat, and context-sensitive follow-ups only where calls demonstrate a problem. S10 supports a targeted insurance improvement (auto versus life), while S46 supports stepped payment-date guidance rather than replaying the whole answer.

### High-volume thin scenarios not captured by the 37 self-repeat findings

- **P1 — `03_06_new_credit__start`:** 4,779 turns, including 2,952 `cash_credit`, 281 `new_credit`, 807 silence, and 705 operator turns. YAML has only `repeat -> start`, then catch-all `<<` (`03_06_new_credit.yaml:21-25`). It is the highest-volume thin scenario and is also affected by the `cash_credit` main-registry omission.
- **P1 — `24_04_hsa_certificates__start`:** 1,615 turns, 972 `hsa_certificates`, and 384 unknown (23.8%). YAML has repeat/agree/disagree/dont_know but no `hsa_certificates` recovery (`24_04_hsa_certificates.yaml:34-40`). S43 shows irrelevant certificate entry followed by repeated fallback and loss of the missing-money goal.
- **P1/P2 — `02_03_check_balance__start`:** 1,074 turns, 668 `check_balance`, and 275 unknown (25.6%). Its explicit routes cover agree/unable/not_now/disagree (`02_03_check_balance.yaml:22-27`); repeat exists only through supplied-loader injection, so production-parity testing matters before calling it missing.
- **P2 — `07_04_how_to_apply_refinance__start`:** 1,932 turns and 1,731 `ipoteka__refinans`, but zero logged unknown. It has agree/repeat and catch-all exits (`07_04_how_to_apply_refinance.yaml:22-27`, `:43-46`). High volume alone does not justify redesign.
- **P2 — `05_02_change_trusted_number__start`:** 951 turns and zero logged unknown; repeat plus catch-all exit (`05_02_change_trusted_number.yaml:21-25`). Review only after the states with observed contextual failures/high unknown rates.

## Recommendations

### P0

1. **Gate continuity surveys on actual service completion and validate a score.** Keep legitimate post-service `disagree` behavior, but add a `survey_eligible/service_completed` condition so initial or unresolved `main` disagreement/dont_know gets clarification or operator handling instead. Require a parsed 1–5 rating before thanks/goodbye; otherwise reask, allow skip, or transfer. Cover S47/S48/S50 and the 41 cloned survey states.
2. **Make the OR-registry check a v2.2.123 release gate.** Inspect the actual production source. If it still uses one `search`, iterate all intent matches and register every alternative with the same target/resume. Add regression assertions for all 157 current main cross-scenario labels, especially `cash_credit`, `account_transfer`, `international_transfer`, and `other_bank_general`, then rerun NLU threshold/priority tests because the main candidate set changes.

### P1

1. **Test and repair interruption continuation deliberately.** In v2.2.123, replay root-service, root-service-identification, and root-service-subscenario interruptions through target completion. Preserve/restore suspended frames or document an intentional reset; never apply a continuity-only resume name to an arbitrary source scenario. Use S9/S16/S46 as acceptance cases plus one genuinely nested stack test with stack assertions.
2. **Fix `22_01_push_checking.ask_how_to_help`’s missing `other_bank` label.** Prefer the existing semantically appropriate `other_bank_general` after RU/KZ regression tests, or add a real trained class. Retain `otherway` meanwhile; do not remove the whole alternative-payment transition.
3. **Remediate self-repeats by observed follow-up failure, not by count alone.** Start with the table above, prioritizing high unknown plus volume (`25_05`, `25_03`, `25_04`, `25_06`, `26_06`) and observed S10/S46 patterns. Preserve a short intentional repeat and the operator escape.
4. **Add the two high-priority thin cases to regression tests:** `03_06` for both `new_credit` and `cash_credit` entry/follow-up/interruption, and `24_04` for rejection/return to the original missing-money context (S43).

### P2

1. **Tighten audit semantics and severity labels:** rename the repeat-handler field, mark nested transitions as supported, keep thin/unreachable/self-repeat lists explicitly declarative, and reserve high/critical severity for demonstrated impact. Add an OR-alternative registry check to future static audits.
2. **Resolve duplicate/unused labels as a model-plus-routing decision:** review the single/double `prosroch_zadol_minimalni` pair and the two commented small-talk handlers. Do not delete config labels merely to alter argmax behavior or without preserving model index alignment.
3. **Keep low-evidence thin scenarios in watch status.** `07_04`, `05_02`, and utility scenarios should not displace the demonstrated survey, OR-routing, interruption, and high-unknown work.
