# November 2026 call sample

Deterministic seed: 20261118. 50 calls: 8 random baseline plus targeted service, unknown, repetition, language, multi-topic, and unresolved strata. This is an evaluation/discovery sample, not a representative prevalence sample. Long digit sequences are redacted in this derived file only.

## SAMPLE 26 | CALL 85493 | 2026-11-07 11:41:18 | 54012928-4f94-45ce-b7e5-ed6992441a33

Stratum: unknown_without_service | client turns: 3 | unknown-content turns: 1 | silence: 0 | repeated bot events: 0 | services: none | language mismatches: 0

```text
=== CALL 85493 | 2026-11-07 11:41:18 | 54012928-4f94-45ce-b7e5-ed6992441a33 ===
[11:41:20] dialog_step=00_00_continuity__main | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[11:41:33] dialog_step=00_00_continuity__main | intent=talk_to_operator
CLIENT: можно оператора
[11:41:33] dialog_step=00_00_continuity__main | intent=talk_to_operator
BOT: Уважаемый клиент, чтобы не тратить ваше время на переключение, давайте попробуем решить вопрос здесь. Если потребуется специалист, я подключу.
Скажите, чем я могу вам помочь?
[11:41:49] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
CLIENT: дайте оператора
[11:41:49] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
BOT: Сейчас я переведу вас на оператора. Подскажите, пожалуйста, причину обращения, чтобы я мог направить вас к нужному специалисту.
[11:42:03] dialog_step=unknown | intent=unknown
CLIENT: номер карты без карты
[11:42:04] dialog_step=unknown | intent=card_requisites_info
BOT: Хорошо, переключаю звонок на специалиста, оставайтесь на линии.
```

## SAMPLE 27 | CALL 86479 | 2026-11-07 12:48:59 | 8d6759f9-095c-47db-a41b-f9fa2cc97144

Stratum: unknown_without_service | client turns: 4 | unknown-content turns: 1 | silence: 0 | repeated bot events: 0 | services: none | language mismatches: 0

```text
=== CALL 86479 | 2026-11-07 12:48:59 | 8d6759f9-095c-47db-a41b-f9fa2cc97144 ===
[12:48:59] dialog_step=00_00_continuity__main | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[12:49:09] dialog_step=00_00_continuity__main | intent=talk_to_operator
CLIENT: соедините с оператором
[12:49:09] dialog_step=00_00_continuity__main | intent=talk_to_operator
BOT: Уважаемый клиент, чтобы не тратить ваше время на переключение, давайте попробуем решить вопрос здесь. Если потребуется специалист, я подключу.
Скажите, чем я могу вам помочь?
[12:49:25] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
CLIENT: соедините с оператором
[12:49:25] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
BOT: Сейчас я переведу вас на оператора. Подскажите, пожалуйста, причину обращения, чтобы я мог направить вас к нужному специалисту.
[12:49:38] dialog_step=00_06_reask_before_operator__second_ask | intent=unknown
CLIENT: по поводу снятия со счета денег
[12:49:38] dialog_step=00_06_reask_before_operator__second_ask | intent=unknown
BOT: Общая линия сейчас перегружена и ожидание может занять длительное время. Чтобы перевести вас на свободного оператора, мне нужно знать причину вашего обращения.
[12:49:55] dialog_step=unknown | intent=check_balance
CLIENT: по поводу денег на счетах на счету
[12:49:55] dialog_step=unknown | intent=check_balance
BOT: Хорошо, переключаю звонок на специалиста, оставайтесь на линии.
```

## SAMPLE 28 | CALL 109337 | 2026-11-09 18:05:56 | cb356a18-6bf8-4211-969b-5e7163276aa6

Stratum: unknown_without_service | client turns: 5 | unknown-content turns: 2 | silence: 0 | repeated bot events: 0 | services: none | language mismatches: 0

```text
=== CALL 109337 | 2026-11-09 18:05:56 | cb356a18-6bf8-4211-969b-5e7163276aa6 ===
[18:05:57] dialog_step=00_00_continuity__language_ask | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Айтыңызшы, сізге қай тіл ыңғайлы болады - қазақ немесе орыс тілдерінде? Скажите, пожалуйста, на каком языке вам будет удобнее - на казахском или русском?
[18:06:15] dialog_step=00_00_continuity__main | intent=change_lang_kz
CLIENT: қазақ тілі
[18:06:15] dialog_step=00_00_continuity__main | intent=change_lang_kz
BOT: Сәлеметсіз бе! Мен виртуалды көмекшімін, есімім Айдос. Қандай көмегім керек?
[18:06:24] dialog_step=00_00_continuity__main | intent=talk_to_operator
CLIENT: оператормен байланыстырыңыз
[18:06:24] dialog_step=00_00_continuity__main | intent=talk_to_operator
BOT: Құрметті клиент, уақытыңызды үнемдеу үшін, сұрағыңызды осы жерде шешуге тырысайық. Қажет болса, маманға қосамын.
Айтыңызшы, мен сізге қалай көмектесе аламын?
[18:06:39] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
CLIENT: оператормен байланыстырыңыз
[18:06:39] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
BOT: Қазір сізді операторға қосамын. Қажетті маманға бағыттауым үшін хабарласу себебін айтыңызшы.
[18:06:48] dialog_step=00_06_reask_before_operator__second_ask | intent=unknown
CLIENT: карталарға байланысты
[18:06:48] dialog_step=00_06_reask_before_operator__second_ask | intent=unknown
BOT: Қазіргі уақытта байланыс желісі шамадан тыс жүктелген және күту ұзаққа созылуы мүмкін. Сізді бос операторға қосу үшін хабарласу себебіңізді білуім керек.
[18:07:05] dialog_step=unknown | intent=unknown
CLIENT: карталарға байланысты
[18:07:05] dialog_step=unknown | intent=unknown
BOT: Жақсы, қоңырауды операторға қосамын, желіден ажырамаңыз.
```

## SAMPLE 29 | CALL 123137 | 2026-11-10 17:11:23 | 10985f42-d072-4f74-a0eb-c60d2b95a5c4

Stratum: unknown_without_service | client turns: 6 | unknown-content turns: 4 | silence: 0 | repeated bot events: 1 | services: none | language mismatches: 0

```text
=== CALL 123137 | 2026-11-10 17:11:23 | 10985f42-d072-4f74-a0eb-c60d2b95a5c4 ===
[17:11:23] dialog_step=00_00_continuity__language_ask | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Айтыңызшы, сізге қай тіл ыңғайлы болады - қазақ немесе орыс тілдерінде? Скажите, пожалуйста, на каком языке вам будет удобнее - на казахском или русском?
[17:11:40] dialog_step=unknown | intent=unknown
CLIENT: қазақ тілі
[17:11:42] dialog_step=00_00_continuity__main | intent=change_lang_kz
BOT: Сәлеметсіз бе! Мен виртуалды көмекшімін, есімім Айдос. Қандай көмегім керек?
[17:11:51] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: айдос ассалаумалейкум
[17:11:51] dialog_step=00_00_continuity__main | intent=unknown
BOT: Мен сізді толық түсінбедім, қайтадан басқаша айтып бересіз бе?
[17:11:58] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: айдос ассалаумалейкум
[17:11:58] dialog_step=00_00_continuity__main | intent=unknown
BOT: Мен сізді толық түсінбедім, қайтадан басқаша айтып бересіз бе?
[17:12:06] dialog_step=00_06_reask_before_operator__first_ask | intent=unknown
CLIENT: айдос ассалаумалейкум
[17:12:06] dialog_step=00_06_reask_before_operator__first_ask | intent=unknown
BOT: Қазір сізді операторға қосамын. Қажетті маманға бағыттауым үшін хабарласу себебін айтыңызшы.
[17:12:17] dialog_step=00_06_reask_before_operator__second_ask | intent=talk_to_operator
CLIENT: операторды қосыңызшы маған
[17:12:17] dialog_step=00_06_reask_before_operator__second_ask | intent=talk_to_operator
BOT: Қазіргі уақытта байланыс желісі шамадан тыс жүктелген және күту ұзаққа созылуы мүмкін. Сізді бос операторға қосу үшін хабарласу себебіңізді білуім керек.
[17:12:38] dialog_step=unknown | intent=card_requisites_info
CLIENT: мен сұрайын дегенім мына реквизиты деген дегені бар ғой неде халық приложениеде соны біреулерге жіберуге бола ма
[17:12:38] dialog_step=unknown | intent=card_requisites_info
BOT: Жақсы, қоңырауды операторға қосамын, желіден ажырамаңыз.
```

## SAMPLE 30 | CALL 150165 | 2026-11-12 16:44:25 | 66b94fbd-a4bd-422e-8698-673014b33420

Stratum: unknown_without_service | client turns: 5 | unknown-content turns: 1 | silence: 1 | repeated bot events: 1 | services: none | language mismatches: 0

```text
=== CALL 150165 | 2026-11-12 16:44:25 | 66b94fbd-a4bd-422e-8698-673014b33420 ===
[16:44:26] dialog_step=00_00_continuity__main | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[16:44:41] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: алло здравствуйте мне колл центр подключайте
[16:44:41] dialog_step=00_00_continuity__main | intent=unknown
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[16:44:47] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: включайте
[16:44:47] dialog_step=00_00_continuity__main | intent=unknown
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[16:44:56] dialog_step=00_00_continuity__main | intent=silence
CLIENT: <SILENCE>
[16:44:56] dialog_step=00_00_continuity__main | intent=silence
BOT: Я вас не расслышал, повторите, пожалуйста.
[16:45:02] dialog_step=00_06_reask_before_operator__first_ask | intent=unknown
CLIENT: алло
[16:45:02] dialog_step=00_06_reask_before_operator__first_ask | intent=unknown
BOT: Сейчас я переведу вас на оператора. Подскажите, пожалуйста, причину обращения, чтобы я мог направить вас к нужному специалисту.
[16:45:14] dialog_step=unknown | intent=deposit__otkrit
CLIENT: я хотела узнать про депозит
[16:45:14] dialog_step=unknown | intent=deposit__otkrit
BOT: Хорошо, переключаю звонок на специалиста, оставайтесь на линии.
```

## SAMPLE 31 | CALL 12998 | 2026-11-02 14:42:01 | 0fb73ad9-92ad-43de-9a49-b52f92590f33

Stratum: repetition_or_stuck | client turns: 8 | unknown-content turns: 0 | silence: 1 | repeated bot events: 1 | services: 05_01_unblock_app, 09_01_unblocking_card, 01_02_why_card_blocked | language mismatches: 0

```text
=== CALL 12998 | 2026-11-02 14:42:01 | 0fb73ad9-92ad-43de-9a49-b52f92590f33 ===
[14:42:01] dialog_step=00_00_continuity__main | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[14:42:13] dialog_step=00_00_continuity__main | intent=talk_to_operator
CLIENT: соедините с оператором
[14:42:13] dialog_step=00_00_continuity__main | intent=talk_to_operator
BOT: Уважаемый клиент, чтобы не тратить ваше время на переключение, давайте попробуем решить вопрос здесь. Если потребуется специалист, я подключу.
Скажите, чем я могу вам помочь?
[14:42:31] dialog_step=confirmation__05_01_unblock_app__start | intent=unblock_app
CLIENT: заблокировался
[14:42:31] dialog_step=confirmation__05_01_unblock_app__start | intent=unblock_app
BOT: Я правильно понял, что вы хотите разблокировать приложение?
[14:42:37] dialog_step=confirmation__09_01_unblocking_card__start | intent=razblock_card__razblock
CLIENT: разблокировать
[14:42:37] dialog_step=confirmation__09_01_unblocking_card__start | intent=razblock_card__razblock
BOT: Я правильно понял, что вы хотите разблокировать карту?
[14:42:46] dialog_step=confirmation__09_01_unblocking_card__start | intent=silence
CLIENT: <SILENCE>
[14:42:46] dialog_step=confirmation__09_01_unblocking_card__start | intent=silence
BOT: Я правильно понял, что вы хотите разблокировать карту?
[14:42:54] dialog_step=09_01_unblocking_card__ask_identification_for_details | intent=agree
CLIENT: да правильно понял
[14:42:54] dialog_step=09_01_unblocking_card__ask_identification_for_details | intent=agree
BOT: Если Ваша карта временно заблокирована, Вы можете самостоятельно снять блокировку, воспользовавшись приложением Халык. Для этого Вам нужно в разделе "Мой банк" - выбрать Вашу карту - нажать на "Блокировки" - далее выключить функцию "Временная блокировка".
Чтобы получить более подробную информацию, нужно пройти идентификацию личности. Хотите её пройти?
[14:43:22] dialog_step=confirmation__01_02_why_card_blocked__start | intent=why_card_blocked
CLIENT: меня заблокировал банк карту
[14:43:22] dialog_step=confirmation__01_02_why_card_blocked__start | intent=why_card_blocked
BOT: Я правильно понял, что вы хотите узнать причину блокировки карты?
[14:43:34] dialog_step=00_01_identification__greeting | intent=why_card_blocked
CLIENT: я увидел причину мне написано что карта заблокирована банком и надо обратиться в банк
[14:43:34] dialog_step=00_01_identification__greeting | intent=why_card_blocked
BOT: Уважаемый клиент, для предоставления ответа на Ваш вопрос необходимо пройти идентификацию личности по цифровому документу, если Вы согласны я подскажу куда заходить.
[14:43:49] dialog_step=unknown | intent=talk_to_operator
CLIENT: соедините с оператором
[14:43:49] dialog_step=unknown | intent=talk_to_operator
BOT: Хорошо, переключаю звонок на специалиста, оставайтесь на линии.
```

## SAMPLE 32 | CALL 22537 | 2026-11-03 11:00:38 | 63e40ab4-e0ea-42c6-8084-7c0ec75cd89c

Stratum: repetition_or_stuck | client turns: 4 | unknown-content turns: 2 | silence: 0 | repeated bot events: 1 | services: none | language mismatches: 0

```text
=== CALL 22537 | 2026-11-03 11:00:38 | 63e40ab4-e0ea-42c6-8084-7c0ec75cd89c ===
[11:00:39] dialog_step=00_00_continuity__main | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[11:00:56] dialog_step=unknown | intent=unknown
CLIENT: каспи банкке ограничение қойылған соған соны ашуға рұқсат беруін сұраймын
[11:00:57] dialog_step=00_00_continuity__main | intent=unknown
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[11:01:10] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: каспи банкке ограничение қойылған народныйдан соны ашуға рұқсат берулеріңізді сұраймын
[11:01:10] dialog_step=00_00_continuity__main | intent=unknown
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[11:01:17] dialog_step=00_00_continuity__main | intent=talk_to_operator
CLIENT: операторға қосыңызшы
[11:01:17] dialog_step=00_00_continuity__main | intent=talk_to_operator
BOT: Уважаемый клиент, чтобы не тратить ваше время на переключение, давайте попробуем решить вопрос здесь. Если потребуется специалист, я подключу.
Скажите, чем я могу вам помочь?
[11:01:32] dialog_step=unknown | intent=talk_to_operator
CLIENT: операторға қосыңыз
[11:01:32] dialog_step=unknown | intent=talk_to_operator
BOT: Хорошо, переключаю звонок на специалиста, оставайтесь на линии.
```

## SAMPLE 33 | CALL 60921 | 2026-11-05 16:10:58 | 5a7243c5-0457-42c5-95dc-7a02405ad5ef

Stratum: repetition_or_stuck | client turns: 7 | unknown-content turns: 5 | silence: 0 | repeated bot events: 1 | services: none | language mismatches: 0

```text
=== CALL 60921 | 2026-11-05 16:10:58 | 5a7243c5-0457-42c5-95dc-7a02405ad5ef ===
[16:10:58] dialog_step=00_00_continuity__main | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[16:11:08] dialog_step=00_00_continuity__main | intent=change_lang_kz
CLIENT: қазақша
[16:11:08] dialog_step=00_00_continuity__main | intent=change_lang_kz
BOT: Сәлеметсіз бе! Мен виртуалды көмекшімін, есімім Айдос. Қандай көмегім керек?
[16:11:15] dialog_step=00_00_continuity__main | intent=talk_to_operator
CLIENT: оператор
[16:11:15] dialog_step=00_00_continuity__main | intent=talk_to_operator
BOT: Құрметті клиент, уақытыңызды үнемдеу үшін, сұрағыңызды осы жерде шешуге тырысайық. Қажет болса, маманға қосамын.
Айтыңызшы, мен сізге қалай көмектесе аламын?
[16:11:28] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: ақшаның қанша түскенін білу керек
[16:11:28] dialog_step=00_00_continuity__main | intent=unknown
BOT: Мен сізді толық түсінбедім, қайтадан басқаша айтып бересіз бе?
[16:11:35] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: ақшаның қанша түскенін білу керек
[16:11:35] dialog_step=00_00_continuity__main | intent=unknown
BOT: Мен сізді толық түсінбедім, қайтадан басқаша айтып бересіз бе?
[16:11:42] dialog_step=00_06_reask_before_operator__first_ask | intent=unknown
CLIENT: ақшаның қанша түскенін білу керек
[16:11:42] dialog_step=00_06_reask_before_operator__first_ask | intent=unknown
BOT: Қазір сізді операторға қосамын. Қажетті маманға бағыттауым үшін хабарласу себебін айтыңызшы.
[16:11:51] dialog_step=00_06_reask_before_operator__second_ask | intent=unknown
CLIENT: ақшаның түскен қанша түскенін білу керек
[16:11:51] dialog_step=00_06_reask_before_operator__second_ask | intent=unknown
BOT: Қазіргі уақытта байланыс желісі шамадан тыс жүктелген және күту ұзаққа созылуы мүмкін. Сізді бос операторға қосу үшін хабарласу себебіңізді білуім керек.
[16:12:04] dialog_step=unknown | intent=unknown
CLIENT: қанша түскенін білу керек
[16:12:04] dialog_step=unknown | intent=unknown
BOT: Жақсы, қоңырауды операторға қосамын, желіден ажырамаңыз.
```

## SAMPLE 34 | CALL 62893 | 2026-11-05 17:27:38 | 11253dc5-5228-467f-998f-5c45ff4cb401

Stratum: repetition_or_stuck | client turns: 9 | unknown-content turns: 4 | silence: 0 | repeated bot events: 1 | services: none | language mismatches: 0

```text
=== CALL 62893 | 2026-11-05 17:27:38 | 11253dc5-5228-467f-998f-5c45ff4cb401 ===
[17:27:38] dialog_step=00_00_continuity__main | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[17:27:52] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: менде толы кездер бар да
[17:27:52] dialog_step=00_00_continuity__main | intent=unknown
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[17:27:59] dialog_step=00_00_continuity__main | intent=change_lang_kz
CLIENT: қазақша сөйлеші
[17:27:59] dialog_step=00_00_continuity__main | intent=change_lang_kz
BOT: Сәлеметсіз бе! Мен виртуалды көмекшімін, есімім Айдос. Қандай көмегім керек?
[17:28:10] dialog_step=00_00_continuity__main | intent=agree
CLIENT: о да
[17:28:10] dialog_step=00_00_continuity__main | intent=agree
BOT: Тамаша, сізге қандай көмек керек?
[17:28:16] dialog_step=00_00_continuity__main | intent=talk_to_operator
CLIENT: операторға қосшы операторға
[17:28:16] dialog_step=00_00_continuity__main | intent=talk_to_operator
BOT: Құрметті клиент, уақытыңызды үнемдеу үшін, сұрағыңызды осы жерде шешуге тырысайық. Қажет болса, маманға қосамын.
Айтыңызшы, мен сізге қалай көмектесе аламын?
[17:28:34] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: оның ның ключі флешка жайында ақылдасқым келген
[17:28:34] dialog_step=00_00_continuity__main | intent=unknown
BOT: Мен сізді толық түсінбедім, қайтадан басқаша айтып бересіз бе?
[17:28:45] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: сол кездерде флешканың кодын таппайтырмыз
[17:28:45] dialog_step=00_00_continuity__main | intent=unknown
BOT: Мен сізді толық түсінбедім, қайтадан басқаша айтып бересіз бе?
[17:28:52] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
CLIENT: операторға қосасың ба
[17:28:52] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
BOT: Қазір сізді операторға қосамын. Қажетті маманға бағыттауым үшін хабарласу себебін айтыңызшы.
[17:29:05] dialog_step=00_06_reask_before_operator__second_ask | intent=unknown
CLIENT: то мәселесінде ключ таппайтырмыз
[17:29:05] dialog_step=00_06_reask_before_operator__second_ask | intent=unknown
BOT: Қазіргі уақытта байланыс желісі шамадан тыс жүктелген және күту ұзаққа созылуы мүмкін. Сізді бос операторға қосу үшін хабарласу себебіңізді білуім керек.
[17:29:20] dialog_step=unknown | intent=withdraw_without_card
CLIENT: флешканың кодын таппай жатырмын
[17:29:20] dialog_step=unknown | intent=withdraw_without_card
BOT: Жақсы, қоңырауды операторға қосамын, желіден ажырамаңыз.
```

## SAMPLE 35 | CALL 124149 | 2026-11-10 17:56:07 | 085b78db-4d99-4f1d-840b-5a04d1240ac9

Stratum: repetition_or_stuck | client turns: 7 | unknown-content turns: 3 | silence: 1 | repeated bot events: 2 | services: none | language mismatches: 0

```text
=== CALL 124149 | 2026-11-10 17:56:07 | 085b78db-4d99-4f1d-840b-5a04d1240ac9 ===
[17:56:08] dialog_step=00_00_continuity__main | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[17:56:21] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: алло саламатсыз ба алло
[17:56:21] dialog_step=00_00_continuity__main | intent=unknown
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[17:56:30] dialog_step=00_00_continuity__main | intent=silence
CLIENT: <SILENCE>
[17:56:30] dialog_step=00_00_continuity__main | intent=silence
BOT: Я вас не расслышал, повторите, пожалуйста.
[17:56:39] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: менеджерге қосыңыз мен орысша түсінбеймін
[17:56:39] dialog_step=00_00_continuity__main | intent=unknown
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[17:56:46] dialog_step=00_00_continuity__main | intent=talk_to_operator
CLIENT: қосыңыз консультация керек маған
[17:56:46] dialog_step=00_00_continuity__main | intent=talk_to_operator
BOT: Уважаемый клиент, чтобы не тратить ваше время на переключение, давайте попробуем решить вопрос здесь. Если потребуется специалист, я подключу.
Скажите, чем я могу вам помочь?
[17:57:01] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: специалист передсна
[17:57:01] dialog_step=00_00_continuity__main | intent=unknown
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[17:57:15] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
CLIENT: подключите специалисту консультация надо вы что издеваетесь что ли
[17:57:15] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
BOT: Сейчас я переведу вас на оператора. Подскажите, пожалуйста, причину обращения, чтобы я мог направить вас к нужному специалисту.
[17:57:29] dialog_step=unknown | intent=cash_credit
CLIENT: насчет кредита хотела узнать
[17:57:29] dialog_step=unknown | intent=cash_credit
BOT: Хорошо, переключаю звонок на специалиста, оставайтесь на линии.
```

## SAMPLE 36 | CALL 145410 | 2026-11-12 12:31:19 | 8fb9c9c3-8472-4058-b17a-4b05681c7264

Stratum: repetition_or_stuck | client turns: 6 | unknown-content turns: 1 | silence: 0 | repeated bot events: 1 | services: 08_05_how_transfer | language mismatches: 0

```text
=== CALL 145410 | 2026-11-12 12:31:19 | 8fb9c9c3-8472-4058-b17a-4b05681c7264 ===
[12:31:20] dialog_step=00_00_continuity__main | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[12:31:31] dialog_step=00_00_continuity__main | intent=talk_to_operator
CLIENT: соедините с оператором
[12:31:31] dialog_step=00_00_continuity__main | intent=talk_to_operator
BOT: Уважаемый клиент, чтобы не тратить ваше время на переключение, давайте попробуем решить вопрос здесь. Если потребуется специалист, я подключу.
Скажите, чем я могу вам помочь?
[12:31:46] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
CLIENT: соедините с оператором
[12:31:46] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
BOT: Сейчас я переведу вас на оператора. Подскажите, пожалуйста, причину обращения, чтобы я мог направить вас к нужному специалисту.
[12:31:57] dialog_step=08_05_how_transfer__start | intent=platezhi__kak_sovershit
CLIENT: переводы
[12:31:57] dialog_step=08_05_how_transfer__start | intent=platezhi__kak_sovershit
BOT: Дорогой клиент, пожалуйста, подскажите, какой перевод вы совершаете? §
[12:32:06] dialog_step=08_05_how_transfer__start | intent=unknown
CLIENT: международный
[12:32:06] dialog_step=08_05_how_transfer__start | intent=unknown
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[12:32:14] dialog_step=08_05_how_transfer__start | intent=unknown
CLIENT: вестерн юнион
[12:32:14] dialog_step=08_05_how_transfer__start | intent=unknown
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[12:32:22] dialog_step=unknown | intent=talk_to_operator
CLIENT: соедините с оператором
[12:32:22] dialog_step=unknown | intent=talk_to_operator
BOT: Хорошо, переключаю звонок на специалиста, оставайтесь на линии.
```

## SAMPLE 37 | CALL 37058 | 2026-11-04 11:08:56 | b5e140e9-bb64-465c-9c69-b54d7908b906

Stratum: language_mismatch_heuristic | client turns: 8 | unknown-content turns: 4 | silence: 0 | repeated bot events: 3 | services: 25_15_recipient_not_received | language mismatches: 1

```text
=== CALL 37058 | 2026-11-04 11:08:56 | b5e140e9-bb64-465c-9c69-b54d7908b906 ===
[11:08:56] dialog_step=00_00_continuity__main | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[11:09:07] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: саламатсыз ба
[11:09:07] dialog_step=00_00_continuity__main | intent=unknown
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[11:09:15] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: перевод перевод жасаған едім
[11:09:15] dialog_step=00_00_continuity__main | intent=unknown
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[11:09:22] dialog_step=00_00_continuity__main | intent=change_lang_kz
CLIENT: қазақша қазақша
[11:09:22] dialog_step=00_00_continuity__main | intent=change_lang_kz
BOT: Сәлеметсіз бе! Мен виртуалды көмекшімін, есімім Айдос. Қандай көмегім керек?
[11:09:31] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: мен жаңағы ана неге
[11:09:31] dialog_step=00_00_continuity__main | intent=unknown
BOT: Мен сізді толық түсінбедім, қайтадан басқаша айтып бересіз бе?
[11:10:00] dialog_step=25_15_recipient_not_received__start | intent=recipient_not_received
CLIENT: перевод жасағанмын ғой перевод сонда каспи депті ана наро банктердің несін таңдамаған екенмін де аударған ақшам шықпай тұр ананаяққа түспей тұр басқа неге нөмірге нөмір тергенде перевод жасап жіберіппін қателесіп ана банкті таңдамағанмын қандай банкке жіберу соны қалай шешеміз енді квитанция ештеңе жоқ шықпай тұр
[11:10:00] dialog_step=25_15_recipient_not_received__start | intent=recipient_not_received
BOT: Нақтылап жіберіңізші, сіз аударым жасадыңыз, ал алушы ақша түспегенін айтып отыр ма?
[11:10:11] dialog_step=25_15_recipient_not_received__answer | intent=recipient_not_received
CLIENT: ақша түспеген мен на банкті таңдамағанмын
[11:10:11] dialog_step=25_15_recipient_not_received__answer | intent=recipient_not_received
BOT: Құрметті клиент, бұл жағдайда орындалған операцияны растау үшін алушыға түбіртекті жібере аласыз. <pause_1> Түбіртекті алу үшін «Аударымдар» бөліміне өтіп, «Тарих» бөліміне өтіңіз. Жасаған аударымыңызды тауып, оны басыңыз. Одан кейін түбіртек көрсетіледі. «Бөлісу» функциясын пайдаланып, чекті алушыға жібере аласыз. <pause_1> Егер алушының деректемелері дұрыс көрсетілсе, қате алушының банкі тарапынан болуы мүмкін. Бұл жағдайда алушы өз банкіне хабарласуы қажет. <pause_1> Қосымша сұрақтарыңыз бар ма?
[11:10:14] dialog_step=25_15_recipient_not_received__answer | intent=unknown
CLIENT: қай банкке жіберу керек
[11:10:14] dialog_step=25_15_recipient_not_received__answer | intent=unknown
BOT: Мен сізді толық түсінбедім, қайтадан басқаша айтып бересіз бе?
[11:10:35] dialog_step=25_15_recipient_not_received__answer | intent=recipient_not_received
CLIENT: перевод номермен жаса жасамай номерін тердім перевод бастым и банк банктен шығу керек екен ғой каспи народный дегенде соны баспағанмын да номерге аударып жібере салғанмын қалай болады ол
[11:10:35] dialog_step=25_15_recipient_not_received__answer | intent=recipient_not_received
BOT: Құрметті клиент, бұл жағдайда орындалған операцияны растау үшін алушыға түбіртекті жібере аласыз. <pause_1> Түбіртекті алу үшін «Аударымдар» бөліміне өтіп, «Тарих» бөліміне өтіңіз. Жасаған аударымыңызды тауып, оны басыңыз. Одан кейін түбіртек көрсетіледі. «Бөлісу» функциясын пайдаланып, чекті алушыға жібере аласыз. <pause_1> Егер алушының деректемелері дұрыс көрсетілсе, қате алушының банкі тарапынан болуы мүмкін. Бұл жағдайда алушы өз банкіне хабарласуы қажет. <pause_1> Қосымша сұрақтарыңыз бар ма?
```

## SAMPLE 38 | CALL 51365 | 2026-11-05 11:28:27 | fd8bcef9-2753-439b-bfd9-77d9ad886443

Stratum: language_mismatch_heuristic | client turns: 4 | unknown-content turns: 0 | silence: 0 | repeated bot events: 0 | services: 09_05_limits_ptp | language mismatches: 1

```text
=== CALL 51365 | 2026-11-05 11:28:27 | fd8bcef9-2753-439b-bfd9-77d9ad886443 ===
[11:28:27] dialog_step=00_00_continuity__language_ask | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Айтыңызшы, сізге қай тіл ыңғайлы болады - қазақ немесе орыс тілдерінде? Скажите, пожалуйста, на каком языке вам будет удобнее - на казахском или русском?
[11:28:42] dialog_step=00_00_continuity__language_ask | intent=silence
BOT: Айтыңызшы, сізге қай тіл ыңғайлы болады - қазақ немесе орыс тілдерінде? Скажите, пожалуйста, на каком языке вам будет удобнее - на казахском или русском?
[11:28:57] dialog_step=00_00_continuity__main | intent=change_lang_ru
CLIENT: орыс тілінде
[11:28:57] dialog_step=00_00_continuity__main | intent=change_lang_ru
BOT: Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[11:29:04] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: народный
[11:29:04] dialog_step=00_00_continuity__main | intent=unknown
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[11:29:14] dialog_step=confirmation__09_05_limits_ptp__start | intent=razblock_card__snyat_ogr
CLIENT: у меня на счету жүріңізші алға на счету арест
[11:29:14] dialog_step=confirmation__09_05_limits_ptp__start | intent=razblock_card__snyat_ogr
BOT: Я правильно понял, что у вас вопрос по ограничениям по карте?
[11:29:20] dialog_step=09_05_limits_ptp__proceed_untrusted_explained | intent=agree
CLIENT: да да
[11:29:20] dialog_step=09_05_limits_ptp__proceed_untrusted_explained | intent=agree
BOT: Дорогой клиент, в случае если Вам выставлено поручение на платеж от банка второго уровня для подробной информаций просим обратится к иницатору Ареста. Также информаю по Арестам Вы можете узнать в приложение Халык в разделе мой банк выбрав карту со статусом счет арестов. <pause_2>
```

## SAMPLE 39 | CALL 69031 | 2026-11-06 10:10:01 | 947d7cc2-236a-4835-bd76-c788c25bd8db

Stratum: language_mismatch_heuristic | client turns: 5 | unknown-content turns: 0 | silence: 1 | repeated bot events: 1 | services: none | language mismatches: 1

```text
=== CALL 69031 | 2026-11-06 10:10:01 | 947d7cc2-236a-4835-bd76-c788c25bd8db ===
[10:10:02] dialog_step=00_00_continuity__main | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[10:10:11] dialog_step=00_00_continuity__main | intent=talk_to_operator
CLIENT: оператор
[10:10:11] dialog_step=00_00_continuity__main | intent=talk_to_operator
BOT: Уважаемый клиент, чтобы не тратить ваше время на переключение, давайте попробуем решить вопрос здесь. Если потребуется специалист, я подключу.
Скажите, чем я могу вам помочь?
[10:10:26] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
CLIENT: оператор
[10:10:26] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
BOT: Сейчас я переведу вас на оператора. Подскажите, пожалуйста, причину обращения, чтобы я мог направить вас к нужному специалисту.
[10:10:39] dialog_step=00_06_reask_before_operator__first_ask | intent=silence
CLIENT: <SILENCE>
[10:10:39] dialog_step=00_06_reask_before_operator__first_ask | intent=silence
BOT: Сейчас я переведу вас на оператора. Подскажите, пожалуйста, причину обращения, чтобы я мог направить вас к нужному специалисту.
[10:10:51] dialog_step=00_06_reask_before_operator__second_ask | intent=talk_to_operator
CLIENT: кеңесші керек кеңесші
[10:10:51] dialog_step=00_06_reask_before_operator__second_ask | intent=talk_to_operator
BOT: Общая линия сейчас перегружена и ожидание может занять длительное время. Чтобы перевести вас на свободного оператора, мне нужно знать причину вашего обращения.
[10:11:04] dialog_step=unknown | intent=talk_to_operator
CLIENT: оператор оператор
[10:11:04] dialog_step=unknown | intent=talk_to_operator
BOT: Хорошо, переключаю звонок на специалиста, оставайтесь на линии.
```

## SAMPLE 40 | CALL 99503 | 2026-11-09 10:42:33 | d4c8aee4-4908-4c58-857c-e2f157f775e9

Stratum: language_mismatch_heuristic | client turns: 5 | unknown-content turns: 3 | silence: 0 | repeated bot events: 1 | services: none | language mismatches: 2

```text
=== CALL 99503 | 2026-11-09 10:42:33 | d4c8aee4-4908-4c58-857c-e2f157f775e9 ===
[10:42:35] dialog_step=00_00_continuity__main | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[10:42:46] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: саламатсыз ба
[10:42:46] dialog_step=00_00_continuity__main | intent=unknown
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[10:42:53] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: сәлеметсіз бе
[10:42:53] dialog_step=00_00_continuity__main | intent=unknown
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[10:43:00] dialog_step=00_06_reask_before_operator__first_ask | intent=unknown
CLIENT: саламатсыз ба
[10:43:00] dialog_step=00_06_reask_before_operator__first_ask | intent=unknown
BOT: Сейчас я переведу вас на оператора. Подскажите, пожалуйста, причину обращения, чтобы я мог направить вас к нужному специалисту.
[10:43:14] dialog_step=00_06_reask_before_operator__second_ask | intent=talk_to_operator
CLIENT: подключите к специалисту
[10:43:14] dialog_step=00_06_reask_before_operator__second_ask | intent=talk_to_operator
BOT: Общая линия сейчас перегружена и ожидание может занять длительное время. Чтобы перевести вас на свободного оператора, мне нужно знать причину вашего обращения.
[10:43:29] dialog_step=unknown | intent=pension_receipt
CLIENT: пенсия түскен жоқ
[10:43:29] dialog_step=unknown | intent=pension_receipt
BOT: Хорошо, переключаю звонок на специалиста, оставайтесь на линии.
```

## SAMPLE 41 | CALL 126365 | 2026-11-10 20:32:22 | e5a7d3c3-6c4a-4e76-ac37-b11f627b7f5f

Stratum: language_mismatch_heuristic | client turns: 4 | unknown-content turns: 1 | silence: 0 | repeated bot events: 0 | services: none | language mismatches: 1

```text
=== CALL 126365 | 2026-11-10 20:32:22 | e5a7d3c3-6c4a-4e76-ac37-b11f627b7f5f ===
[20:32:23] dialog_step=00_00_continuity__main | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[20:32:33] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: екі ау
[20:32:33] dialog_step=00_00_continuity__main | intent=unknown
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[20:32:40] dialog_step=00_00_continuity__main | intent=talk_to_operator
CLIENT: соедините с оператором
[20:32:40] dialog_step=00_00_continuity__main | intent=talk_to_operator
BOT: Уважаемый клиент, чтобы не тратить ваше время на переключение, давайте попробуем решить вопрос здесь. Если потребуется специалист, я подключу.
Скажите, чем я могу вам помочь?
[20:32:55] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
CLIENT: соедините оператором
[20:32:55] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
BOT: Сейчас я переведу вас на оператора. Подскажите, пожалуйста, причину обращения, чтобы я мог направить вас к нужному специалисту.
[20:33:07] dialog_step=unknown | intent=cash_credit
CLIENT: по кредиту по кредиту
[20:33:07] dialog_step=unknown | intent=cash_credit
BOT: Хорошо, переключаю звонок на специалиста, оставайтесь на линии.
```

## SAMPLE 42 | CALL 3452 | 2026-11-01 16:12:14 | d839a0a3-0dce-49e7-bc5b-1ed28ce2b41d

Stratum: long_or_multi_topic | client turns: 6 | unknown-content turns: 0 | silence: 0 | repeated bot events: 0 | services: 25_15_recipient_not_received, 20_05_card_transfer_not_received | language mismatches: 0

```text
=== CALL 3452 | 2026-11-01 16:12:14 | d839a0a3-0dce-49e7-bc5b-1ed28ce2b41d ===
[16:12:15] dialog_step=00_00_continuity__main | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[16:12:35] dialog_step=25_15_recipient_not_received__start | intent=recipient_not_received
CLIENT: у меня не поступили деньги сейчас на в халык банк должно было поступить денежку пятнадцать тысяч она не поступила у меня до сих пор
[16:12:35] dialog_step=25_15_recipient_not_received__start | intent=recipient_not_received
BOT: Уточните, пожалуйста, вы отправили перевод, а получатель говорит, что деньги не поступили?
[16:12:51] dialog_step=25_15_recipient_not_received__answer | intent=recipient_not_received
CLIENT: нет нет мне должен был отправить перевод но я я получатель мне до сих пор деньги не дошли до меня
[16:12:51] dialog_step=25_15_recipient_not_received__answer | intent=recipient_not_received
BOT: Дорогой клиент, в данном случае вы можете отправить получателю квитанцию в качестве подтверждения совершённой операции. <pause_1> Для получения квитанции перейдите в раздел «Переводы», далее «История». Найдите совершённый вами перевод и нажмите на него. Далее отобразится квитанция. Вы можете воспользоваться функцией «Поделиться» и отправить чек получателю. <pause_1> Если реквизиты получателя указаны корректно, ошибка может возникать со стороны банка получателя. В этом случае получателю необходимо обратиться в свой банк. <pause_1> У Вас будут дополнительные вопросы?
[16:13:08] dialog_step=confirmation__20_05_card_transfer_not_received__start | intent=pin__ne_perevod_dengi
CLIENT: нет это мне не мне не пришли деньги мне наоборот на мой халык деньги не пришли
[16:13:08] dialog_step=confirmation__20_05_card_transfer_not_received__start | intent=pin__ne_perevod_dengi
BOT: Я правильно понял, что вы не получили перевод на карту?
[16:13:18] dialog_step=00_01_identification__greeting | intent=pin__ne_perevod_dengi
CLIENT: да да- да-да да на карту я не получила перевод хотя он отправил сказал
[16:13:18] dialog_step=00_01_identification__greeting | intent=pin__ne_perevod_dengi
BOT: Уважаемый клиент, для предоставления ответа на Ваш вопрос необходимо пройти идентификацию личности по цифровому документу, если Вы согласны я подскажу куда заходить.
[16:13:36] dialog_step=00_01_identification__gov_services_confirmation | intent=what
CLIENT: так давайте давайте куда заходить то надо
[16:13:36] dialog_step=00_01_identification__gov_services_confirmation | intent=what
BOT: Пожалуйста, откройте приложение Халык <pause_1> и перейдите в раздел "Госуслуги" <pause_1> Я подожду. <pause_5>
Подскажите, вы перешли в раздел "Госуслуги"?
[16:14:03] dialog_step=00_01_identification__gov_services_confirmation | intent=wait
CLIENT: сейчас подождите нет еще блин мне что мне что выходить что ли отсюда с этого мне отсюда сейчас выходить в халык зайти надо сразу да
[16:14:03] dialog_step=00_01_identification__gov_services_confirmation | intent=wait
BOT: Хорошо, подожду. Сообщите, когда будете готовы. <pause_5>
Подскажите, вы перешли в раздел "Госуслуги"?
```

## SAMPLE 43 | CALL 79604 | 2026-11-06 17:27:21 | 762cfe45-e0ae-4c6e-87da-c0391be79c5e

Stratum: long_or_multi_topic | client turns: 6 | unknown-content turns: 1 | silence: 0 | repeated bot events: 1 | services: 20_05_card_transfer_not_received, 24_04_hsa_certificates | language mismatches: 0

```text
=== CALL 79604 | 2026-11-06 17:27:21 | 762cfe45-e0ae-4c6e-87da-c0391be79c5e ===
[17:27:22] dialog_step=00_00_continuity__main | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[17:27:37] dialog_step=confirmation__20_05_card_transfer_not_received__start | intent=pin__ne_perevod_dengi
CLIENT: не поступили деньги на
[17:27:37] dialog_step=confirmation__20_05_card_transfer_not_received__start | intent=pin__ne_perevod_dengi
BOT: Я правильно понял, что вы не получили перевод на карту?
[17:27:46] dialog_step=24_04_hsa_certificates__start | intent=hsa_certificates
CLIENT: найти куущий счет
[17:27:46] dialog_step=24_04_hsa_certificates__start | intent=hsa_certificates
BOT: Дорогой клиент, в приложении Халык бесплатно доступны справки о доступном остатке, о наличии счёта и о задолженности. Чтобы получить справку, необходимо на главной странице перейти в свой профиль в правом в верхнем углу и выбрать «Справки». Справку можно сформировать по текущему счёту, депозиту и платёжной карте, кроме кредитных карт, спецсчёта для пособий и спецсчёта Национального фонда. У Вас будут дополнительные вопросы?
[17:28:19] dialog_step=24_04_hsa_certificates__start | intent=hsa_certificates
CLIENT: нахуй мне справка я вижу что счет пустой
[17:28:19] dialog_step=24_04_hsa_certificates__start | intent=hsa_certificates
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[17:28:28] dialog_step=24_04_hsa_certificates__start | intent=hsa_certificates
CLIENT: нахуй мне справка
[17:28:28] dialog_step=24_04_hsa_certificates__start | intent=hsa_certificates
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[17:28:36] dialog_step=00_06_reask_before_operator__first_ask | intent=unknown
CLIENT: затем мне справка долбаеб
[17:28:36] dialog_step=00_06_reask_before_operator__first_ask | intent=unknown
BOT: Сейчас я переведу вас на оператора. Подскажите, пожалуйста, причину обращения, чтобы я мог направить вас к нужному специалисту.
[17:28:48] dialog_step=unknown | intent=pin__ne_perevod_dengi
CLIENT: не поступили деньги на счет
[17:28:48] dialog_step=unknown | intent=pin__ne_perevod_dengi
BOT: Хорошо, переключаю звонок на специалиста, оставайтесь на линии.
```

## SAMPLE 44 | CALL 91923 | 2026-11-08 09:31:34 | 3ab82c09-cd82-412c-b680-c2ed1e92a284

Stratum: long_or_multi_topic | client turns: 8 | unknown-content turns: 0 | silence: 1 | repeated bot events: 1 | services: 13_04_check_amount | language mismatches: 0

```text
=== CALL 91923 | 2026-11-08 09:31:34 | 3ab82c09-cd82-412c-b680-c2ed1e92a284 ===
[09:31:34] dialog_step=00_00_continuity__language_ask | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Айтыңызшы, сізге қай тіл ыңғайлы болады - қазақ немесе орыс тілдерінде? Скажите, пожалуйста, на каком языке вам будет удобнее - на казахском или русском?
[09:31:50] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: казахском
[09:31:50] dialog_step=00_00_continuity__main | intent=unknown
BOT: Сәлеметсіз бе! Мен виртуалды көмекшімін, есімім Айдос. Қандай көмегім керек?
[09:31:59] dialog_step=00_00_continuity__main | intent=talk_to_operator
CLIENT: оператормен сөйлесу
[09:31:59] dialog_step=00_00_continuity__main | intent=talk_to_operator
BOT: Құрметті клиент, уақытыңызды үнемдеу үшін, сұрағыңызды осы жерде шешуге тырысайық. Қажет болса, маманға қосамын.
Айтыңызшы, мен сізге қалай көмектесе аламын?
[09:32:15] dialog_step=confirmation__13_04_check_amount__start | intent=prosroch_zadol__check_sum
CLIENT: мен қанша кредит төлеуім керек сол бүгінге дейін
[09:32:15] dialog_step=confirmation__13_04_check_amount__start | intent=prosroch_zadol__check_sum
BOT: Қарыз сомасын білгіңіз келеді деп дұрыс түсіндім бе?
[09:32:24] dialog_step=confirmation__13_04_check_amount__start | intent=silence
CLIENT: <SILENCE>
[09:32:24] dialog_step=confirmation__13_04_check_amount__start | intent=silence
BOT: Қарыз сомасын білгіңіз келеді деп дұрыс түсіндім бе?
[09:32:31] dialog_step=13_04_check_amount__proceed_untrusted_explained | intent=prosroch_zadol__check_sum
CLIENT: иә қарыз сомасы қанша болып тұр
[09:32:31] dialog_step=13_04_check_amount__proceed_untrusted_explained | intent=prosroch_zadol__check_sum
BOT: Несие бойынша қалған қарызды және өтеу кестесін көру үшін Халық қосымшасына кіріңіз. «Шоттар» бөліміне өтіп, несиені таңдаңыз, сізге төлем туралы ақпарат көрсетілген төлем кестесі ашылады.
[09:32:48] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: ба
[09:32:48] dialog_step=00_00_continuity__main | intent=unknown
BOT: Мен сізге тағы қандай көмек бере аламын?
[09:32:54] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: аллоло
[09:32:54] dialog_step=00_00_continuity__main | intent=unknown
BOT: Мен сізді толық түсінбедім, қайтадан басқаша айтып бересіз бе?
[09:33:01] dialog_step=unknown | intent=talk_to_operator
CLIENT: оператормен қосып жібер
[09:33:01] dialog_step=unknown | intent=talk_to_operator
BOT: Жақсы, қоңырауды операторға қосамын, желіден ажырамаңыз.
```

## SAMPLE 45 | CALL 130989 | 2026-11-11 11:39:30 | b6b7ecbf-c77c-4eb5-a5ba-77d53a224011

Stratum: long_or_multi_topic | client turns: 8 | unknown-content turns: 1 | silence: 3 | repeated bot events: 4 | services: none | language mismatches: 0

```text
=== CALL 130989 | 2026-11-11 11:39:30 | b6b7ecbf-c77c-4eb5-a5ba-77d53a224011 ===
[11:39:31] dialog_step=00_00_continuity__main | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[11:39:44] dialog_step=00_00_continuity__main | intent=silence
CLIENT: <SILENCE>
[11:39:44] dialog_step=00_00_continuity__main | intent=silence
BOT: Я вас не расслышал, повторите, пожалуйста.
[11:40:16] dialog_step=00_00_continuity__main | intent=silence
BOT: Я вас не расслышал, повторите, пожалуйста.
[11:40:28] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: жерді негізірмануды далалық ре өсірген аймақтарда өсірген
[11:40:28] dialog_step=00_00_continuity__main | intent=unknown
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[11:40:38] dialog_step=00_00_continuity__main | intent=silence
CLIENT: <SILENCE>
[11:40:38] dialog_step=00_00_continuity__main | intent=silence
BOT: Я вас не расслышал, повторите, пожалуйста.
[11:40:47] dialog_step=00_00_continuity__main | intent=silence
CLIENT: <SILENCE>
[11:40:47] dialog_step=00_00_continuity__main | intent=silence
BOT: Я вас не расслышал, повторите, пожалуйста.
[11:40:54] dialog_step=00_00_continuity__main | intent=talk_to_operator
CLIENT: операторға қосыңызшы операторға
[11:40:54] dialog_step=00_00_continuity__main | intent=talk_to_operator
BOT: Уважаемый клиент, чтобы не тратить ваше время на переключение, давайте попробуем решить вопрос здесь. Если потребуется специалист, я подключу.
Скажите, чем я могу вам помочь?
[11:41:10] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
CLIENT: операторға қосшы операторға
[11:41:10] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
BOT: Сейчас я переведу вас на оператора. Подскажите, пожалуйста, причину обращения, чтобы я мог направить вас к нужному специалисту.
[11:41:27] dialog_step=00_06_reask_before_operator__second_ask | intent=talk_to_operator
CLIENT: операторға қосшы операторға
[11:41:27] dialog_step=00_06_reask_before_operator__second_ask | intent=talk_to_operator
BOT: Общая линия сейчас перегружена и ожидание может занять длительное время. Чтобы перевести вас на свободного оператора, мне нужно знать причину вашего обращения.
[11:41:39] dialog_step=00_06_reask_before_operator__second_ask | intent=silence
BOT: Общая линия сейчас перегружена и ожидание может занять длительное время. Чтобы перевести вас на свободного оператора, мне нужно знать причину вашего обращения.
[11:41:58] dialog_step=unknown | intent=talk_to_operator
CLIENT: операторға қосшы операторға құдай үшін
[11:41:58] dialog_step=unknown | intent=talk_to_operator
BOT: Хорошо, переключаю звонок на специалиста, оставайтесь на линии.
```

## SAMPLE 46 | CALL 146583 | 2026-11-12 13:35:22 | b315c51e-63fd-44fa-9fa7-72ead7859e67

Stratum: long_or_multi_topic | client turns: 6 | unknown-content turns: 2 | silence: 0 | repeated bot events: 2 | services: 03_08_change_payment_date, 25_09_update_personal_data | language mismatches: 0

```text
=== CALL 146583 | 2026-11-12 13:35:22 | b315c51e-63fd-44fa-9fa7-72ead7859e67 ===
[13:35:24] dialog_step=00_00_continuity__main | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[13:35:46] dialog_step=03_08_change_payment_date__start | intent=change_payment_date
CLIENT: у меня изменился график оплаты труда и в связи с этим хотел поменять график погашения платежей по кредиту
[13:35:46] dialog_step=03_08_change_payment_date__start | intent=change_payment_date
BOT: Дорогой клиент, изменить дату платежа по кредиту вы можете в приложении Халык. <pause_1> Для этого откройте раздел «Мой банк». Нажмите на нужный кредит. Перейдите в раздел «Условия кредита». Нажмите «Изменить условия займа». Выберите «Выбрать новую дату». <pause_1> Изменить дату платежа можно только в текущем месяце после совершения планового платежа. <pause_1> За изменение даты может взиматься комиссия. Её размер зависит от условий вашего кредита. При оформлении изменения даты платежа размер комиссии будет указан в приложении. <pause_1> У Вас будут дополнительные вопросы?
[13:36:36] dialog_step=03_08_change_payment_date__start | intent=repeat
CLIENT: так повторите пожалуйста еще раз зашел в мой банк дальше
[13:36:36] dialog_step=03_08_change_payment_date__start | intent=repeat
BOT: Дорогой клиент, изменить дату платежа по кредиту вы можете в приложении Халык. <pause_1> Для этого откройте раздел «Мой банк». Нажмите на нужный кредит. Перейдите в раздел «Условия кредита». Нажмите «Изменить условия займа». Выберите «Выбрать новую дату». <pause_1> Изменить дату платежа можно только в текущем месяце после совершения планового платежа. <pause_1> За изменение даты может взиматься комиссия. Её размер зависит от условий вашего кредита. При оформлении изменения даты платежа размер комиссии будет указан в приложении. <pause_1> У Вас будут дополнительные вопросы?
[13:37:27] dialog_step=03_08_change_payment_date__start | intent=unknown
CLIENT: так измен условия знаю спасибо
[13:37:27] dialog_step=03_08_change_payment_date__start | intent=unknown
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[13:37:38] dialog_step=03_08_change_payment_date__start | intent=unknown
CLIENT: спасибо большое попробую сейчас изменить
[13:37:38] dialog_step=03_08_change_payment_date__start | intent=unknown
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[13:37:51] dialog_step=25_09_update_personal_data__start | intent=update_personal_data
CLIENT: так вот я зашёл в мой банк теперь что я должен сказать для изменения
[13:37:51] dialog_step=25_09_update_personal_data__start | intent=update_personal_data
BOT: Дорогой клиент, для обновления анкетных данных вам необходимо обратиться в отделение банка. При себе необходимо иметь документ, удостоверяющий личность. <pause_1> При смене фамилии должен быть подтверждающий документ. <pause_1> У Вас будут дополнительные вопросы?
[13:38:13] dialog_step=unknown | intent=unknown
CLIENT: афина
[13:38:13] dialog_step=unknown | intent=unknown
BOT: Хорошо, переключаю звонок на специалиста, оставайтесь на линии.
```

## SAMPLE 47 | CALL 32717 | 2026-11-03 19:18:47 | 3f7c2ece-2d6d-40bd-ab48-6e2706844700

Stratum: silence_or_unresolved | client turns: 5 | unknown-content turns: 2 | silence: 0 | repeated bot events: 0 | services: none | language mismatches: 0

```text
=== CALL 32717 | 2026-11-03 19:18:47 | 3f7c2ece-2d6d-40bd-ab48-6e2706844700 ===
[19:18:48] dialog_step=00_00_continuity__main | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[19:19:00] dialog_step=00_00_continuity__score_the_conversation | intent=disagree
CLIENT: не оператор қосыңызшы
[19:19:00] dialog_step=00_00_continuity__score_the_conversation | intent=disagree
BOT: Пожалуйста, оцените работу от одного до пяти, где пять - это отлично, а один - это плохо
[19:19:10] dialog_step=00_00_continuity__score_the_conversation | intent=talk_to_operator
CLIENT: с оператор оператор включите
[19:19:10] dialog_step=00_00_continuity__score_the_conversation | intent=talk_to_operator
BOT: Уважаемый клиент, чтобы не тратить ваше время на переключение, давайте попробуем решить вопрос здесь. Если потребуется специалист, я подключу.
Пожалуйста, оцените работу от одного до пяти, где пять - это отлично, а один - это плохо
[19:19:34] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
CLIENT: пять оператор включите
[19:19:34] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
BOT: Сейчас я переведу вас на оператора. Подскажите, пожалуйста, причину обращения, чтобы я мог направить вас к нужному специалисту.
[19:19:51] dialog_step=00_06_reask_before_operator__second_ask | intent=unknown
CLIENT: хотел узнать номер своего этого народ который стоит
[19:19:51] dialog_step=00_06_reask_before_operator__second_ask | intent=unknown
BOT: Общая линия сейчас перегружена и ожидание может занять длительное время. Чтобы перевести вас на свободного оператора, мне нужно знать причину вашего обращения.
[19:20:06] dialog_step=unknown | intent=unknown
CLIENT: карту хотел узнать карту
[19:20:06] dialog_step=unknown | intent=unknown
BOT: Хорошо, переключаю звонок на специалиста, оставайтесь на линии.
```

## SAMPLE 48 | CALL 77285 | 2026-11-06 15:48:46 | 03ef1857-660b-4a14-a836-b7d0a3480c08

Stratum: silence_or_unresolved | client turns: 3 | unknown-content turns: 1 | silence: 0 | repeated bot events: 0 | services: none | language mismatches: 0

```text
=== CALL 77285 | 2026-11-06 15:48:46 | 03ef1857-660b-4a14-a836-b7d0a3480c08 ===
[15:48:46] dialog_step=00_00_continuity__language_ask | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Айтыңызшы, сізге қай тіл ыңғайлы болады - қазақ немесе орыс тілдерінде? Скажите, пожалуйста, на каком языке вам будет удобнее - на казахском или русском?
[15:49:01] dialog_step=00_00_continuity__main | intent=change_lang_ru
CLIENT: фамилия русском на русском
[15:49:01] dialog_step=00_00_continuity__main | intent=change_lang_ru
BOT: Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[15:49:13] dialog_step=00_00_continuity__score_the_conversation | intent=dont_know
CLIENT: не знаю звонили я поэтому перезваниваю
[15:49:13] dialog_step=00_00_continuity__score_the_conversation | intent=dont_know
BOT: Пожалуйста, оцените работу от одного до пяти, где пять - это отлично, а один - это плохо
[15:49:23] dialog_step=unknown | intent=unknown
CLIENT: пять пять
[15:49:23] dialog_step=unknown | intent=unknown
BOT: Спасибо за оценку!
Всего доброго!
```

## SAMPLE 49 | CALL 93548 | 2026-11-08 12:55:01 | abc0735f-fceb-4ba1-b644-c03432674ea5

Stratum: silence_or_unresolved | client turns: 6 | unknown-content turns: 3 | silence: 0 | repeated bot events: 2 | services: none | language mismatches: 0

```text
=== CALL 93548 | 2026-11-08 12:55:01 | abc0735f-fceb-4ba1-b644-c03432674ea5 ===
[12:55:02] dialog_step=00_00_continuity__main | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[12:55:14] dialog_step=00_00_continuity__main | intent=change_lang_kz
CLIENT: айдос аиды қазақша есть дейтін
[12:55:14] dialog_step=00_00_continuity__main | intent=change_lang_kz
BOT: Сәлеметсіз бе! Мен виртуалды көмекшімін, есімім Айдос. Қандай көмегім керек?
[12:55:25] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: ана пэка банктен карточкада ақша ғой үш мәге
[12:55:25] dialog_step=00_00_continuity__main | intent=unknown
BOT: Мен сізді толық түсінбедім, қайтадан басқаша айтып бересіз бе?
[12:55:31] dialog_step=00_00_continuity__main | intent=agree
CLIENT: иә иә айтамын
[12:55:31] dialog_step=00_00_continuity__main | intent=agree
BOT: Тамаша, сізге қандай көмек керек?
[12:55:40] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: давайдар ма ма алло
[12:55:40] dialog_step=00_00_continuity__main | intent=unknown
BOT: Мен сізді толық түсінбедім, қайтадан басқаша айтып бересіз бе?
[12:55:49] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: пенсияон баланың карточкасы ақша жіберді
[12:55:49] dialog_step=00_00_continuity__main | intent=unknown
BOT: Мен сізді толық түсінбедім, қайтадан басқаша айтып бересіз бе?
[12:55:54] dialog_step=00_00_continuity__main | intent=silence
BOT: Мен сізді анық естімедім, қайталап жіберіңізші.
[12:55:59] dialog_step=unknown | intent=unknown
CLIENT: алло
[12:55:59] dialog_step=unknown | intent=unknown
BOT: Жақсы, қоңырауды операторға қосамын, желіден ажырамаңыз.
```

## SAMPLE 50 | CALL 109684 | 2026-11-09 18:28:22 | dce2446b-62a7-4451-a03d-8fe4c3231993

Stratum: silence_or_unresolved | client turns: 5 | unknown-content turns: 0 | silence: 3 | repeated bot events: 2 | services: none | language mismatches: 0

```text
=== CALL 109684 | 2026-11-09 18:28:22 | dce2446b-62a7-4451-a03d-8fe4c3231993 ===
[18:28:22] dialog_step=00_00_continuity__language_ask | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Айтыңызшы, сізге қай тіл ыңғайлы болады - қазақ немесе орыс тілдерінде? Скажите, пожалуйста, на каком языке вам будет удобнее - на казахском или русском?
[18:28:38] dialog_step=00_00_continuity__main | intent=change_lang_kz
CLIENT: қазақша
[18:28:38] dialog_step=00_00_continuity__main | intent=change_lang_kz
BOT: Сәлеметсіз бе! Мен виртуалды көмекшімін, есімім Айдос. Қандай көмегім керек?
[18:28:50] dialog_step=00_00_continuity__score_the_conversation | intent=dont_know
CLIENT: мынау народный ашылмайты да неғып ашылмайтқанын білмей тұрмын сол
[18:28:50] dialog_step=00_00_continuity__score_the_conversation | intent=dont_know
BOT: Өтінемін, жұмысты бірден беске дейін бағалаңыз, мұнда бес – өте жақсы, ал бір – өте нашар.
[18:29:02] dialog_step=00_00_continuity__score_the_conversation | intent=silence
CLIENT: <SILENCE>
[18:29:02] dialog_step=00_00_continuity__score_the_conversation | intent=silence
BOT: Өтінемін, жұмысты бірден беске дейін бағалаңыз, мұнда бес – өте жақсы, ал бір – өте нашар.
[18:29:15] dialog_step=00_00_continuity__score_the_conversation | intent=silence
CLIENT: <SILENCE>
[18:29:15] dialog_step=00_00_continuity__score_the_conversation | intent=silence
BOT: Өтінемін, жұмысты бірден беске дейін бағалаңыз, мұнда бес – өте жақсы, ал бір – өте нашар.
[18:29:28] dialog_step=unknown | intent=silence
CLIENT: <SILENCE>
[18:29:28] dialog_step=unknown | intent=silence
BOT: Кері байланыс болмағандықтан, мен қоңырауды аяқтаймын.
```
