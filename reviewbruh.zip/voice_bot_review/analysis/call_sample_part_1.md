# November 2026 call sample

Deterministic seed: 20261118. 50 calls: 8 random baseline plus targeted service, unknown, repetition, language, multi-topic, and unresolved strata. This is an evaluation/discovery sample, not a representative prevalence sample. Long digit sequences are redacted in this derived file only.

## SAMPLE 1 | CALL 11917 | 2026-11-02 13:58:46 | 918fa172-3dd5-4c0f-a46a-d36a15f7f731

Stratum: random_baseline | client turns: 6 | unknown-content turns: 2 | silence: 1 | repeated bot events: 1 | services: none | language mismatches: 0

```text
=== CALL 11917 | 2026-11-02 13:58:46 | 918fa172-3dd5-4c0f-a46a-d36a15f7f731 ===
[13:58:47] dialog_step=00_00_continuity__language_ask | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Айтыңызшы, сізге қай тіл ыңғайлы болады - қазақ немесе орыс тілдерінде? Скажите, пожалуйста, на каком языке вам будет удобнее - на казахском или русском?
[13:59:03] dialog_step=00_00_continuity__main | intent=change_lang_ru
CLIENT: на русском
[13:59:03] dialog_step=00_00_continuity__main | intent=change_lang_ru
BOT: Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[13:59:11] dialog_step=00_00_continuity__main | intent=talk_to_operator
CLIENT: свяжись оператортором
[13:59:11] dialog_step=00_00_continuity__main | intent=talk_to_operator
BOT: Уважаемый клиент, чтобы не тратить ваше время на переключение, давайте попробуем решить вопрос здесь. Если потребуется специалист, я подключу.
Скажите, чем я могу вам помочь?
[13:59:26] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: серч операторта
[13:59:26] dialog_step=00_00_continuity__main | intent=unknown
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[13:59:34] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
CLIENT: свяжите с оператором
[13:59:34] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
BOT: Сейчас я переведу вас на оператора. Подскажите, пожалуйста, причину обращения, чтобы я мог направить вас к нужному специалисту.
[13:59:46] dialog_step=00_06_reask_before_operator__second_ask | intent=unknown
CLIENT: получателю не пришел платеж
[13:59:46] dialog_step=00_06_reask_before_operator__second_ask | intent=unknown
BOT: Общая линия сейчас перегружена и ожидание может занять длительное время. Чтобы перевести вас на свободного оператора, мне нужно знать причину вашего обращения.
[14:00:01] dialog_step=00_06_reask_before_operator__second_ask | intent=silence
CLIENT: <SILENCE>
[14:00:01] dialog_step=00_06_reask_before_operator__second_ask | intent=silence
BOT: Общая линия сейчас перегружена и ожидание может занять длительное время. Чтобы перевести вас на свободного оператора, мне нужно знать причину вашего обращения.
```

## SAMPLE 2 | CALL 14998 | 2026-11-02 16:18:44 | 6586665a-1f5d-41ce-a63b-25b719cb0283

Stratum: random_baseline | client turns: 3 | unknown-content turns: 1 | silence: 0 | repeated bot events: 0 | services: none | language mismatches: 0

```text
=== CALL 14998 | 2026-11-02 16:18:44 | 6586665a-1f5d-41ce-a63b-25b719cb0283 ===
[16:18:44] dialog_step=00_00_continuity__main | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[16:18:55] dialog_step=00_00_continuity__main | intent=talk_to_operator
CLIENT: оператормен қосасыз ба
[16:18:55] dialog_step=00_00_continuity__main | intent=talk_to_operator
BOT: Уважаемый клиент, чтобы не тратить ваше время на переключение, давайте попробуем решить вопрос здесь. Если потребуется специалист, я подключу.
Скажите, чем я могу вам помочь?
[16:19:11] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
CLIENT: специалистпен қосыңызшы
[16:19:11] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
BOT: Сейчас я переведу вас на оператора. Подскажите, пожалуйста, причину обращения, чтобы я мог направить вас к нужному специалисту.
[16:19:23] dialog_step=unknown | intent=unknown
CLIENT: кредит кредит алайын дегенмін соған
[16:19:24] dialog_step=unknown | intent=cash_credit
BOT: Хорошо, переключаю звонок на специалиста, оставайтесь на линии.
```

## SAMPLE 3 | CALL 27621 | 2026-11-03 14:39:58 | 769bce16-2c92-4650-92a4-2d9a4e3e0492

Stratum: random_baseline | client turns: 5 | unknown-content turns: 2 | silence: 0 | repeated bot events: 0 | services: none | language mismatches: 0

```text
=== CALL 27621 | 2026-11-03 14:39:58 | 769bce16-2c92-4650-92a4-2d9a4e3e0492 ===
[14:40:00] dialog_step=00_00_continuity__main | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[14:40:10] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: ре
[14:40:10] dialog_step=00_00_continuity__main | intent=unknown
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[14:40:18] dialog_step=00_00_continuity__main | intent=talk_to_operator
CLIENT: свяжитесь с оператором
[14:40:18] dialog_step=00_00_continuity__main | intent=talk_to_operator
BOT: Уважаемый клиент, чтобы не тратить ваше время на переключение, давайте попробуем решить вопрос здесь. Если потребуется специалист, я подключу.
Скажите, чем я могу вам помочь?
[14:40:33] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
CLIENT: требуется специалист
[14:40:33] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
BOT: Сейчас я переведу вас на оператора. Подскажите, пожалуйста, причину обращения, чтобы я мог направить вас к нужному специалисту.
[14:40:46] dialog_step=00_06_reask_before_operator__second_ask | intent=unknown
CLIENT: оплата карточки
[14:40:46] dialog_step=00_06_reask_before_operator__second_ask | intent=unknown
BOT: Общая линия сейчас перегружена и ожидание может занять длительное время. Чтобы перевести вас на свободного оператора, мне нужно знать причину вашего обращения.
[14:40:59] dialog_step=unknown | intent=unknown
CLIENT: по поводу карточки
[14:40:59] dialog_step=unknown | intent=unknown
BOT: Хорошо, переключаю звонок на специалиста, оставайтесь на линии.
```

## SAMPLE 4 | CALL 64231 | 2026-11-05 18:30:25 | 9201e15b-2ac8-406d-b9b4-3c251eead9f9

Stratum: random_baseline | client turns: 5 | unknown-content turns: 0 | silence: 4 | repeated bot events: 1 | services: none | language mismatches: 0

```text
=== CALL 64231 | 2026-11-05 18:30:25 | 9201e15b-2ac8-406d-b9b4-3c251eead9f9 ===
[18:30:25] dialog_step=00_00_continuity__language_ask | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Айтыңызшы, сізге қай тіл ыңғайлы болады - қазақ немесе орыс тілдерінде? Скажите, пожалуйста, на каком языке вам будет удобнее - на казахском или русском?
[18:30:44] dialog_step=00_00_continuity__language_ask | intent=silence
CLIENT: <SILENCE>
[18:30:44] dialog_step=00_00_continuity__language_ask | intent=silence
BOT: Айтыңызшы, сізге қай тіл ыңғайлы болады - қазақ немесе орыс тілдерінде? Скажите, пожалуйста, на каком языке вам будет удобнее - на казахском или русском?
[18:30:56] dialog_step=00_00_continuity__main | intent=change_lang_kz
CLIENT: қазақ тілі
[18:30:56] dialog_step=00_00_continuity__main | intent=change_lang_kz
BOT: Сәлеметсіз бе! Мен виртуалды көмекшімін, есімім Айдос. Қандай көмегім керек?
[18:31:07] dialog_step=00_00_continuity__main | intent=silence
CLIENT: <SILENCE>
[18:31:07] dialog_step=00_00_continuity__main | intent=silence
BOT: Мен сізді анық естімедім, қайталап жіберіңізші.
[18:31:15] dialog_step=00_00_continuity__main | intent=silence
CLIENT: <SILENCE>
[18:31:15] dialog_step=00_00_continuity__main | intent=silence
BOT: Мен сізді анық естімедім, қайталап жіберіңізші.
[18:31:23] dialog_step=unknown | intent=silence
CLIENT: <SILENCE>
[18:31:23] dialog_step=unknown | intent=silence
BOT: Кері байланыс болмағандықтан, мен қоңырауды аяқтаймын.
```

## SAMPLE 5 | CALL 104094 | 2026-11-09 14:06:52 | 93acaf6b-80f3-4d61-a22a-4dbf76704fcc

Stratum: random_baseline | client turns: 6 | unknown-content turns: 3 | silence: 0 | repeated bot events: 1 | services: 08_03_what_limit | language mismatches: 0

```text
=== CALL 104094 | 2026-11-09 14:06:52 | 93acaf6b-80f3-4d61-a22a-4dbf76704fcc ===
[14:06:52] dialog_step=00_00_continuity__language_ask | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Айтыңызшы, сізге қай тіл ыңғайлы болады - қазақ немесе орыс тілдерінде? Скажите, пожалуйста, на каком языке вам будет удобнее - на казахском или русском?
[14:07:08] dialog_step=00_00_continuity__main | intent=change_lang_kz
CLIENT: қазақша
[14:07:08] dialog_step=00_00_continuity__main | intent=change_lang_kz
BOT: Сәлеметсіз бе! Мен виртуалды көмекшімін, есімім Айдос. Қандай көмегім керек?
[14:07:17] dialog_step=00_00_continuity__main | intent=talk_to_operator
CLIENT: оператормен қосасыз ба
[14:07:17] dialog_step=00_00_continuity__main | intent=talk_to_operator
BOT: Құрметті клиент, уақытыңызды үнемдеу үшін, сұрағыңызды осы жерде шешуге тырысайық. Қажет болса, маманға қосамын.
Айтыңызшы, мен сізге қалай көмектесе аламын?
[14:07:34] dialog_step=08_03_what_limit__start | intent=limit__ne_prohodit_perevod
CLIENT: мен бір кісіге ақша аударуым керек менде лимит пе екен соны біліп бересіз бе
[14:07:34] dialog_step=08_03_what_limit__start | intent=limit__ne_prohodit_perevod
BOT: Құрметті клиент, қандай аударым жасайтыныңызды айтыңызшы? Телефон нөміріне, Қазақстан картасына және шот нөміріне, әлде халықаралық аударым жасайсыз ба?
[14:07:51] dialog_step=08_03_what_limit__start | intent=unknown
CLIENT: қазақстан картасына қазақстан картасына
[14:07:51] dialog_step=08_03_what_limit__start | intent=unknown
BOT: Мен сізді толық түсінбедім, қайтадан басқаша айтып бересіз бе?
[14:08:02] dialog_step=08_03_what_limit__start | intent=unknown
CLIENT: оператор не ғой
[14:08:02] dialog_step=08_03_what_limit__start | intent=unknown
BOT: Мен сізді толық түсінбедім, қайтадан басқаша айтып бересіз бе?
[14:08:06] dialog_step=unknown | intent=unknown
CLIENT: мынау де
[14:08:06] dialog_step=unknown | intent=unknown
BOT: Жақсы, қоңырауды операторға қосамын, желіден ажырамаңыз.
```

## SAMPLE 6 | CALL 107885 | 2026-11-09 16:49:10 | 087ca011-a12e-4083-a6d6-fb3529602bf4

Stratum: random_baseline | client turns: 5 | unknown-content turns: 2 | silence: 0 | repeated bot events: 1 | services: none | language mismatches: 0

```text
=== CALL 107885 | 2026-11-09 16:49:10 | 087ca011-a12e-4083-a6d6-fb3529602bf4 ===
[16:49:10] dialog_step=00_00_continuity__language_ask | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Айтыңызшы, сізге қай тіл ыңғайлы болады - қазақ немесе орыс тілдерінде? Скажите, пожалуйста, на каком языке вам будет удобнее - на казахском или русском?
[16:49:25] dialog_step=00_00_continuity__main | intent=change_lang_ru
CLIENT: на русском
[16:49:25] dialog_step=00_00_continuity__main | intent=change_lang_ru
BOT: Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[16:49:34] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: виртульальный помощник
[16:49:34] dialog_step=00_00_continuity__main | intent=unknown
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[16:49:44] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: я делаю ваш банк
[16:49:44] dialog_step=00_00_continuity__main | intent=unknown
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[16:49:50] dialog_step=00_06_reask_before_operator__first_ask | intent=unknown
CLIENT: переконнуллиировать
[16:49:50] dialog_step=00_06_reask_before_operator__first_ask | intent=unknown
BOT: Сейчас я переведу вас на оператора. Подскажите, пожалуйста, причину обращения, чтобы я мог направить вас к нужному специалисту.
[16:50:03] dialog_step=unknown | intent=ipoteka__refinans
CLIENT: специалист по поводу рефинансирования
[16:50:03] dialog_step=unknown | intent=ipoteka__refinans
BOT: Хорошо, переключаю звонок на специалиста, оставайтесь на линии.
```

## SAMPLE 7 | CALL 113870 | 2026-11-10 10:32:26 | 5882c711-afc5-4064-8b55-640a852e034d

Stratum: random_baseline | client turns: 7 | unknown-content turns: 1 | silence: 1 | repeated bot events: 0 | services: 02_04_insufficient_funds | language mismatches: 0

```text
=== CALL 113870 | 2026-11-10 10:32:26 | 5882c711-afc5-4064-8b55-640a852e034d ===
[10:32:26] dialog_step=00_00_continuity__main | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[10:32:39] dialog_step=confirmation__02_04_insufficient_funds__start | intent=insufficient_funds
CLIENT: айдос я потеряла пятьдесят две тысячи тенге где они
[10:32:39] dialog_step=confirmation__02_04_insufficient_funds__start | intent=insufficient_funds
BOT: Я правильно понял, что у вас вопрос по сумме средств на карте?
[10:32:48] dialog_step=02_04_insufficient_funds__ask_identification_for_details | intent=agree
CLIENT: да
[10:32:48] dialog_step=02_04_insufficient_funds__ask_identification_for_details | intent=agree
BOT: Дорогой клиент, Информацию о карте или о счете Вы можете получить в приложении Халык в разделе "Счета", нажав на карту или счет.
Чтобы получить более подробную информацию, нужно пройти идентификацию личности. Хотите её пройти?
[10:33:06] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: с
[10:33:06] dialog_step=00_00_continuity__main | intent=unknown
BOT: Могу ли я еще чем-то помочь?
[10:33:14] dialog_step=00_00_continuity__main | intent=silence
CLIENT: <SILENCE>
[10:33:14] dialog_step=00_00_continuity__main | intent=silence
BOT: Я вас не расслышал, повторите, пожалуйста.
[10:33:21] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: я хочу пройти идентификацию
[10:33:21] dialog_step=00_00_continuity__main | intent=unknown
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[10:33:29] dialog_step=00_00_continuity__main | intent=talk_to_operator
CLIENT: тогда переведи на оператора
[10:33:29] dialog_step=00_00_continuity__main | intent=talk_to_operator
BOT: Уважаемый клиент, чтобы не тратить ваше время на переключение, давайте попробуем решить вопрос здесь. Если потребуется специалист, я подключу.
Скажите, чем я могу вам помочь?
[10:33:46] dialog_step=unknown | intent=talk_to_operator
CLIENT: мне нужен другой специалист
[10:33:46] dialog_step=unknown | intent=talk_to_operator
BOT: Хорошо, переключаю звонок на специалиста, оставайтесь на линии.
```

## SAMPLE 8 | CALL 115743 | 2026-11-10 11:50:59 | 6deae59f-3256-47f7-8707-f7c08b892c65

Stratum: random_baseline | client turns: 3 | unknown-content turns: 0 | silence: 0 | repeated bot events: 0 | services: none | language mismatches: 0

```text
=== CALL 115743 | 2026-11-10 11:50:59 | 6deae59f-3256-47f7-8707-f7c08b892c65 ===
[11:51:00] dialog_step=00_00_continuity__main | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[11:51:11] dialog_step=00_00_continuity__main | intent=talk_to_operator
CLIENT: связаться с оператором
[11:51:11] dialog_step=00_00_continuity__main | intent=talk_to_operator
BOT: Уважаемый клиент, чтобы не тратить ваше время на переключение, давайте попробуем решить вопрос здесь. Если потребуется специалист, я подключу.
Скажите, чем я могу вам помочь?
[11:51:26] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
CLIENT: связаться с оператором
[11:51:26] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
BOT: Сейчас я переведу вас на оператора. Подскажите, пожалуйста, причину обращения, чтобы я мог направить вас к нужному специалисту.
[11:51:44] dialog_step=unknown | intent=recipient_not_received
CLIENT: перевела деньги с вашего банка на другой банк в течение сскольких дней поступят деньги на счет
[11:51:44] dialog_step=unknown | intent=recipient_not_received
BOT: Хорошо, переключаю звонок на специалиста, оставайтесь на линии.
```

## SAMPLE 9 | CALL 3722 | 2026-11-01 16:49:52 | bc55dcf2-3075-437c-9f07-c38c6bf02c8a

Stratum: service_journey | client turns: 3 | unknown-content turns: 0 | silence: 0 | repeated bot events: 0 | services: 08_02_international_transfer, 25_15_recipient_not_received, 25_05_card_refund_timing | language mismatches: 0

```text
=== CALL 3722 | 2026-11-01 16:49:52 | bc55dcf2-3075-437c-9f07-c38c6bf02c8a ===
[16:49:52] dialog_step=00_00_continuity__main | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[16:50:09] dialog_step=08_02_international_transfer__uz_transfer | intent=uz_transfer
CLIENT: ал я переводил деньги на карту узбекистана и до сих пор не пришли они
[16:50:09] dialog_step=08_02_international_transfer__uz_transfer | intent=uz_transfer
BOT: Дорогой клиент, совершить перевод на карту в Узбекистан вы сможете в приложении Халык. Для этого необходимо перейти в раздел Переводы, выбрать Международные переводы, далее нажать на На карту в Узбекистан и следуйте инструкциям для заполнения необходимых данных. <pause_2>
[16:50:33] dialog_step=25_15_recipient_not_received__start | intent=recipient_not_received
CLIENT: я отправил они не дошли в заль
[16:50:33] dialog_step=25_15_recipient_not_received__start | intent=recipient_not_received
BOT: Уточните, пожалуйста, вы отправили перевод, а получатель говорит, что деньги не поступили?
[16:50:43] dialog_step=25_05_card_refund_timing__start | intent=card_refund_timing
CLIENT: да не поступили
[16:50:43] dialog_step=25_05_card_refund_timing__start | intent=card_refund_timing
BOT: Уважаемый клиент, возврат денежных средств по операциям по карте осуществляется в срок от одного до пятнадцати календарных дней. <pause_1> Поступление средств можно проверить в выписке по карте в приложении Халык Банк. <pause_1> У Вас будут дополнительные вопросы?
```

## SAMPLE 10 | CALL 12913 | 2026-11-02 14:38:42 | 114c75df-c97f-4884-b624-29ad19dd10d5

Stratum: service_journey | client turns: 3 | unknown-content turns: 0 | silence: 0 | repeated bot events: 1 | services: 26_05_insurance_info | language mismatches: 0

```text
=== CALL 12913 | 2026-11-02 14:38:42 | 114c75df-c97f-4884-b624-29ad19dd10d5 ===
[14:38:42] dialog_step=00_00_continuity__main | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[14:38:58] dialog_step=26_05_insurance_info__start | intent=insurance_info
CLIENT: можете меня соединить страховой отделом страховой машину хотел страховать
[14:38:58] dialog_step=26_05_insurance_info__start | intent=insurance_info
BOT: Дорогой клиент, если ваш вопрос связан со страхованием жизни Халык Лайф, пожалуйста, обратитесь по короткому номеру семь один два три. <pause_1> Если ваш вопрос связан с автострахованием, пожалуйста, позвоните по короткому номеру семь девять семь. <pause_1> Специалисты предоставят более подробную консультацию по вашему вопросу. <pause_1> У Вас будут дополнительные вопросы?
[14:39:30] dialog_step=00_00_continuity__main | intent=agree
CLIENT: да семь девять семь сказали да
[14:39:30] dialog_step=00_00_continuity__main | intent=agree
BOT: Отлично, в чем вам нужна помощь?
[14:39:39] dialog_step=26_05_insurance_info__start | intent=insurance_info
CLIENT: страховой автострахование номер какой
[14:39:39] dialog_step=26_05_insurance_info__start | intent=insurance_info
BOT: Дорогой клиент, если ваш вопрос связан со страхованием жизни Халык Лайф, пожалуйста, обратитесь по короткому номеру семь один два три. <pause_1> Если ваш вопрос связан с автострахованием, пожалуйста, позвоните по короткому номеру семь девять семь. <pause_1> Специалисты предоставят более подробную консультацию по вашему вопросу. <pause_1> У Вас будут дополнительные вопросы?
```

## SAMPLE 11 | CALL 39149 | 2026-11-04 12:43:10 | e8075c05-774c-48d1-bc14-d1c0215a41a4

Stratum: service_journey | client turns: 2 | unknown-content turns: 0 | silence: 0 | repeated bot events: 0 | services: 25_05_card_refund_timing | language mismatches: 0

```text
=== CALL 39149 | 2026-11-04 12:43:10 | e8075c05-774c-48d1-bc14-d1c0215a41a4 ===
[12:43:10] dialog_step=00_00_continuity__language_ask | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Айтыңызшы, сізге қай тіл ыңғайлы болады - қазақ немесе орыс тілдерінде? Скажите, пожалуйста, на каком языке вам будет удобнее - на казахском или русском?
[12:43:28] dialog_step=00_00_continuity__main | intent=change_lang_kz
CLIENT: қазақ тілі
[12:43:28] dialog_step=00_00_continuity__main | intent=change_lang_kz
BOT: Сәлеметсіз бе! Мен виртуалды көмекшімін, есімім Айдос. Қандай көмегім керек?
[12:43:43] dialog_step=25_05_card_refund_timing__start | intent=card_refund_timing
CLIENT: кеше біз киноға билет алып едік сосын оны возврат жасадық та и ақшасы бірақ бізге түспеді
[12:43:43] dialog_step=25_05_card_refund_timing__start | intent=card_refund_timing
BOT: Құрметті клиент, карта бойынша операциялар үшін қаражатты қайтару бір күннен он бес күнтізбелік күнге дейін жүзеге асырылады. <pause_1> Қаражаттың түскенін Халық Банк қосымшасындағы карта бойынша үзінді көшірмеден тексере аласыз. <pause_1> Қосымша сұрақтарыңыз бар ма?
```

## SAMPLE 12 | CALL 49164 | 2026-11-05 09:55:55 | ee886a93-0cda-4f8a-90b6-0730f8c72ce5

Stratum: service_journey | client turns: 3 | unknown-content turns: 1 | silence: 0 | repeated bot events: 0 | services: 09_04_limits_5_7_8 | language mismatches: 0

```text
=== CALL 49164 | 2026-11-05 09:55:55 | ee886a93-0cda-4f8a-90b6-0730f8c72ce5 ===
[09:56:03] dialog_step=00_00_continuity__main | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[09:56:21] dialog_step=confirmation__09_04_limits_5_7_8__start | intent=razblock_card__snyat_limit
CLIENT: хотел снять деньги с карточки банкомат пишет превышен лимит хотя никогда не снимал деньги с карточки что за фигня
[09:56:21] dialog_step=confirmation__09_04_limits_5_7_8__start | intent=razblock_card__snyat_limit
BOT: Я правильно понял, что вы хотите изменить лимиты по карте?
[09:56:29] dialog_step=confirmation__09_04_limits_5_7_8__start | intent=unknown
CLIENT: я их вообще никогда в жизни не ставил
[09:56:29] dialog_step=confirmation__09_04_limits_5_7_8__start | intent=unknown
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[09:56:47] dialog_step=00_01_identification__greeting | intent=razblock_card__snyat_limit
CLIENT: хотел снять деньги с карточки деньги никогда не снимал а мне банкомат пишет что превышен лимит лимит я никогда не устанавливал и как что делать чтобы снять деньги с карточки
[09:56:47] dialog_step=00_01_identification__greeting | intent=razblock_card__snyat_limit
BOT: Уважаемый клиент, для предоставления ответа на Ваш вопрос необходимо пройти идентификацию личности по цифровому документу, если Вы согласны я подскажу куда заходить.
```

## SAMPLE 13 | CALL 51589 | 2026-11-05 11:38:43 | 91f9b2a4-2164-4a1a-b177-dff3e82e24b0

Stratum: service_journey | client turns: 11 | unknown-content turns: 6 | silence: 3 | repeated bot events: 5 | services: 02_01_pension_receipt | language mismatches: 0

```text
=== CALL 51589 | 2026-11-05 11:38:43 | 91f9b2a4-2164-4a1a-b177-dff3e82e24b0 ===
[11:38:43] dialog_step=00_00_continuity__language_ask | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Айтыңызшы, сізге қай тіл ыңғайлы болады - қазақ немесе орыс тілдерінде? Скажите, пожалуйста, на каком языке вам будет удобнее - на казахском или русском?
[11:39:02] dialog_step=00_00_continuity__language_ask | intent=silence
CLIENT: <SILENCE>
[11:39:02] dialog_step=00_00_continuity__language_ask | intent=silence
BOT: Айтыңызшы, сізге қай тіл ыңғайлы болады - қазақ немесе орыс тілдерінде? Скажите, пожалуйста, на каком языке вам будет удобнее - на казахском или русском?
[11:39:16] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: қазақ қазақтар
[11:39:16] dialog_step=00_00_continuity__main | intent=unknown
BOT: Сәлеметсіз бе! Мен виртуалды көмекшімін, есімім Айдос. Қандай көмегім керек?
[11:39:26] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: ана үйның түсі ғой сонышы
[11:39:26] dialog_step=00_00_continuity__main | intent=unknown
BOT: Мен сізді толық түсінбедім, қайтадан басқаша айтып бересіз бе?
[11:39:35] dialog_step=00_00_continuity__main | intent=silence
CLIENT: <SILENCE>
[11:39:35] dialog_step=00_00_continuity__main | intent=silence
BOT: Мен сізді анық естімедім, қайталап жіберіңізші.
[11:39:47] dialog_step=confirmation__02_01_pension_receipt__start | intent=pension_receipt
CLIENT: анау пенсиям түсу еді соны бесм неғып түседі соны білейін дегенмін ғой
[11:39:47] dialog_step=confirmation__02_01_pension_receipt__start | intent=pension_receipt
BOT: Сіз зейнетақы түскенін білгіңіз келеді деп дұрыс түсіндім бе?
[11:39:53] dialog_step=confirmation__02_01_pension_receipt__start | intent=unknown
CLIENT: я я
[11:39:53] dialog_step=confirmation__02_01_pension_receipt__start | intent=unknown
BOT: Мен сізді толық түсінбедім, қайтадан басқаша айтып бересіз бе?
[11:40:01] dialog_step=confirmation__02_01_pension_receipt__start | intent=unknown
CLIENT: нешем туралы шешем түсу еді
[11:40:01] dialog_step=confirmation__02_01_pension_receipt__start | intent=unknown
BOT: Мен сізді толық түсінбедім, қайтадан басқаша айтып бересіз бе?
[11:40:06] dialog_step=confirmation__02_01_pension_receipt__start | intent=silence
BOT: Сіз зейнетақы түскенін білгіңіз келеді деп дұрыс түсіндім бе?
[11:40:12] dialog_step=02_01_pension_receipt__unidentified_untrusted_explained | intent=agree
CLIENT: иә иә
[11:40:12] dialog_step=02_01_pension_receipt__unidentified_untrusted_explained | intent=agree
BOT: Құрметті клиент, картаға түскен қаражатты Халық қосымшасындағы «Менің банкім» бөлімінен картаңызды таңдау арқылы тексере аласыз. Егер қаражат түспеген болса, жіберушіге хабарласуыңызды сұраймыз. <pause_2>
[11:40:30] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: мына автосы ана не қосыңызшы
[11:40:30] dialog_step=00_00_continuity__main | intent=unknown
BOT: Мен сізге тағы қандай көмек бере аламын?
[11:40:38] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: қосыңызшы неге
[11:40:38] dialog_step=00_00_continuity__main | intent=unknown
BOT: Мен сізді толық түсінбедім, қайтадан басқаша айтып бересіз бе?
[11:40:48] dialog_step=00_00_continuity__main | intent=silence
CLIENT: <SILENCE>
[11:40:48] dialog_step=00_00_continuity__main | intent=silence
BOT: Мен сізді анық естімедім, қайталап жіберіңізші.
```

## SAMPLE 14 | CALL 58135 | 2026-11-05 14:49:25 | 52dc5263-336b-4f5f-b9ab-2b33d61436da

Stratum: service_journey | client turns: 9 | unknown-content turns: 4 | silence: 1 | repeated bot events: 4 | services: 01_02_why_card_blocked | language mismatches: 0

```text
=== CALL 58135 | 2026-11-05 14:49:25 | 52dc5263-336b-4f5f-b9ab-2b33d61436da ===
[14:49:26] dialog_step=00_00_continuity__main | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[14:49:39] dialog_step=confirmation__01_02_why_card_blocked__start | intent=why_card_blocked
CLIENT: мне нужно с оператором поговорить меня заблокировали
[14:49:39] dialog_step=confirmation__01_02_why_card_blocked__start | intent=why_card_blocked
BOT: Я правильно понял, что вы хотите узнать причину блокировки карты?
[14:49:49] dialog_step=confirmation__01_02_why_card_blocked__start | intent=silence
CLIENT: <SILENCE>
[14:49:49] dialog_step=confirmation__01_02_why_card_blocked__start | intent=silence
BOT: Я правильно понял, что вы хотите узнать причину блокировки карты?
[14:49:56] dialog_step=00_01_identification__greeting | intent=agree
CLIENT: а-да-да да да
[14:49:56] dialog_step=00_01_identification__greeting | intent=agree
BOT: Уважаемый клиент, для предоставления ответа на Ваш вопрос необходимо пройти идентификацию личности по цифровому документу, если Вы согласны я подскажу куда заходить.
[14:50:22] dialog_step=00_01_identification__greeting | intent=unknown
CLIENT: что будешь делать вы можете когда вот и записываете нормально микрофон подключать если это не то можете ближе к микрофону разговаривать у вас там шум
[14:50:22] dialog_step=00_01_identification__greeting | intent=unknown
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[14:50:38] dialog_step=00_01_identification__greeting | intent=unknown
CLIENT: можете четко разговаривать ближе к микрофону убрать шум сзадя не слышно клиенту как вы разговариваете
[14:50:38] dialog_step=00_01_identification__greeting | intent=unknown
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[14:50:45] dialog_step=00_01_identification__greeting | intent=talk_to_operator
CLIENT: подключите к оператору
[14:50:45] dialog_step=00_01_identification__greeting | intent=talk_to_operator
BOT: Уважаемый клиент, чтобы не тратить ваше время на переключение, давайте попробуем решить вопрос здесь. Если потребуется специалист, я подключу.
Уважаемый клиент, для предоставления ответа на Ваш вопрос необходимо пройти идентификацию личности по цифровому документу, если Вы согласны я подскажу куда заходить.
[14:51:10] dialog_step=00_01_identification__gov_services_confirmation | intent=what
CLIENT: куда заходить егов
[14:51:10] dialog_step=00_01_identification__gov_services_confirmation | intent=what
BOT: Пожалуйста, откройте приложение Халык <pause_1> и перейдите в раздел "Госуслуги" <pause_1> Я подожду. <pause_5>
Подскажите, вы перешли в раздел "Госуслуги"?
[14:51:39] dialog_step=00_01_identification__gov_services_confirmation | intent=unknown
CLIENT: никакие эти не принимате вы сами себе жизнь усложняете я не могу просто закинуть долбаные деньги хотя я ужебила эти настройки
[14:51:39] dialog_step=00_01_identification__gov_services_confirmation | intent=unknown
BOT: Пожалуйста, откройте приложение Халык <pause_1> и перейдите в раздел "Госуслуги" <pause_1> Я подожду. <pause_5>
Подскажите, вы перешли в раздел "Госуслуги"?
[14:52:04] dialog_step=00_01_identification__gov_services_confirmation | intent=unknown
CLIENT: нормальный человек вот так записывает и голос вы хотя бы задний шум выключили бы вас не слышно
[14:52:04] dialog_step=00_01_identification__gov_services_confirmation | intent=unknown
BOT: Пожалуйста, откройте приложение Халык <pause_1> и перейдите в раздел "Госуслуги" <pause_1> Я подожду. <pause_5>
Подскажите, вы перешли в раздел "Госуслуги"?
```

## SAMPLE 15 | CALL 67999 | 2026-11-06 09:25:51 | 17457877-08f0-49fe-8a90-861473deb41e

Stratum: service_journey | client turns: 3 | unknown-content turns: 1 | silence: 0 | repeated bot events: 0 | services: 03_06_new_credit | language mismatches: 0

```text
=== CALL 67999 | 2026-11-06 09:25:51 | 17457877-08f0-49fe-8a90-861473deb41e ===
[09:25:51] dialog_step=00_00_continuity__main | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[09:26:03] dialog_step=00_00_continuity__main | intent=talk_to_operator
CLIENT: оператормен байланыс
[09:26:03] dialog_step=00_00_continuity__main | intent=talk_to_operator
BOT: Уважаемый клиент, чтобы не тратить ваше время на переключение, давайте попробуем решить вопрос здесь. Если потребуется специалист, я подключу.
Скажите, чем я могу вам помочь?
[09:26:19] dialog_step=03_06_new_credit__start | intent=cash_credit
CLIENT: кредит туралы
[09:26:19] dialog_step=03_06_new_credit__start | intent=cash_credit
BOT: Дорогой клиент, вы можете оформить кредит онлайн через мобильное приложение и посмотреть свои возможности, не выходя из дома. Для этого необходимо зайти на главную страницу - выбрать раздел «Кредиты» - «Онлайн-кредит или Рефинансирование» - «Получить» и следуйте инструкциям.
[09:26:45] dialog_step=unknown | intent=unknown
CLIENT: оператормен байланыс
[09:26:46] dialog_step=unknown | intent=talk_to_operator
BOT: Хорошо, переключаю звонок на специалиста, оставайтесь на линии.
```

## SAMPLE 16 | CALL 75955 | 2026-11-06 14:47:55 | ea3dcfe9-9de0-4f71-bf00-c47d52ef6dd1

Stratum: service_journey | client turns: 10 | unknown-content turns: 2 | silence: 0 | repeated bot events: 2 | services: 25_15_recipient_not_received, 20_05_card_transfer_not_received | language mismatches: 0

```text
=== CALL 75955 | 2026-11-06 14:47:55 | ea3dcfe9-9de0-4f71-bf00-c47d52ef6dd1 ===
[14:47:58] dialog_step=00_00_continuity__main | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[14:48:15] dialog_step=25_15_recipient_not_received__start | intent=recipient_not_received
CLIENT: айдос ол үшін менің осы народный банктің өзге банкке аударған ақша қаражатым түспей тұр соның нақты себебін білейін деп едім
[14:48:15] dialog_step=25_15_recipient_not_received__start | intent=recipient_not_received
BOT: Уточните, пожалуйста, вы отправили перевод, а получатель говорит, что деньги не поступили?
[14:48:23] dialog_step=25_15_recipient_not_received__start | intent=unknown
CLIENT: казахском
[14:48:23] dialog_step=25_15_recipient_not_received__start | intent=unknown
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[14:48:30] dialog_step=25_15_recipient_not_received__start | intent=change_lang_kz
CLIENT: можно на казахском
[14:48:30] dialog_step=25_15_recipient_not_received__start | intent=change_lang_kz
BOT: Нақтылап жіберіңізші, сіз аударым жасадыңыз, ал алушы ақша түспегенін айтып отыр ма?
[14:48:41] dialog_step=confirmation__20_05_card_transfer_not_received__start | intent=pin__ne_perevod_dengi
CLIENT: иә ақша түспегенін айтып отыр соның нақты себебін анықтау керек
[14:48:41] dialog_step=confirmation__20_05_card_transfer_not_received__start | intent=pin__ne_perevod_dengi
BOT: Картаңызға аударым түспегенін дұрыс түсіндім бе?
[14:48:51] dialog_step=25_15_recipient_not_received__start | intent=recipient_not_received
CLIENT: картама менің аударған ақшам өзі счетқа түспеген
[14:48:51] dialog_step=25_15_recipient_not_received__start | intent=recipient_not_received
BOT: Нақтылап жіберіңізші, сіз аударым жасадыңыз, ал алушы ақша түспегенін айтып отыр ма?
[14:48:59] dialog_step=25_15_recipient_not_received__answer | intent=agree
CLIENT: иә
[14:48:59] dialog_step=25_15_recipient_not_received__answer | intent=agree
BOT: Құрметті клиент, бұл жағдайда орындалған операцияны растау үшін алушыға түбіртекті жібере аласыз. <pause_1> Түбіртекті алу үшін «Аударымдар» бөліміне өтіп, «Тарих» бөліміне өтіңіз. Жасаған аударымыңызды тауып, оны басыңыз. Одан кейін түбіртек көрсетіледі. «Бөлісу» функциясын пайдаланып, чекті алушыға жібере аласыз. <pause_1> Егер алушының деректемелері дұрыс көрсетілсе, қате алушының банкі тарапынан болуы мүмкін. Бұл жағдайда алушы өз банкіне хабарласуы қажет. <pause_1> Қосымша сұрақтарыңыз бар ма?
[14:49:13] dialog_step=25_15_recipient_not_received__answer | intent=talk_to_operator
CLIENT: оператормен байланыс
[14:49:13] dialog_step=25_15_recipient_not_received__answer | intent=talk_to_operator
BOT: Құрметті клиент, уақытыңызды үнемдеу үшін, сұрағыңызды осы жерде шешуге тырысайық. Қажет болса, маманға қосамын.
Құрметті клиент, бұл жағдайда орындалған операцияны растау үшін алушыға түбіртекті жібере аласыз. <pause_1> Түбіртекті алу үшін «Аударымдар» бөліміне өтіп, «Тарих» бөліміне өтіңіз. Жасаған аударымыңызды тауып, оны басыңыз. Одан кейін түбіртек көрсетіледі. «Бөлісу» функциясын пайдаланып, чекті алушыға жібере аласыз. <pause_1> Егер алушының деректемелері дұрыс көрсетілсе, қате алушының банкі тарапынан болуы мүмкін. Бұл жағдайда алушы өз банкіне хабарласуы қажет. <pause_1> Қосымша сұрақтарыңыз бар ма?
[14:49:24] dialog_step=25_15_recipient_not_received__answer | intent=unknown
CLIENT: маған уақытты өтеудің қажеттігі жоқ оператормен байланыстырыңыз
[14:49:24] dialog_step=25_15_recipient_not_received__answer | intent=unknown
BOT: Мен сізді толық түсінбедім, қайтадан басқаша айтып бересіз бе?
[14:49:34] dialog_step=25_15_recipient_not_received__answer | intent=unknown
CLIENT: маған уақыт төңдеудің қажеттілігі оператормен байланыстырыңыз
[14:49:34] dialog_step=25_15_recipient_not_received__answer | intent=unknown
BOT: Мен сізді толық түсінбедім, қайтадан басқаша айтып бересіз бе?
[14:49:41] dialog_step=unknown | intent=talk_to_operator
CLIENT: оператормен байланыстырыңыз
[14:49:41] dialog_step=unknown | intent=talk_to_operator
BOT: Жақсы, қоңырауды операторға қосамын, желіден ажырамаңыз.
```

## SAMPLE 17 | CALL 84422 | 2026-11-07 10:29:11 | ef8c24fd-68e0-457e-aad2-8db8ada105dd

Stratum: service_journey | client turns: 4 | unknown-content turns: 1 | silence: 0 | repeated bot events: 0 | services: 05_01_unblock_app | language mismatches: 0

```text
=== CALL 84422 | 2026-11-07 10:29:11 | ef8c24fd-68e0-457e-aad2-8db8ada105dd ===
[10:29:11] dialog_step=00_00_continuity__language_ask | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Айтыңызшы, сізге қай тіл ыңғайлы болады - қазақ немесе орыс тілдерінде? Скажите, пожалуйста, на каком языке вам будет удобнее - на казахском или русском?
[10:29:27] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: казахский
[10:29:27] dialog_step=00_00_continuity__main | intent=unknown
BOT: Сәлеметсіз бе! Мен виртуалды көмекшімін, есімім Айдос. Қандай көмегім керек?
[10:29:40] dialog_step=confirmation__05_01_unblock_app__start | intent=unblock_app
CLIENT: халық банкына доступы ашып беріңізші блокты
[10:29:40] dialog_step=confirmation__05_01_unblock_app__start | intent=unblock_app
BOT: Сіз қосымшаны бұғаттан шығарғыңыз келеді деп дұрыс түсіндім бе?
[10:29:48] dialog_step=00_07_proceed_untrusted__start | intent=unblock_app
CLIENT: приложениені блоктан шығару керек приложение ашылмай тұр
[10:29:48] dialog_step=00_07_proceed_untrusted__start | intent=unblock_app
BOT: Сіздің нөміріңіз расталмаған, сондықтан мен ақпарат бере алмаймын. Нөмірді қалай сенімді ету керектігін айта аласыз ба?
[10:30:01] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: осы не істеуі керек
[10:30:01] dialog_step=00_00_continuity__main | intent=unknown
BOT: Мен сізге тағы қандай көмек бере аламын?
```

## SAMPLE 18 | CALL 100707 | 2026-11-09 11:38:40 | 9b1d1916-6933-4640-ac10-a41747af7f8a

Stratum: service_journey | client turns: 8 | unknown-content turns: 2 | silence: 2 | repeated bot events: 2 | services: 01_03_card_withdrawal_fail | language mismatches: 0

```text
=== CALL 100707 | 2026-11-09 11:38:40 | 9b1d1916-6933-4640-ac10-a41747af7f8a ===
[11:38:41] dialog_step=00_00_continuity__main | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[11:38:54] dialog_step=confirmation__01_03_card_withdrawal_fail__start | intent=card_withdrawal_fail
CLIENT: хотела снять деньги с банкомата он мне не выдал
[11:38:54] dialog_step=confirmation__01_03_card_withdrawal_fail__start | intent=card_withdrawal_fail
BOT: Подскажите пожалуйста, у Вас не получается снять денежные средства посредством банкомата?
[11:39:06] dialog_step=00_01_identification__greeting | intent=card_withdrawal_fail
CLIENT: не получилось банкомат деньги не выдал но
[11:39:06] dialog_step=00_01_identification__greeting | intent=card_withdrawal_fail
BOT: Уважаемый клиент, для предоставления ответа на Ваш вопрос необходимо пройти идентификацию личности по цифровому документу, если Вы согласны я подскажу куда заходить.
[11:39:21] dialog_step=00_01_identification__gov_services_confirmation | intent=agree
CLIENT: хорошо
[11:39:21] dialog_step=00_01_identification__gov_services_confirmation | intent=agree
BOT: Пожалуйста, откройте приложение Халык <pause_1> и перейдите в раздел "Госуслуги" <pause_1> Я подожду. <pause_5>
Подскажите, вы перешли в раздел "Госуслуги"?
[11:39:40] dialog_step=00_01_identification__gov_services_confirmation | intent=unable
CLIENT: не открывается
[11:39:40] dialog_step=00_01_identification__gov_services_confirmation | intent=unable
BOT: Хорошо, подожду. Сообщите, когда будете готовы. <pause_5>
Подскажите, вы перешли в раздел "Госуслуги"?
[11:39:58] dialog_step=00_01_identification__gov_services_confirmation | intent=silence
CLIENT: <SILENCE>
[11:39:58] dialog_step=00_01_identification__gov_services_confirmation | intent=silence
BOT: Подскажите, вы перешли в раздел "Госуслуги"?
[11:40:03] dialog_step=00_01_identification__gov_services_confirmation | intent=unknown
CLIENT: что только
[11:40:03] dialog_step=00_01_identification__gov_services_confirmation | intent=unknown
BOT: Пожалуйста, откройте приложение Халык <pause_1> и перейдите в раздел "Госуслуги" <pause_1> Я подожду. <pause_5>
Подскажите, вы перешли в раздел "Госуслуги"?
[11:40:24] dialog_step=00_01_identification__gov_services_confirmation | intent=silence
CLIENT: <SILENCE>
[11:40:24] dialog_step=00_01_identification__gov_services_confirmation | intent=silence
BOT: Подскажите, вы перешли в раздел "Госуслуги"?
[11:40:35] dialog_step=unknown | intent=unknown
CLIENT: ой деби на
[11:40:35] dialog_step=unknown | intent=unknown
BOT: Хорошо, переключаю звонок на специалиста, оставайтесь на линии.
```

## SAMPLE 19 | CALL 105670 | 2026-11-09 15:12:43 | f0f366e3-085a-4f3b-be85-22be53a65e32

Stratum: service_journey | client turns: 13 | unknown-content turns: 4 | silence: 1 | repeated bot events: 6 | services: 09_01_unblocking_card, 20_01_set_card_pin, 03_08_change_payment_date | language mismatches: 0

```text
=== CALL 105670 | 2026-11-09 15:12:43 | f0f366e3-085a-4f3b-be85-22be53a65e32 ===
[15:12:43] dialog_step=00_00_continuity__main | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Сәлеметсіз бе! Мен виртуалды көмекшімін, есімім Айдос. Қандай көмегім керек?
[15:13:03] dialog_step=confirmation__09_01_unblocking_card__start | intent=razblock_card__razblock
CLIENT: саламатсыз ба ма менде заблокировать етіліп қалды картам пин кодты дұрыс жазбай қалай ашамын қайтадан
[15:13:03] dialog_step=confirmation__09_01_unblocking_card__start | intent=razblock_card__razblock
BOT: Картаңызды бұғаттан шығарғыңыз келеді деп дұрыс түсіндім бе?
[15:13:09] dialog_step=09_01_unblocking_card__ask_identification_for_details | intent=agree
CLIENT: иә
[15:13:09] dialog_step=09_01_unblocking_card__ask_identification_for_details | intent=agree
BOT: Егер картаңыз уақытша бұғатталған болса, Халық қосымшасын пайдалана отырып, бұғаттауды өз бетіңізше алып тастай аласыз. Ол үшін Сізге "Менің банкім" бөлімінде - Картаңызды таңдау керек - "Бұғаттаулар" батырмасын басу керек - содан кейін "Уақытша оқшаулау" функциясын өшіру керек.
Толығырақ ақпарат алу үшін жеке тұлғаны сәйкестендіруден өту қажет. Сәйкестендіруден өткіңіз келе ме?
[15:13:37] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: ой не қыламыз сол өзім ғой звондап тұрған
[15:13:37] dialog_step=00_00_continuity__main | intent=unknown
BOT: Мен сізге тағы қандай көмек бере аламын?
[15:13:47] dialog_step=20_01_set_card_pin__start | intent=pin__ustanovka_pin
CLIENT: пинкодты қалай ауыстырамын пин-код ауыстыратын затым жоқ ана жерде менде не приложениеде
[15:13:47] dialog_step=20_01_set_card_pin__start | intent=pin__ustanovka_pin
BOT: Қараңыз, пин-кодты Халық қосымшасы арқылы оңай орнатуға немесе өзгертуге болады. Мұны қалай жасауға болатынын айтып берейін, келісесіз бе?
[15:13:58] dialog_step=20_01_set_card_pin__pin_code_change_instruction | intent=agree
CLIENT: иә
[15:13:58] dialog_step=20_01_set_card_pin__pin_code_change_instruction | intent=agree
BOT: Жақсы! ПИН-кодты орнату немесе өзгерту үшін Халық қосымшасын пайдалана аласыз. «Менің банкім» бөліміне кіріп, ПИН-кодты орнату немесе өзгерту қажет картаны таңдаңыз. Одан кейін «Баптаулар» бөліміне өтіп, «ПИН-код» тармағын таңдаңыз және нұсқауларды орындаңыз.
[15:14:21] dialog_step=03_08_change_payment_date__start | intent=change_payment_date
CLIENT: настройки да сменить
[15:14:21] dialog_step=03_08_change_payment_date__start | intent=change_payment_date
BOT: Құрметті клиент, несие бойынша төлем күнін Халық қосымшасында өзгертуге болады. <pause_1> Ол үшін «Менің банкім» бөліміне өтіңіз. Қажетті кредитті басыңыз. «Кредит талаптары» бөліміне өтіңіз. «Кредит талаптарын өзгерту» батырмасын басыңыз. «Жаңа күнді таңдау» опциясын таңдаңыз. <pause_1> Төлем күнін тек ай сайынғы төлем жасалғаннан кейін ағымдағы айда өзгертуге болады. <pause_1> Төлем күнін өзгерткені үшін комиссия алынуы мүмкін. Оның мөлшері кредитіңіздің шарттарына байланысты. Төлем күнін өзгерту кезінде комиссия мөлшері қосымшада көрсетіледі. <pause_1> Қосымша сұрақтарыңыз бар ма?
[15:15:11] dialog_step=03_08_change_payment_date__start | intent=silence
CLIENT: <SILENCE>
[15:15:11] dialog_step=03_08_change_payment_date__start | intent=silence
BOT: Құрметті клиент, несие бойынша төлем күнін Халық қосымшасында өзгертуге болады. <pause_1> Ол үшін «Менің банкім» бөліміне өтіңіз. Қажетті кредитті басыңыз. «Кредит талаптары» бөліміне өтіңіз. «Кредит талаптарын өзгерту» батырмасын басыңыз. «Жаңа күнді таңдау» опциясын таңдаңыз. <pause_1> Төлем күнін тек ай сайынғы төлем жасалғаннан кейін ағымдағы айда өзгертуге болады. <pause_1> Төлем күнін өзгерткені үшін комиссия алынуы мүмкін. Оның мөлшері кредитіңіздің шарттарына байланысты. Төлем күнін өзгерту кезінде комиссия мөлшері қосымшада көрсетіледі. <pause_1> Қосымша сұрақтарыңыз бар ма?
[15:15:15] dialog_step=03_08_change_payment_date__start | intent=silence
BOT: Құрметті клиент, несие бойынша төлем күнін Халық қосымшасында өзгертуге болады. <pause_1> Ол үшін «Менің банкім» бөліміне өтіңіз. Қажетті кредитті басыңыз. «Кредит талаптары» бөліміне өтіңіз. «Кредит талаптарын өзгерту» батырмасын басыңыз. «Жаңа күнді таңдау» опциясын таңдаңыз. <pause_1> Төлем күнін тек ай сайынғы төлем жасалғаннан кейін ағымдағы айда өзгертуге болады. <pause_1> Төлем күнін өзгерткені үшін комиссия алынуы мүмкін. Оның мөлшері кредитіңіздің шарттарына байланысты. Төлем күнін өзгерту кезінде комиссия мөлшері қосымшада көрсетіледі. <pause_1> Қосымша сұрақтарыңыз бар ма?
[15:15:33] dialog_step=confirmation__09_01_unblocking_card__start | intent=razblock_card__razblock
CLIENT: маған заблокировать еткер қайтадан ашуым керек енді заблокироватьсяны оны аша алмайтын сияқтымын
[15:15:33] dialog_step=confirmation__09_01_unblocking_card__start | intent=razblock_card__razblock
BOT: Картаңызды бұғаттан шығарғыңыз келеді деп дұрыс түсіндім бе?
[15:15:39] dialog_step=09_01_unblocking_card__ask_identification_for_details | intent=agree
CLIENT: иә
[15:15:39] dialog_step=09_01_unblocking_card__ask_identification_for_details | intent=agree
BOT: Егер картаңыз уақытша бұғатталған болса, Халық қосымшасын пайдалана отырып, бұғаттауды өз бетіңізше алып тастай аласыз. Ол үшін Сізге "Менің банкім" бөлімінде - Картаңызды таңдау керек - "Бұғаттаулар" батырмасын басу керек - содан кейін "Уақытша оқшаулау" функциясын өшіру керек.
Толығырақ ақпарат алу үшін жеке тұлғаны сәйкестендіруден өту қажет. Сәйкестендіруден өткіңіз келе ме?
[15:15:47] dialog_step=09_01_unblocking_card__ask_identification_for_details | intent=silence
BOT: Толығырақ ақпарат алу үшін жеке тұлғаны сәйкестендіруден өту қажет. Сәйкестендіруден өткіңіз келе ме?
[15:15:55] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: здравствуйте
[15:15:55] dialog_step=00_00_continuity__main | intent=unknown
BOT: Мен сізге тағы қандай көмек бере аламын?
[15:16:02] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: ойбай сәйкестендір біз қалай өтеміз
[15:16:02] dialog_step=00_00_continuity__main | intent=unknown
BOT: Мен сізді толық түсінбедім, қайтадан басқаша айтып бересіз бе?
[15:16:12] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: сізді қалай өтеміз сәйкестендірг өткіңіз келеді ме дедіңіз ғой оны қалай өтеміз
[15:16:12] dialog_step=00_00_continuity__main | intent=unknown
BOT: Мен сізді толық түсінбедім, қайтадан басқаша айтып бересіз бе?
[15:16:24] dialog_step=unknown | intent=unknown
CLIENT: бұғаттауды алу үшін сәйкестендіру өтуіңіз керек дедіңіз ғой солай ма
[15:16:24] dialog_step=unknown | intent=unknown
BOT: Жақсы, қоңырауды операторға қосамын, желіден ажырамаңыз.
```

## SAMPLE 20 | CALL 116605 | 2026-11-10 12:27:40 | 016516e8-ab8a-4dd5-94aa-a413f5844886

Stratum: service_journey | client turns: 6 | unknown-content turns: 1 | silence: 0 | repeated bot events: 0 | services: 09_05_limits_ptp | language mismatches: 0

```text
=== CALL 116605 | 2026-11-10 12:27:40 | 016516e8-ab8a-4dd5-94aa-a413f5844886 ===
[12:27:40] dialog_step=00_00_continuity__language_ask | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Айтыңызшы, сізге қай тіл ыңғайлы болады - қазақ немесе орыс тілдерінде? Скажите, пожалуйста, на каком языке вам будет удобнее - на казахском или русском?
[12:27:56] dialog_step=00_00_continuity__main | intent=change_lang_kz
CLIENT: қазақ тілі
[12:27:56] dialog_step=00_00_continuity__main | intent=change_lang_kz
BOT: Сәлеметсіз бе! Мен виртуалды көмекшімін, есімім Айдос. Қандай көмегім керек?
[12:28:05] dialog_step=00_00_continuity__main | intent=talk_to_operator
CLIENT: маған оператормен байланысу керек
[12:28:05] dialog_step=00_00_continuity__main | intent=talk_to_operator
BOT: Құрметті клиент, уақытыңызды үнемдеу үшін, сұрағыңызды осы жерде шешуге тырысайық. Қажет болса, маманға қосамын.
Айтыңызшы, мен сізге қалай көмектесе аламын?
[12:28:19] dialog_step=confirmation__09_05_limits_ptp__start | intent=razblock_card__snyat_ogr
CLIENT: арест жөнінде
[12:28:19] dialog_step=confirmation__09_05_limits_ptp__start | intent=razblock_card__snyat_ogr
BOT: Карта шектеулері туралы сұрағыңыз бар екенін дұрыс түсіндім бе?
[12:28:26] dialog_step=09_05_limits_ptp__proceed_untrusted_explained | intent=agree
CLIENT: иә иә
[12:28:26] dialog_step=09_05_limits_ptp__proceed_untrusted_explained | intent=agree
BOT: Құрметті клиент, егер сізге екінші деңгейлі банк тарапынан төлем бойынша ұйғарым қойылса, толық ақпарат алу үшін Арыз беруші (Арест инициаторы) тарапқа жүгінуіңізді сұраймыз. Сондай-ақ, Аресттер туралы ақпаратты Халық қосымшасындағы «Менің банкім» бөлімінен, Арест мәртебесі бар картаны таңдау арқылы біле аласыз. <pause_2>
[12:28:49] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: байланысу керек
[12:28:49] dialog_step=00_00_continuity__main | intent=unknown
BOT: Мен сізге тағы қандай көмек бере аламын?
[12:28:56] dialog_step=unknown | intent=talk_to_operator
CLIENT: оператормен байланысу керек
[12:28:56] dialog_step=unknown | intent=talk_to_operator
BOT: Жақсы, қоңырауды операторға қосамын, желіден ажырамаңыз.
```

## SAMPLE 21 | CALL 124808 | 2026-11-10 18:32:33 | 3bc2fb49-091f-4f27-8a47-a80a9f442286

Stratum: service_journey | client turns: 2 | unknown-content turns: 0 | silence: 0 | repeated bot events: 1 | services: 25_07_deposit_withdrawal | language mismatches: 0

```text
=== CALL 124808 | 2026-11-10 18:32:33 | 3bc2fb49-091f-4f27-8a47-a80a9f442286 ===
[18:32:33] dialog_step=00_00_continuity__language_ask | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Айтыңызшы, сізге қай тіл ыңғайлы болады - қазақ немесе орыс тілдерінде? Скажите, пожалуйста, на каком языке вам будет удобнее - на казахском или русском?
[18:32:49] dialog_step=00_00_continuity__main | intent=change_lang_ru
CLIENT: русском
[18:32:49] dialog_step=00_00_continuity__main | intent=change_lang_ru
BOT: Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[18:33:05] dialog_step=25_07_deposit_withdrawal__start | intent=deposit_withdrawal
CLIENT: деньги у меня лежат на депозите в городе усть каменогорск приехав в город астана я могу их снять с депозита
[18:33:05] dialog_step=25_07_deposit_withdrawal__start | intent=deposit_withdrawal
BOT: При частичном изъятии средств с депозита «Универсальный» через приложение или отделение банка вы можете снять деньги без комиссии через три дня после пополнения депозита. Если снять деньги раньше, будет удержана комиссия в размере одного процента от суммы снятия. <pause_1> Если сумма снятия превышает два миллиона тенге, необходимо заранее, не менее чем за один рабочий день, заказать наличные через приложение или в отделении банка. <pause_1> Вам подсказать, как заказать наличные?
[18:33:27] dialog_step=25_07_deposit_withdrawal__start | intent=silence
BOT: При частичном изъятии средств с депозита «Универсальный» через приложение или отделение банка вы можете снять деньги без комиссии через три дня после пополнения депозита. Если снять деньги раньше, будет удержана комиссия в размере одного процента от суммы снятия. <pause_1> Если сумма снятия превышает два миллиона тенге, необходимо заранее, не менее чем за один рабочий день, заказать наличные через приложение или в отделении банка. <pause_1> Вам подсказать, как заказать наличные?
```

## SAMPLE 22 | CALL 135344 | 2026-11-11 15:04:26 | f6d76bba-c623-4788-be18-3b05ff09abe5

Stratum: service_journey | client turns: 7 | unknown-content turns: 3 | silence: 0 | repeated bot events: 2 | services: 24_04_hsa_certificates | language mismatches: 0

```text
=== CALL 135344 | 2026-11-11 15:04:26 | f6d76bba-c623-4788-be18-3b05ff09abe5 ===
[15:04:27] dialog_step=00_00_continuity__main | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[15:04:44] dialog_step=24_04_hsa_certificates__start | intent=hsa_certificates
CLIENT: здравствуйте айдос я хотела бы для бухгалтерии взять счет свой
[15:04:44] dialog_step=24_04_hsa_certificates__start | intent=hsa_certificates
BOT: Дорогой клиент, в приложении Халык бесплатно доступны справки о доступном остатке, о наличии счёта и о задолженности. Чтобы получить справку, необходимо на главной странице перейти в свой профиль в правом в верхнем углу и выбрать «Справки». Справку можно сформировать по текущему счёту, депозиту и платёжной карте, кроме кредитных карт, спецсчёта для пособий и спецсчёта Национального фонда. У Вас будут дополнительные вопросы?
[15:04:47] dialog_step=24_04_hsa_certificates__start | intent=unknown
CLIENT: я получить ьёз
[15:04:47] dialog_step=24_04_hsa_certificates__start | intent=unknown
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[15:05:01] dialog_step=24_04_hsa_certificates__start | intent=unknown
CLIENT: на длятелей лицевой шф свой банка
[15:05:01] dialog_step=24_04_hsa_certificates__start | intent=unknown
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[15:05:09] dialog_step=24_04_hsa_certificates__start | intent=talk_to_operator
CLIENT: подключите мне смотрешке
[15:05:09] dialog_step=24_04_hsa_certificates__start | intent=talk_to_operator
BOT: Уважаемый клиент, чтобы не тратить ваше время на переключение, давайте попробуем решить вопрос здесь. Если потребуется специалист, я подключу.
Дорогой клиент, в приложении Халык бесплатно доступны справки о доступном остатке, о наличии счёта и о задолженности. Чтобы получить справку, необходимо на главной странице перейти в свой профиль в правом в верхнем углу и выбрать «Справки». Справку можно сформировать по текущему счёту, депозиту и платёжной карте, кроме кредитных карт, спецсчёта для пособий и спецсчёта Национального фонда. У Вас будут дополнительные вопросы?
[15:05:51] dialog_step=24_04_hsa_certificates__start | intent=unknown
CLIENT: подключите меня который
[15:05:51] dialog_step=24_04_hsa_certificates__start | intent=unknown
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[15:05:59] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
CLIENT: подключите меня к оператору
[15:05:59] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
BOT: Сейчас я переведу вас на оператора. Подскажите, пожалуйста, причину обращения, чтобы я мог направить вас к нужному специалисту.
[15:06:11] dialog_step=unknown | intent=card_requisites_info
CLIENT: нужен счет
[15:06:11] dialog_step=unknown | intent=card_requisites_info
BOT: Хорошо, переключаю звонок на специалиста, оставайтесь на линии.
```

## SAMPLE 23 | CALL 4765 | 2026-11-01 20:46:52 | e158a324-12a2-4a16-900d-39f6ac2feac0

Stratum: unknown_without_service | client turns: 4 | unknown-content turns: 3 | silence: 0 | repeated bot events: 1 | services: none | language mismatches: 0

```text
=== CALL 4765 | 2026-11-01 20:46:52 | e158a324-12a2-4a16-900d-39f6ac2feac0 ===
[20:46:52] dialog_step=00_00_continuity__language_ask | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Айтыңызшы, сізге қай тіл ыңғайлы болады - қазақ немесе орыс тілдерінде? Скажите, пожалуйста, на каком языке вам будет удобнее - на казахском или русском?
[20:47:07] dialog_step=00_00_continuity__main | intent=change_lang_kz
CLIENT: қазақша
[20:47:07] dialog_step=00_00_continuity__main | intent=change_lang_kz
BOT: Сәлеметсіз бе! Мен виртуалды көмекшімін, есімім Айдос. Қандай көмегім керек?
[20:47:16] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: на былай сұрақ бар еді
[20:47:16] dialog_step=00_00_continuity__main | intent=unknown
BOT: Мен сізді толық түсінбедім, қайтадан басқаша айтып бересіз бе?
[20:47:25] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: халық банкінің банкомат несіне форте банк
[20:47:25] dialog_step=00_00_continuity__main | intent=unknown
BOT: Мен сізді толық түсінбедім, қайтадан басқаша айтып бересіз бе?
[20:47:31] dialog_step=00_00_continuity__main | intent=silence
BOT: Мен сізді анық естімедім, қайталап жіберіңізші.
[20:47:42] dialog_step=unknown | intent=unknown
CLIENT: форте банктің карточкасын банкоматқа салуға келеді ме халық банкі банкоматынан
[20:47:42] dialog_step=unknown | intent=unknown
BOT: Жақсы, қоңырауды операторға қосамын, желіден ажырамаңыз.
```

## SAMPLE 24 | CALL 22560 | 2026-11-03 11:01:36 | c826053f-925d-4ab2-b1bf-3efc561b1b97

Stratum: unknown_without_service | client turns: 5 | unknown-content turns: 2 | silence: 0 | repeated bot events: 1 | services: none | language mismatches: 0

```text
=== CALL 22560 | 2026-11-03 11:01:36 | c826053f-925d-4ab2-b1bf-3efc561b1b97 ===
[11:01:39] dialog_step=00_00_continuity__main | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Здравствуйте! Я виртуальный помощник Айдос. Чем могу помочь?
[11:01:50] dialog_step=00_00_continuity__main | intent=talk_to_operator
CLIENT: свяжите меня с оператором
[11:01:50] dialog_step=00_00_continuity__main | intent=talk_to_operator
BOT: Уважаемый клиент, чтобы не тратить ваше время на переключение, давайте попробуем решить вопрос здесь. Если потребуется специалист, я подключу.
Скажите, чем я могу вам помочь?
[11:02:07] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: мне срочно нужен специалист ситуация сложная
[11:02:07] dialog_step=00_00_continuity__main | intent=unknown
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[11:02:16] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: можно ли нанять специалиста на дом
[11:02:16] dialog_step=00_00_continuity__main | intent=unknown
BOT: Я не до конца вас понял, не могли бы вы переформулировать?
[11:02:24] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
CLIENT: свяжите меня с оператором
[11:02:24] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
BOT: Сейчас я переведу вас на оператора. Подскажите, пожалуйста, причину обращения, чтобы я мог направить вас к нужному специалисту.
[11:02:38] dialog_step=unknown | intent=reissue_card
CLIENT: истек срок годности карты карту зажевала
[11:02:38] dialog_step=unknown | intent=reissue_card
BOT: Хорошо, переключаю звонок на специалиста, оставайтесь на линии.
```

## SAMPLE 25 | CALL 38674 | 2026-11-04 12:25:24 | 9771b3da-f488-483c-a036-cde880aece91

Stratum: unknown_without_service | client turns: 6 | unknown-content turns: 1 | silence: 1 | repeated bot events: 1 | services: none | language mismatches: 0

```text
=== CALL 38674 | 2026-11-04 12:25:24 | 9771b3da-f488-483c-a036-cde880aece91 ===
[12:25:24] dialog_step=00_00_continuity__language_ask | intent=unknown
BOT: Әңгіме жазылуда. Разговор записывается.
Айтыңызшы, сізге қай тіл ыңғайлы болады - қазақ немесе орыс тілдерінде? Скажите, пожалуйста, на каком языке вам будет удобнее - на казахском или русском?
[12:25:41] dialog_step=00_00_continuity__main | intent=change_lang_kz
CLIENT: қазақ тілінде
[12:25:41] dialog_step=00_00_continuity__main | intent=change_lang_kz
BOT: Сәлеметсіз бе! Мен виртуалды көмекшімін, есімім Айдос. Қандай көмегім керек?
[12:25:49] dialog_step=00_00_continuity__main | intent=unknown
CLIENT: меня зовут молодых
[12:25:49] dialog_step=00_00_continuity__main | intent=unknown
BOT: Мен сізді толық түсінбедім, қайтадан басқаша айтып бересіз бе?
[12:25:55] dialog_step=00_00_continuity__main | intent=talk_to_operator
CLIENT: операторға қосасыз ба
[12:25:55] dialog_step=00_00_continuity__main | intent=talk_to_operator
BOT: Құрметті клиент, уақытыңызды үнемдеу үшін, сұрағыңызды осы жерде шешуге тырысайық. Қажет болса, маманға қосамын.
Айтыңызшы, мен сізге қалай көмектесе аламын?
[12:26:12] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
CLIENT: оператормен сөйлесре аласыз ба оператормен
[12:26:12] dialog_step=00_06_reask_before_operator__first_ask | intent=talk_to_operator
BOT: Қазір сізді операторға қосамын. Қажетті маманға бағыттауым үшін хабарласу себебін айтыңызшы.
[12:26:23] dialog_step=00_06_reask_before_operator__first_ask | intent=silence
CLIENT: <SILENCE>
[12:26:23] dialog_step=00_06_reask_before_operator__first_ask | intent=silence
BOT: Қазір сізді операторға қосамын. Қажетті маманға бағыттауым үшін хабарласу себебін айтыңызшы.
[12:26:36] dialog_step=unknown | intent=unblock_app
CLIENT: аха приложениені блоктан шығару керек
[12:26:36] dialog_step=unknown | intent=unblock_app
BOT: Жақсы, қоңырауды операторға қосамын, желіден ажырамаңыз.
```
