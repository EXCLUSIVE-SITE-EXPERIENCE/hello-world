# Best in-sample F1 thresholds

**Exploratory only: thresholds were selected and measured on the same 50 AI-annotated calls. Re-fit on human training data and validate on a separate held-out set.**

| Model | Question | Threshold | Precision | Recall | F1 | Brier |
|---|---|---:|---:|---:|---:|---:|
| `typesafe/jev-1.14` | `clear_request_missed` | 0.9 | 0.609 | 0.875 | 0.718 | 0.370 |
| `typesafe/jev-1.14` | `wrong_intent_or_route` | 0.7 | 0.875 | 0.583 | 0.700 | 0.169 |
| `typesafe/jev-1.14` | `scenario_coverage_gap` | 0.5 | 0.457 | 1.000 | 0.627 | 0.323 |
| `typesafe/jev-1.14` | `scenario_logic_or_context_failure` | 0.8 | 0.519 | 0.933 | 0.667 | 0.368 |
| `typesafe/jev-1.14` | `prompt_ux_problem` | 0.4 | 0.500 | 0.913 | 0.646 | 0.262 |
| `typesafe/jev-1.14` | `operator_friction` | 0.8 | 0.963 | 0.867 | 0.912 | 0.127 |
| `typesafe/jev-1.14` | `language_mismatch` | 0.6 | 0.833 | 0.556 | 0.667 | 0.143 |
| `typesafe/jev-1.14` | `asr_suspected` | 0.6 | 0.429 | 0.900 | 0.581 | 0.219 |
| `typesafe/jev-1.14` | `no_progress_loop` | 0.9 | 0.280 | 0.700 | 0.400 | 0.600 |
| `google/gemini-decision-1` | `clear_request_missed` | 0.6 | 0.769 | 0.625 | 0.690 | 0.162 |
| `google/gemini-decision-1` | `wrong_intent_or_route` | 0.3 | 0.857 | 0.500 | 0.632 | 0.127 |
| `google/gemini-decision-1` | `scenario_coverage_gap` | 0.2 | 0.472 | 0.810 | 0.596 | 0.238 |
| `google/gemini-decision-1` | `scenario_logic_or_context_failure` | 0.4 | 0.706 | 0.800 | 0.750 | 0.149 |
| `google/gemini-decision-1` | `prompt_ux_problem` | 0.2 | 0.571 | 0.696 | 0.627 | 0.259 |
| `google/gemini-decision-1` | `operator_friction` | 0.2 | 0.935 | 0.967 | 0.951 | 0.116 |
| `google/gemini-decision-1` | `language_mismatch` | 0.3 | 1.000 | 0.556 | 0.714 | 0.080 |
| `google/gemini-decision-1` | `asr_suspected` | 0.6 | 1.000 | 0.500 | 0.667 | 0.107 |
| `google/gemini-decision-1` | `no_progress_loop` | 0.8 | 0.545 | 0.600 | 0.571 | 0.257 |
| `cloudflare/clef` | `clear_request_missed` | 0.8 | 0.609 | 0.875 | 0.718 | 0.267 |
| `cloudflare/clef` | `wrong_intent_or_route` | 0.4 | 0.786 | 0.917 | 0.846 | 0.085 |
| `cloudflare/clef` | `scenario_coverage_gap` | 0.3 | 0.615 | 0.762 | 0.681 | 0.207 |
| `cloudflare/clef` | `scenario_logic_or_context_failure` | 0.7 | 0.632 | 0.800 | 0.706 | 0.241 |
| `cloudflare/clef` | `prompt_ux_problem` | 0.3 | 0.528 | 0.826 | 0.644 | 0.244 |
| `cloudflare/clef` | `operator_friction` | 0.4 | 0.933 | 0.933 | 0.933 | 0.074 |
| `cloudflare/clef` | `language_mismatch` | 0.3 | 0.727 | 0.889 | 0.800 | 0.070 |
| `cloudflare/clef` | `asr_suspected` | 0.7 | 0.750 | 0.600 | 0.667 | 0.177 |
| `cloudflare/clef` | `no_progress_loop` | 0.8 | 0.219 | 0.700 | 0.333 | 0.547 |
