# Qualitative call review: SAMPLE 1–25

## Scope and reading rules

All 25 assigned calls in `call_sample_part_1.md` were reviewed. Relevant active YAML and `intent_config_v23.json` were checked before making scenario-routing claims. This is an **enriched evaluation/discovery sample, not a representative prevalence sample**; the counts below describe only these 25 calls and must not be extrapolated to all calls.

- There is no audio. `asr_suspected` is used only where the transcript is garbled or fragmented; it is **not** proof of an ASR error.
- A final `transferred` outcome means a handoff was announced, **not** that the banking problem was resolved.
- Explicit intent evidence was preserved. In particular, bot-event `cash_credit` in S2, bot-event `talk_to_operator` in S15, and `card_requisites_info` in S22 are successful classifications, not NLU misses. Repeated successful `talk_to_operator` classifications were distinguished from actual NLU failures.
- Scenario observations were checked against the active YAML, including `00_00_continuity`, `00_01_identification`, `00_06_reask_before_operator`, `00_07_proceed_untrusted`, and the service scenarios named below.

## Counts derived from `call_annotations_01_25.json`

### Outcomes and severity

| Dimension | Counts |
|---|---|
| Outcome | transferred **15**; unresolved **4**; partially_resolved **3**; resolved **2**; abandoned **1**; unclear **0** |
| Severity | high **9**; medium **10**; low **4**; none **2** |
| Confidence | high **22**; medium **3**; low **0** |

The 15 transferred calls are S2, S3, S5, S6, S7, S8, S15, S16, S18, S19, S20, S22, S23, S24, and S25. They must not be counted as 15 resolved calls. The two clear information-resolution examples are S10 and S11.

### Failure tags

Tags are multi-label, so their counts sum to more than 25.

| Tag | Calls | Tag | Calls |
|---|---:|---|---:|
| operator_friction | 13 | prompt_ux | 9 |
| nlu_miss | 8 | scenario_state_coverage | 7 |
| nlu_wrong_intent | 6 | scenario_missing | 6 |
| scenario_logic | 6 | no_progress | 6 |
| asr_suspected | 6 | state_context | 5 |
| language_mismatch | 3 | none | 2 |

## Cross-call patterns

### 1. Operator recognition often works; the handoff policy creates the friction

`operator_friction` occurs in 13 annotated calls, but this is not equivalent to 13 operator NLU failures. Clear operator phrases are explicitly recognized in S1, S2, S3, S5, S7, S8, S14, S15, S16, S20, S22, S24, and S25. The recurring problem is what happens next: a deflection, a reason request, another deflection, a repeated long answer, or a fallback after unknown turns.

S1 is the clearest bad outcome: two operator requests succeed, but the clear reason `получателю не пришел платеж` becomes `unknown` in `00_06_reask_before_operator__second_ask`; the overloaded-line prompt repeats and no transfer appears. S16 similarly recognizes the first operator request but replays the entire nonreceipt answer before later requests fail and a final short request succeeds. In contrast, S25 shows that language selection, both operator requests, and the `unblock_app` reason can all be classified successfully before handoff.

### 2. Wrong intent and missing coverage are different failure modes

Six calls have `nlu_wrong_intent`: S8, S9, S12, S16, S19, and S22. The highest-impact confusions are:

- **Nonreceipt versus instructions/refund/timing:** S8 turns an ordinary interbank-timing question into `recipient_not_received`; S9 first turns an already-failed Uzbekistan transfer into `uz_transfer` send instructions, then turns confirmation into `card_refund_timing`; S16 reverses an outgoing recipient problem into incoming-card `pin__ne_perevod_dengi`.
- **Nearby navigation concepts:** S19 turns a PIN-settings follow-up into `change_payment_date`; S22 turns an account number for accounting into `hsa_certificates`; S12 chooses card-limit modification instead of first using the existing ATM-limit scenario.

Eight calls have `nlu_miss`, including clear nonreceipt reason capture (S1), Kazakhstan-card response plus operator phrasing (S5), longer Kazakh operator requests (S16), trusted-number next steps (S17), and urgent-specialist phrasing (S24). These should not be merged with new-intent work.

`scenario_missing` and `scenario_state_coverage` expose separate backlog items:

- A global **request_identification** intent and safe resume path (S7, S19); v23 has no such intent.
- Ordinary **interbank_transfer_timing** guidance distinct from confirmed nonreceipt (S8).
- An **audio_quality/cannot_hear** path, or robust mapping to the existing `complaint` intent (S14).
- An identified **transfer-status/exact-reason** path beyond receipt-sharing advice (S16), and a missing-money transaction-review path (S7).
- **other_bank_card_at_halyk_atm** coverage (S23). The existing card-stuck-atm scenario answers a different question, and `00_00_continuity.main` has no `atm_general` route.
- State-level gaps for a generic RK-card limit response (S5), correction to the ATM-limit confirmation (S12), trusted-number instructions (S17), branch-location deposit withdrawal (S21), and compound expired-plus-retained-card routing (S24).

### 3. Default transitions and interrupts lose context or create loops

Six calls carry `scenario_logic`, five `state_context`, and six `no_progress`.

- In S7, `02_04_insufficient_funds.ask_identification_for_details` has `True == True -> '<<'`; one fragmented turn pops the service and loses the 52K/identification context. S19 has the same pattern in `09_01_unblocking_card.ask_identification_for_details`.
- In S17, `00_07_proceed_untrusted.start` handles only a narrow set of responses before its default `<<`. A clear contextual `what should I do?` therefore exits instead of providing the offered trusted-number instructions.
- In S18, `00_01_identification.gov_services_confirmation` maps `unable` to `wait_for_ready_to_say_code`, which returns to the same question. The NLU was correct; the scenario handled that correct intent incorrectly.
- In S9, an unrelated main-intent interrupt moves a pending nonreceipt confirmation into card-refund timing. S19 similarly loses PIN context to an unrelated credit-date scenario.
- Long prompts are replayed after silence or unknown input in S14, S16, S18, S19, and S21. Repeating the same content does not disambiguate the caller's problem.

### 4. Language mismatch persists even when intent recognition succeeds

Three calls are tagged `language_mismatch`: S2, S15, and S16. S2 and S15 recognize Kazakh operator and credit intents but answer in Russian. S16 begins with a Russian answer to a Kazakh nonreceipt question, then successfully switches after `можно на казахском`. These are not reasons to mislabel the successful intents as NLU errors; the fix is language detection/switching and preserving the selected language across scenario and operator prompts.

### 5. Successful patterns worth retaining

- **S4:** explicit Kazakh selection followed by a bounded silence exit; no banking request was made, so no service defect should be invented.
- **S10:** `insurance_info` works and the correct auto-insurance number 797 is supplied. The remaining issue is verbose/generic follow-up handling, not core routing.
- **S11:** clean Kazakh refund-timing response: 1–15 calendar days plus statement location, directly answering the concern.
- **S6:** clear final `ipoteka__refinans` classification and correct handoff despite earlier unusable fragments.
- **S18:** `card_withdrawal_fail`, `agree`, and `unable` are all recognized correctly, demonstrating why NLU and scenario health need separate evaluation.
- **S25:** `change_lang_kz`, both `talk_to_operator` turns, and `unblock_app` are all explicit successes.

## Highest-value fixes

1. **Make fallback context-safe before adding more intents.** Replace unmatched-intent `True -> '<<'` exits in identification/trusted-number states with a local clarification or operator fallback that preserves the original scenario and resume state. Add regression tests using S7, S17, and S19.
2. **Fix `unable` handling in `00_01_identification`.** Do not route `не открывается` to a wait loop. Offer the existing alternative identification path or an operator, and add a direct `talk_to_operator -> switch_to_operator` transition where appropriate. Test with S14 and S18.
3. **Constrain cross-scenario interrupts during sensitive local states.** A pending nonreceipt confirmation or PIN-navigation follow-up should not jump to refunds or loan-payment-date content without explicit supporting words. Use S9 and S19 as regression cases.
4. **Simplify repeated-operator handoff.** Once the caller repeats an explicit operator request and supplies a recognizable reason, transfer promptly and pass the reason, direction, and original utterance to the queue. Remove overloaded-line and full-answer replays from this path. S1 and S16 should be acceptance tests.
5. **Add `request_identification` globally with original-goal resume.** This addresses two independent calls (S7 and S19) and should be wired to `00_01_identification`, not merely added to the model label list.
6. **Build direction-aware NLU tests and hard negatives.** Cover outgoing recipient nonreceipt versus incoming-card nonreceipt, already-sent versus how-to-send, transfer timing versus late transfer, card refund versus transfer nonreceipt, account requisites versus certificates, ATM-limit information versus changing card limits, and PIN settings versus credit-date settings.
7. **Add the genuinely missing service coverage.** Prioritize request-identification, interbank-transfer timing, cannot-hear/audio quality, other-bank-card ATM compatibility, and exact transfer investigation. Business owners must approve the actual banking content, especially deposit-location and ATM-compatibility answers.
8. **Shorten prompts and preserve language.** On silence, ask a short targeted question rather than replaying a long answer. Auto-offer Kazakh when Kazakh speech is detected and retain it through service and operator scenarios.

## Notable observations for every call

| Sample / call | Outcome | Main observation |
|---|---|---|
| S1 / 11917 | unresolved | Operator intents succeed; clear nonreceipt reason fails in `second_ask`, followed by prompt repetition and no handoff. |
| S2 / 14998 | transferred | Kazakh operator requests and final bot-event `cash_credit` succeed; bot remains Russian. |
| S3 / 27621 | transferred | Operator requests succeed. Card reasons are broad and unknown, but too ambiguous to prove an NLU defect. |
| S4 / 64231 | abandoned | Correct Kazakh switch and silence termination; no service goal was stated. |
| S5 / 104094 | transferred | `08_03.start` cannot consume generic `қазақстан картасына`; no limit answer is given. |
| S6 / 107885 | transferred | Early text is garbled; final refinancing classification and handoff are correct. |
| S7 / 113870 | transferred | Explicit identification request has no intent; default pop loses the missing-money context. |
| S8 / 115743 | transferred | A normal transfer-duration question is misclassified as recipient nonreceipt; no timing answer. |
| S9 / 3722 | unresolved | Send instructions and then refund timing answer a missing Uzbekistan transfer incorrectly. |
| S10 / 12913 | resolved | Correct 797 auto-insurance number; follow-up repeats an unnecessarily broad message. |
| S11 / 39149 | resolved | Correct Kazakh card-refund timing and statement instructions. |
| S12 / 49164 | partially_resolved | ATM error is framed as a desire to change limits; correction is uncovered, though identification begins. |
| S13 / 51589 | partially_resolved | Pension intent and final affirmation work; generic untrusted guidance does not confirm actual receipt. Later destination is ambiguous. |
| S14 / 58135 | unresolved | Correct block/operator intents coexist with unhandled audio complaints and an eGov instruction loop. |
| S15 / 67999 | transferred | Russian responses to Kazakh; final bot-event `talk_to_operator` is an explicit success. |
| S16 / 75955 | transferred | Outgoing/incoming direction is reversed once, generic advice is replayed, and later operator variants fail before final success. |
| S17 / 84422 | unresolved | Correct app-unblock intent is dropped when the trusted-number follow-up hits an uncovered default exit. |
| S18 / 100707 | transferred | Correct `unable` classification is incorrectly treated as waiting, causing the identification loop. |
| S19 / 105670 | transferred | Correct unblock/PIN paths derail into credit-date content; explicit identification-how questions are uncovered. |
| S20 / 116605 | transferred | Conditional arrest guidance is given; short `байланысу керек` is a contextual miss before full operator phrasing succeeds. |
| S21 / 124808 | partially_resolved | Universal-deposit terms do not directly answer whether withdrawal is possible in another city; product is assumed. |
| S22 / 135344 | transferred | Certificates are the wrong initial topic; final `card_requisites_info` is a correct classification. |
| S23 / 4765 | transferred | Clear Forte-card/Halyk-ATM question has no main-intent/scenario coverage. |
| S24 / 22560 | transferred | `reissue_card` captures expiry but drops ATM retention; YAML maps those reasons to different operator queues. |
| S25 / 38674 | transferred | All key language/operator/app-unblock classifications succeed; residual issue is avoidable first-turn operator deflection. |
