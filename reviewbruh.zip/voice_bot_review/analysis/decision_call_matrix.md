# Fifty-call model matrix

Outcomes and 0–3 UX severity scores. `Ann.` is the AI-assisted annotation, not human gold.

| Sample | Call | Ann. outcome | Jev outcome / UX | Gemini outcome / UX | Clef outcome / UX |
|---:|---:|---|---|---|---|
| 1 | 11917 | unresolved | abandoned / 2.23 | abandoned / 2.04 | abandoned / 2.13 |
| 2 | 14998 | transferred | transferred / 0.76 | transferred / 0.62 | transferred / 1.11 |
| 3 | 27621 | transferred | transferred / 1.59 | transferred / 1.26 | transferred / 1.61 |
| 4 | 64231 | abandoned | abandoned / 2.34 | abandoned / 1.81 | abandoned / 2.06 |
| 5 | 104094 | transferred | transferred / 2.32 | transferred / 1.74 | transferred / 2.00 |
| 6 | 107885 | transferred | transferred / 1.91 | transferred / 1.46 | transferred / 1.73 |
| 7 | 113870 | transferred | transferred / 1.90 | transferred / 1.56 | transferred / 2.10 |
| 8 | 115743 | transferred | transferred / 1.62 | transferred / 0.57 | transferred / 1.24 |
| 9 | 3722 | unresolved | unresolved_no_transfer / 1.86 | resolved / 1.52 | partially_resolved / 1.56 |
| 10 | 12913 | resolved | unresolved_no_transfer / 1.47 | partially_resolved / 1.47 | unresolved_no_transfer / 1.52 |
| 11 | 39149 | resolved | resolved / 0.20 | unclear / 0.18 | resolved / 0.37 |
| 12 | 49164 | partially_resolved | unresolved_no_transfer / 1.50 | unclear / 1.00 | unresolved_no_transfer / 1.82 |
| 13 | 51589 | partially_resolved | abandoned / 2.38 | unresolved_no_transfer / 1.99 | abandoned / 2.23 |
| 14 | 58135 | unresolved | unresolved_no_transfer / 2.68 | unresolved_no_transfer / 2.26 | unresolved_no_transfer / 2.55 |
| 15 | 67999 | transferred | transferred / 1.21 | transferred / 0.52 | transferred / 1.37 |
| 16 | 75955 | transferred | transferred / 2.01 | transferred / 1.36 | transferred / 2.33 |
| 17 | 84422 | unresolved | unresolved_no_transfer / 2.77 | unresolved_no_transfer / 2.22 | unresolved_no_transfer / 2.21 |
| 18 | 100707 | transferred | transferred / 2.58 | transferred / 1.64 | transferred / 2.34 |
| 19 | 105670 | transferred | transferred / 2.55 | transferred / 1.92 | transferred / 2.36 |
| 20 | 116605 | transferred | transferred / 1.51 | transferred / 0.55 | transferred / 1.70 |
| 21 | 124808 | partially_resolved | abandoned / 1.36 | abandoned / 1.54 | partially_resolved / 1.11 |
| 22 | 135344 | transferred | transferred / 2.01 | transferred / 1.94 | transferred / 2.16 |
| 23 | 4765 | transferred | transferred / 2.04 | transferred / 1.78 | transferred / 1.92 |
| 24 | 22560 | transferred | transferred / 1.92 | transferred / 1.24 | transferred / 1.77 |
| 25 | 38674 | transferred | transferred / 1.68 | transferred / 1.19 | transferred / 1.53 |
| 26 | 85493 | transferred | transferred / 1.26 | transferred / 0.68 | transferred / 1.14 |
| 27 | 86479 | transferred | transferred / 1.72 | transferred / 1.41 | transferred / 1.84 |
| 28 | 109337 | transferred | transferred / 1.41 | transferred / 1.26 | transferred / 1.48 |
| 29 | 123137 | transferred | transferred / 2.32 | transferred / 1.59 | transferred / 2.07 |
| 30 | 150165 | transferred | transferred / 1.91 | transferred / 1.32 | transferred / 1.75 |
| 31 | 12998 | transferred | transferred / 1.75 | transferred / 0.96 | transferred / 2.01 |
| 32 | 22537 | transferred | transferred / 2.06 | transferred / 1.63 | transferred / 2.12 |
| 33 | 60921 | transferred | transferred / 2.02 | transferred / 1.92 | transferred / 2.27 |
| 34 | 62893 | transferred | transferred / 2.06 | transferred / 1.62 | transferred / 2.12 |
| 35 | 124149 | transferred | transferred / 2.32 | transferred / 2.03 | transferred / 2.40 |
| 36 | 145410 | transferred | transferred / 2.02 | transferred / 1.44 | transferred / 2.16 |
| 37 | 37058 | unresolved | unresolved_no_transfer / 2.61 | unresolved_no_transfer / 1.95 | unresolved_no_transfer / 2.39 |
| 38 | 51365 | partially_resolved | unresolved_no_transfer / 1.48 | resolved / 0.82 | resolved / 1.20 |
| 39 | 69031 | transferred | transferred / 1.77 | transferred / 1.54 | transferred / 1.88 |
| 40 | 99503 | transferred | transferred / 2.32 | transferred / 1.79 | transferred / 2.25 |
| 41 | 126365 | transferred | transferred / 1.50 | transferred / 0.86 | transferred / 1.48 |
| 42 | 3452 | unresolved | unresolved_no_transfer / 1.60 | unclear / 1.07 | unresolved_no_transfer / 1.74 |
| 43 | 79604 | transferred | transferred / 2.04 | transferred / 1.69 | transferred / 2.37 |
| 44 | 91923 | transferred | transferred / 1.87 | transferred / 1.16 | transferred / 1.74 |
| 45 | 130989 | transferred | transferred / 2.20 | transferred / 1.96 | transferred / 2.26 |
| 46 | 146583 | transferred | transferred / 2.15 | transferred / 1.74 | transferred / 2.06 |
| 47 | 32717 | transferred | transferred / 1.85 | transferred / 1.56 | transferred / 1.95 |
| 48 | 77285 | unresolved | unresolved_no_transfer / 2.05 | unresolved_no_transfer / 2.11 | resolved / 1.18 |
| 49 | 93548 | transferred | transferred / 2.37 | transferred / 2.07 | transferred / 2.33 |
| 50 | 109684 | abandoned | abandoned / 2.68 | unresolved_no_transfer / 2.35 | abandoned / 2.34 |
