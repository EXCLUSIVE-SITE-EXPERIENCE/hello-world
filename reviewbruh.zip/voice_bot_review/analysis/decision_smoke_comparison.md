# Decisions model comparison

**Agreement with AI-assisted annotations, not human-gold accuracy. Do not select a production model from this table alone.**

Noul threshold: 0.5. Successful rows: 9; errors: 0.

| Model | Calls | Errors | Cost USD | Outcome agreement | UX severity MAE | Mean seconds | p95 seconds |
|---|---:|---:|---:|---:|---:|---:|---:|
| `cloudflare/clef` | 3 | 0 | 0.001295 | 0.667 | 0.788 | 1.858 | 2.120 |
| `google/gemini-decision-1` | 3 | 0 | 0.000553 | 0.667 | 0.866 | 1.279 | 1.971 |
| `typesafe/jev-1.14` | 3 | 0 | 0.000260 | 0.667 | 0.867 | 1.021 | 1.230 |

## Pairwise outcome agreement

| Models | Agreement | Compared |
|---|---:|---:|
| `cloudflare/clef <> google/gemini-decision-1` | 1.000 | 3 |
| `cloudflare/clef <> typesafe/jev-1.14` | 1.000 | 3 |
| `google/gemini-decision-1 <> typesafe/jev-1.14` | 1.000 | 3 |

## cloudflare/clef: independent failure tags

| Question | TP | FP | FN | Precision | Recall | F1 |
|---|---:|---:|---:|---:|---:|---:|
| `clear_request_missed` | 1 | 2 | 0 | 0.333 | 1.000 | 0.500 |
| `wrong_intent_or_route` | 0 | 0 | 0 | — | — | — |
| `scenario_coverage_gap` | 0 | 0 | 0 | — | — | — |
| `scenario_logic_or_context_failure` | 0 | 2 | 0 | 0.000 | — | — |
| `prompt_ux_problem` | 0 | 2 | 0 | 0.000 | — | — |
| `operator_friction` | 3 | 0 | 0 | 1.000 | 1.000 | 1.000 |
| `language_mismatch` | 1 | 0 | 0 | 1.000 | 1.000 | 1.000 |
| `asr_suspected` | 1 | 1 | 0 | 0.500 | 1.000 | 0.667 |
| `no_progress_loop` | 1 | 2 | 0 | 0.333 | 1.000 | 0.500 |

## google/gemini-decision-1: independent failure tags

| Question | TP | FP | FN | Precision | Recall | F1 |
|---|---:|---:|---:|---:|---:|---:|
| `clear_request_missed` | 1 | 0 | 0 | 1.000 | 1.000 | 1.000 |
| `wrong_intent_or_route` | 0 | 0 | 0 | — | — | — |
| `scenario_coverage_gap` | 0 | 0 | 0 | — | — | — |
| `scenario_logic_or_context_failure` | 0 | 1 | 0 | 0.000 | — | — |
| `prompt_ux_problem` | 0 | 1 | 0 | 0.000 | — | — |
| `operator_friction` | 3 | 0 | 0 | 1.000 | 1.000 | 1.000 |
| `language_mismatch` | 0 | 0 | 1 | — | 0.000 | — |
| `asr_suspected` | 0 | 1 | 1 | 0.000 | 0.000 | — |
| `no_progress_loop` | 1 | 0 | 0 | 1.000 | 1.000 | 1.000 |

## typesafe/jev-1.14: independent failure tags

| Question | TP | FP | FN | Precision | Recall | F1 |
|---|---:|---:|---:|---:|---:|---:|
| `clear_request_missed` | 1 | 2 | 0 | 0.333 | 1.000 | 0.500 |
| `wrong_intent_or_route` | 0 | 1 | 0 | 0.000 | — | — |
| `scenario_coverage_gap` | 0 | 3 | 0 | 0.000 | — | — |
| `scenario_logic_or_context_failure` | 0 | 2 | 0 | 0.000 | — | — |
| `prompt_ux_problem` | 0 | 2 | 0 | 0.000 | — | — |
| `operator_friction` | 3 | 0 | 0 | 1.000 | 1.000 | 1.000 |
| `language_mismatch` | 1 | 0 | 0 | 1.000 | 1.000 | 1.000 |
| `asr_suspected` | 1 | 1 | 0 | 0.500 | 1.000 | 0.667 |
| `no_progress_loop` | 1 | 2 | 0 | 0.333 | 1.000 | 0.500 |
