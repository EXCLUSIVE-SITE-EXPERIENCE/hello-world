# Verigram YAML and dialog-engine review

## Scope and confidence

Reviewed all **170 active scenarios**, `intent_config_v23.json`, the workbook, relevant calls, and the supplied dialog-engine core. No production files were changed.

Two evidence levels are kept separate:

- **YAML/config fact:** deterministic for the active snapshot captured on 2026-11-06.
- **Supplied-source risk:** proven in the supplied older engine source, but requiring parity confirmation against production **v2.2.123**. The guide discusses an older observed deployment, so source-level findings are release checks, not automatic production defects.

## Structural validation: what is healthy

Independent validation reproduced:

- 170 scenarios and 1,113 states;
- 3,094 flattened transition rules;
- 275 cross-scenario transitions;
- 2,180 positive intent mentions and 1,106 scenario/intent pairs;
- 225 distinct YAML intent labels and 226 model labels;
- 136 `continuity.main` cross-scenario routes.

All 275 target scenario IDs exist, all targets have `start`, and every resume state exists in the **source** scenario. The audit found no invalid local target, missing target start/source resume state, YAML parse/duplicate-key error, invalid condition syntax, or transition placed after an unconditional rule.

Nested transition lists in `00_06_reask_before_operator` are supported by the supplied loader and are not malformed.

### Correct `>>target|resume_state` semantics

The supplied engine:

1. updates the current/source stack frame to `resume_state`;
2. pushes the target scenario at its own `start`.

Therefore `>>03_07_credit_closing_certificate|what_can_i_help_you_with` enters `03_07...__start` and saves `what_can_i_help_you_with` on `00_00_continuity`. It does **not** look for that state in `03_07`. The initial concern that 41 such routes were broken was correctly rejected after reading the engine.

## P0 release check — OR alternatives omitted by `MainIntentManager`

**Supplied-source risk with exact YAML exposure.** `main_intent_manager.py` performs one regex `search` per transition and registers only the first intent. The 136 main cross-scenario transitions contain 157 distinct alternatives; the supplied manager would omit **21 alternatives across 8 OR transitions**.

| Main route | Second/later labels omitted by the supplied manager; November client-turn count |
|---|---|
| `03_06_new_credit` | `cash_credit` (8,860) |
| `07_01_applying_for_ipoteka` | `halyk_sale` (4), `bazis_a` (0), `bi_group` (89), `halyk_ipoteka` (127) |
| `07_05_where_to_consult_car_loan` | `digital_avtokredit` (31), `avtokredit` (497) |
| `08_02_international_transfer` | `send_western_union_transfer` (90), `uz_transfer` (31), `receive_swift_transfer` (636), `receive_western_union_transfer` (78), `international_transfer` (592) |
| `08_03_what_limit` | `limit__ne_prohodit_perevod` (292) |
| `08_05_how_transfer` | `transfer_by_phone_number` (601), `halyk_client` (473), `other_bank_general` (529), `account_transfer` (984) |
| `09_06_deposit_open` | `deposit__zakrit` (185) |
| `20_04_card_contactless_binding_issue` | `apple_pay` (147), `google_pay` (20), `samsung_pay` (4) |

At `continuity.main`, the explicit YAML OR conditions still work. Away from main, the supplied engine gives the NLU and interruption manager only the registered main-intent list, so an omitted alternative cannot independently win a main interruption unless another local route handles it.

**Action:** inspect the actual v2.2.123 source. If parity holds, iterate all matches and register every alternative with the same target/resume. Add assertions for all 157 labels, especially `cash_credit`, `account_transfer`, `international_transfer`, and `other_bank_general`, then rerun NLU tests because the main candidate set changes.

## P0 — Pre-service surveys and non-rating acceptance

**YAML fact with direct call evidence.**

- `00_00_continuity.main` maps `disagree`/`dont_know` directly to `score_the_conversation` without a completed-service guard.
- Its score state has only `True == True -> thanks_for_score`, then goodbye. No 1–5 value is required.
- The same catch-all pattern occurs in **41 scenarios** declaring `score_the_conversation`.
- S47/S48/S50 demonstrate an operator request, missed-call return, and app-launch complaint leading to premature surveys and/or invalid completion.

November has 6,570 continuity score-state client turns, including 3,599 `disagree`, 706 `dont_know`, 1,895 silence, and 370 operator requests. This is volume, not a count of unjustified surveys.

**Action:** add a service-completed/survey-eligible condition, preserve unresolved goals, require a parsed rating before thanks, and offer skip/clarification/operator paths. Include the cloned survey states in replay tests.

## P1 — Main-interrupt continuation can be discarded

**Supplied-source behavior.** `_handle_main_intent_interruption` pops every non-root frame before entering the new scenario. For `root -> service A -> identification B -> target C`, both A and B are lost; C can eventually return only to the root resume flow. It does not erase all `context.data` or transcript history, but it does discard the scenario-stack continuation.

S9, S16, and S46 are compatible with context replacement but do not prove v2.2.123 stack behavior; no stack dump was supplied.

**Action:** replay root-service, root-service-identification, and deeper nested interruptions in production. Preserve/restore suspended frames and their valid return states, or document an intentional reset. Do not merely delete the unwind loop: continuity-only resume names need not exist in an arbitrary interrupted source scenario.

## P1 — Self-repeat and thin-scenario coverage

The audit found **37 entry-intent/self-transition pairs in 35 scenario files**. These are review candidates, not 37 proven failures. A deliberate concise repeat can be valid; the harmful case is a different follow-up being classified as the entry intent and receiving the original generic answer again.

Start with high-volume/high-unknown examples:

| State | Start turns | Unknown share | Review focus |
|---|---:|---:|---|
| `26_05_insurance_info__start` | 7,151 | 21.1% | Auto versus life; narrower follow-ups |
| `25_05_card_refund_timing__start` | 2,255 | 34.4% | Refund versus transfer status/timing |
| `25_04_transfer_history__start` | 1,955 | 29.6% | QR/payment-type/history follow-ups |
| `25_08_atm_cash_limit__start` | 1,901 | 27.1% | ATM-limit information versus changing limits |
| `26_06_new_credit_status__start` | 1,839 | 29.6% | Application-status branches |
| `25_07_deposit_withdrawal__start` | 1,753 | 26.2% | Product/location-specific withdrawal |
| `25_03_forgot_app_password__start` | 1,276 | 34.3% | Password versus launch/access failures |

There are **53 scenarios with 1–3 states**, 85 with at most 4, and 95 with at most 5. Thinness is descriptive, not automatically defective; utility scenarios should not be expanded merely to increase state count.

Two high-value thin cases are:

- `03_06_new_credit`: 4,779 start turns, only repeat plus catch-all exit, and the `cash_credit` registry omission above.
- `24_04_hsa_certificates`: no same-intent recovery; S43 shows irrelevant certificate entry followed by fallback and loss of the missing-money goal.

Split initial answer, concise intentional repeat, expected follow-ups, done/thanks, and operator escape only where replay evidence justifies it.

## P1 — Exact `other_bank` label is absent, but the branch is not wholly impossible

`22_01_push_checking.ask_how_to_help` has:

```text
intent == "otherway" or intent == "other_bank"
  -> explain_alternative_payment_methods
```

The model has `otherway` and `other_bank_general`, but no exact `other_bank`. That disjunct is unproducible in the supplied model/state-candidate logic; the transition remains reachable through `otherway`.

**Action:** test `other_bank_general` as the replacement/alias, or deliberately train a distinct class. Do not remove the entire alternative-payment transition.

## P2 — Label and repeat-handling cleanup

- `are_you_robot`, `what_is_your_name`, and `prosroch_zadol_minimalni` have no positive YAML intent reference. The supplied NLU uses state/main candidate subsets, so these unreferenced labels do not directly compete there. Wire useful small-talk routes if desired, but do not delete config indices independently of the trained model.
- Both `prosroch_zadol_minimalni` and `prosroch_zadol__minimalni` exist; only the double-underscore form is wired. Resolve this as a model-plus-routing decision with regression tests.
- Twenty-two scenarios lack an **explicit YAML** repeat condition. The supplied loader can inject repeat handling, so this is not proof that repeat is unsupported at runtime. Check v2.2.123 behavior before editing all of them.

## Recommended release gates

1. **P0:** survey eligibility/rating validation across continuity and all clones.
2. **P0:** production parity check and tests for every main OR alternative.
3. **P1:** nested interruption/resumption replay with stack assertions.
4. **P1:** identification/default-exit and `other_bank` corrections.
5. **P1:** self-repeat remediation ordered by real follow-up failures and state volume, not state count alone.
6. **P2:** duplicate/small-talk label review and explicit-repeat parity tests.

Machine-readable results are in `analysis/yaml_audit_summary.json`, `analysis/yaml_audit_issues.json`, and `analysis/yaml_scenario_stats.{json,csv}`. The independent verification and detailed code references are in `analysis/yaml_audit_review.md`.
