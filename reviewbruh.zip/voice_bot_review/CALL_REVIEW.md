# Verigram call review: November 2026

## Method and limits

- Read the architecture guide, active intent configuration/workbook, and relevant YAML states.
- Mechanically parsed **150,837 November call records** and **635,683 client turns**, covering November 1 through November 12 at 17:28 (partial month).
- Reviewed **50 calls** in detail: 8 random-baseline calls with content plus 42 calls deliberately selected across service journeys, unknowns, repetition, language mismatch, multi-topic calls, and unresolved calls. Two separately reviewed 25-call annotation sets were combined and source-validated.
- These are **AI-assisted qualitative annotations, not human-adjudicated gold labels**. They are suitable for prioritization and test-case design, not final model-accuracy claims. High-confidence annotations still require human validation before retraining.
- The 50-call set is an **enriched discovery sample, not a prevalence sample**. Its tag counts must not be extrapolated to production.
- No audio, NLU confidence/top-k, ASR confidence/n-best, callback results, or post-transfer resolution was available. `asr_suspected` means garbled text, not a proven ASR defect. A transfer announcement is not task resolution.
- Active YAML was captured on November 6. It is not guaranteed to be the exact in-memory version for every call in the month.

Derived transcripts redact long digit sequences. No call content was sent to an external model.

## Full-month mechanical signals

These are transcript metrics, not adjudicated failure rates.

| Signal | Count | Rate |
|---|---:|---:|
| Call records | 150,837 | 100% |
| Client turns | 635,683 | — |
| `intent=unknown` client turns | 188,909 | 29.72% of turns |
| `talk_to_operator` client turns | 184,382 | 29.01% of turns |
| `silence` client turns | 56,241 | 8.85% of turns |
| Unknown + operator + silence | 429,532 | 67.57% of turns |
| Calls with a non-silence unknown turn | 80,826 | 53.59% of calls |
| Calls with at least two non-silence unknown turns | 44,804 | 29.70% of calls |
| Calls with an operator request | 90,380 | 59.92% of calls |
| Calls entering operator re-ask | 57,491 | 38.11% of calls |
| Calls with repeated bot text | 57,374 | 38.04% of calls |
| Calls with consecutive identical bot text | 49,299 | 32.68% of calls |
| Calls reaching a service scenario | 54,947 | 36.43% of calls |
| Calls reaching multiple service scenarios | 10,589 | 7.02% of calls |
| Calls with language-mismatch heuristic | 6,583 | 4.36%; heuristic only |
| Calls without substantive client content | 21,097 | 13.99% of calls |
| Client turns with `dialog_step=unknown` | 113,438 | 17.85% of turns |

Daily unknown-turn share stayed in a narrow **28.10–30.53%** band. That stability suggests a systemic issue rather than a single-day model incident.

Of 226 deployed labels, 195 appeared in November client events and 31 did not. Zero November observations do not prove a label is useless, especially for rare/high-risk services, but those labels deserve a route/training review.

### Highest-value state hotspots

Unknown here can mean ASR noise, out-of-scope input, or no matching model/state intent. It needs adjudication.

| State | Client turns | Unknown | Unknown share |
|---|---:|---:|---:|
| `00_06_reask_before_operator__second_ask` | 37,803 | 21,937 | 58.0% |
| `04_02_self_open_card_new__open_card_general` | 1,435 | 1,069 | 74.5% |
| `26_22_national_fund_children__more_questions` | 611 | 413 | 67.6% |
| `00_02_multiple_card_choose__start` | 991 | 592 | 59.7% |
| `04_04_self_actual_reissue_card__awaiting_user_action` | 2,904 | 1,564 | 53.9% |
| `00_01_identification__retry_egov_code` | 780 | 352 | 45.1% |
| `00_00_continuity__main` | 238,726 | 89,869 | 37.6% |

The second operator-reason state is especially important: it has both high volume and a 58% unknown share. It should be one of the first per-state NLU and UX evaluation sets.

## Fifty-call qualitative results

### Outcomes and severity

| Outcome | Calls |
|---|---:|
| Transferred; post-transfer result unknown | 35 |
| Unresolved without a completed answer | 7 |
| Partially resolved | 4 |
| Clearly resolved by the bot | 2 |
| Abandoned | 2 |

Fifteen calls were high severity, 22 medium, 10 low, and 3 had no material defect. Forty-three annotations were high confidence, 6 medium, and 1 low.

### Failure tags (multi-label)

| Tag | Calls | Interpretation |
|---|---:|---|
| Operator friction | 30 | Deflection, repeated reason requests, overload messages, or delayed transfer |
| Prompt UX | 23 | Long, generic, repeated, irrelevant, or premature prompts |
| NLU miss | 16 | Intelligible request remained unknown |
| Wrong intent | 12 | Recognized intent conflicted with the caller's meaning |
| Scenario state coverage | 11 | Existing flow lacked the needed branch/answer |
| Missing intent/scenario | 11 | A genuinely new or broader coverage gap |
| Scenario logic | 11 | Wrong branch, loop, premature exit, or invalid survey |
| State/context failure | 10 | Original goal or direction was lost |
| ASR suspected | 10 | Garbled text; audio required for confirmation |
| No-progress loop | 10 | Caller or bot repeated without useful progress |
| Language mismatch | 9 | Sustained wrong-language behavior |
| No material defect | 3 | Positive/acceptable calls |

Twenty-five calls had an NLU miss or wrong intent, 24 had a scenario/state issue, and **17 had both**. This overlap is why a new NLU model alone will not fix the user experience.

## Priority findings

### P0 — Survey and terminal-state logic can end calls before service

`00_00_continuity.main` sends `disagree` or `dont_know` directly to `score_the_conversation`, regardless of whether service was delivered. Score states then accept any turn reaching transition selection through `True == True` rather than requiring a rating. The same catch-all pattern appears in **41 scenarios** with a `score_the_conversation` state. November contains 6,570 continuity score-state client turns, including 370 operator requests; volume alone does not show how many surveys were unjustified.

- **S47 / call 32717:** an explicit operator request became `disagree`; survey text later contaminated the operator flow.
- **S48 / call 77285:** a caller returning a missed bank call was surveyed and sent to goodbye without help.
- **S50 / call 109684:** an app-launch complaint became `dont_know`; three survey prompts and silence ended the call.

**Fix:** permit surveys only after a completed service interaction and an explicit end-of-help response. Preserve the original goal. Validate a rating before thanks/goodbye; otherwise clarify or exit without claiming a score. Isolate survey and operator contexts. Make S47/S48/S50 acceptance tests.

### P0 — Fallback and interrupt behavior loses the original goal

- **S7 and S19:** `ask_identification_for_details` has an unmatched-intent `True == True -> '<<'`; a fragment pops the service and loses the missing-money/PIN context. Clear requests to pass identification have no global intent.
- **S17:** the untrusted start offers trusted-number instructions, but a clear “what should I do?” hits the default return instead of the offered instructions.
- **S9 and S19:** unrelated main-intent interrupts turn pending nonreceipt/PIN contexts into refund/credit-date content.
- **S14 and S18:** `unable` is treated like waiting in identification; correct NLU therefore produces an instruction loop.

**Fix:** replace default pops with local clarification or an operator path that retains the original resume state. Add a global `request_identification` route with original-goal resume. Separate `wait` from `unable`. Restrict unrelated main-intent interrupts during sensitive confirmations. Review the supplied engine's root-unwind behavior for main-intent interruptions against the production version.

### P1 — Operator recognition often works; the handoff policy causes friction

Many explicit RU/KZ operator requests are correctly classified. The recurring bad sequence is:

```text
operator recognized -> deflection -> reason request
-> overload/second reason request -> repeated prompt or long generic answer
```

- **S1 / call 11917:** operator recognition succeeded, but the clear nonreceipt reason became unknown and no transfer was reached.
- **S39 and S45:** repeated explicit requests were recognized, yet the bot kept demanding a reason and replaying prompts.
- **S33:** four intelligible Kazakh received-amount variants remained unknown across main and both re-ask states.
- **S25:** language, operator, and app-unblock classifications all worked; only avoidable deflection remained.

**Fix:** after a repeated explicit operator request, allow general-queue transfer. Use a voluntarily supplied topic for specialist routing; do not require one. Once a valid reason is recognized, transfer promptly. On silence, wait or give one short targeted prompt rather than repeating the overload warning. Preserve correct `00_06` specialist mappings.

### P1 — Transfer direction and transaction status need first-class modeling

- **S8:** ordinary interbank timing became confirmed `recipient_not_received`.
- **S9:** an already-sent Uzbekistan transfer first received send instructions, then card-refund timing.
- **S16 and S42:** outgoing/recipient problems were reversed into incoming-card `pin__ne_perevod_dengi` or sender-side receipt advice.
- **S37:** no bank selected/no receipt repeatedly produced the same generic receipt answer without resolving the question.

**Fix:** distinguish how-to-send, normal transfer timing, confirmed outgoing nonreceipt, incoming card nonreceipt, refund timing, and missing-bank/no-receipt. Preserve sender/recipient direction in context. Add an identified transfer-status/exact-reason path and a dedicated no-bank-selected/no-receipt branch. Use direction-specific hard negatives.

### P1 — Generic self-repeat states cannot handle narrower follow-ups

The YAML audit found **35 scenario files** with an entry-intent self-repeat. Examples in the calls include insurance, transfer nonreceipt, deposit withdrawal, and payment-date guidance.

- **S10:** auto-insurance routing works, but a narrower follow-up replays both life and auto insurance instructions.
- **S21:** another-city deposit withdrawal receives generic Universal-deposit terms and fees without answering the location question.
- **S37 and S46:** the original generic answer repeats instead of handling no-receipt or current-step guidance.

**Fix:** split initial answer, repeat, expected follow-ups, done/thanks, and operator escape. Repeat only the current step, not the whole answer. Add entity/sub-intent branches for auto versus life insurance, branch location, transfer role/status, and current app-navigation step.

### P1 — Language selection does not consistently govern subsequent prompts

Nine reviewed calls had behavioral language mismatch. S35 is explicit: the caller says they do not understand Russian and still receives Russian. Other calls recognize Kazakh operator/service intents but keep Russian fallback, deflection, and transfer prompts.

**Fix:** detect sustained Kazakh input, offer or execute `change_lang_kz`, and apply the selected language immediately across all scenario, fallback, survey, identification, and operator states. Treat “орысша түсінбеймін” as language-switch plus support evidence. Keep code-mixed utterances distinct from an explicit language preference.

### P1/P2 — Concrete coverage backlog

| Proposed coverage | Evidence | Recommended action |
|---|---|---|
| `request_identification` | S7, S19 | Global intent into `00_01_identification`, preserving original goal/resume state |
| Interbank transfer timing/status | S8, S9, S16, S37, S42 | Split timing, direction, nonreceipt, and identified investigation |
| Greeting/small talk | S29, S40 | Short localized response that does not consume service retries; full scenario optional |
| `cannot_hear` / audio-quality help | S14 | Acknowledge and offer repeat/operator; can reuse `complaint` only if semantically validated |
| `other_bank_card_at_halyk_atm` | S23 | New approved compatibility/withdrawal/deposit/fee scenario; not card-stuck-atm |
| Flash-token / EDS code support | S34 | New intent and troubleshooting/operator path; hard-negative against withdrawal and PIN |
| `missed_bank_call` | S48 | Explain callback options or route to operator; never direct to survey |
| `app_launch_failure` | S50 | Separate app launch from account unblock and forgotten password |
| Compound expired + ATM-retained card | S24 | Multi-label reasoning or route to retained-card queue while preserving expiry context |
| Safe card-requisite sharing | S29 | Extend existing card-requisites scenario with approved security guidance |
| Branch-location deposit withdrawal | S21 | Add product/location-aware state rather than assuming Universal terms |

Additional intent candidates should be discovered from clustered unknown turns, not only this small sample.

## NLU regression set: highest-value confusion pairs

Create reviewed RU/KZ/code-mixed positives and hard negatives for:

1. Outgoing nonreceipt ↔ incoming card nonreceipt.
2. Normal transfer timing ↔ confirmed late/nonreceived transfer.
3. Already-sent/status ↔ how-to-send instructions.
4. Transfer nonreceipt ↔ card-refund timing.
5. Account/card requisites ↔ HSA certificates.
6. PIN settings ↔ credit-payment-date settings ↔ personal-data update.
7. Flash-token/EDS code ↔ cardless withdrawal/PIN.
8. App launch failure ↔ app unblock ↔ forgotten password.
9. Expired card ↔ ATM-retained card; support compound reasons.
10. Operator/service requests ↔ `disagree`/`dont_know`, especially mixed language.

Do not train on S49 or other ambiguous/garbled examples until audio or a reliable transcript confirms the label. Preserve positive regressions from S4, S10, S11, S25, and S44.

## Prompt and observation improvements

- Replace full-answer replay on silence/unknown with a short targeted clarification.
- Add thanks/done and current-step intents where needed; avoid treating every follow-up as the original main intent.
- Fix prompt artifacts noted in the annotations (for example the stray `§` in transfer guidance and ungrammatical arrest guidance).
- The guide says only `phrases[0]` is currently spoken, so multiple utterance variants in YAML do not provide real variation.
- Log per-turn NLU top-k/probabilities, state candidate intents, selected transition/fallback reason, callback results, ASR confidence/n-best, scenario version, and post-call disposition. The current 17.85% unknown `dialog_step` share in the extract also needs cleanup.

## Recommended implementation order

1. **P0:** survey gating/rating validation; default-exit/context preservation; `unable` versus `wait`.
2. **P0/P1:** repeated-operator transfer and silence behavior, starting with `00_06.second_ask`.
3. **P1:** transfer direction/status and no-receipt branches; identification resume.
4. **P1:** self-repeat expansion in the highest-volume states, using the hotspot table.
5. **P1:** sustained-language handling across every prompt path.
6. **P1:** hard-negative NLU retraining with deployment/argmax and old-intent regression tests.
7. **P2:** new long-tail scenarios after frequency/business-value ranking and content approval.
8. **Throughout:** audio review for the 10 ASR-suspected calls and shadow/replay evaluation before rollout.

The complete per-call evidence and recommendations are in `analysis/call_annotations_50.json`; the two narrative reviews are `analysis/call_review_01_25.md` and `analysis/call_review_26_50.md`.
