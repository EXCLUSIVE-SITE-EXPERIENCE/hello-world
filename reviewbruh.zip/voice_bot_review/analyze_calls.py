#!/usr/bin/env python3
"""Local-only analysis and deterministic sampling of Verigram call transcripts.

No call content is sent over the network. Derived transcripts redact long digit
sequences. The source files are opened read-only.
"""

from __future__ import annotations

import argparse
import collections
import datetime as dt
import json
import random
import re
from pathlib import Path
from typing import Iterator

HEADER_RE = re.compile(r"^=== CALL (\d+) \| ([^|]+) \| ([0-9a-fA-F-]+) ===$")
META_RE = re.compile(
    r"^\[(\d{2}:\d{2}:\d{2})]\s+dialog_step=(.*?)\s+\|\s+intent=(.*?)\s*$"
)
DIGITS_RE = re.compile(r"(?<!\d)(\d{4,})(?!\d)")
WORD_RE = re.compile(r"[\w-]+", re.UNICODE)
KZ_SPECIFIC_RE = re.compile(r"[ӘәҒғҚқҢңӨөҰұҮүҺһІі]")
RU_SPECIFIC_RE = re.compile(r"[ЁёЪъЬьЭэЫы]")
RU_WORDS = {
    "что", "как", "где", "когда", "почему", "здравствуйте", "нужно",
    "мне", "могу", "хочу", "пожалуйста", "не", "на", "и", "в", "с",
    "по", "это", "деньги", "русском", "соедините", "специалист", "можно",
}
KZ_WORDS = {
    "мен", "сіз", "қалай", "неге", "қашан", "керек", "сәлеметсізб",
    "бар", "жоқ", "болады", "маман", "қосыңыз", "айтыңызшы", "ақша",
    "қосып", "жіберіңізші", "маған", "сізге", "қай", "тіл",
}
NON_SERVICE_SCENARIOS = {
    "00_00_continuity", "00_01_identification", "00_02_multiple_card_choose",
    "00_02a_multiple_card_choose", "00_03_operator", "00_04_language_switch",
    "00_05_iin_extraction", "00_06_reask_before_operator",
    "00_07_proceed_untrusted", "unknown", "",
}
NON_SUBSTANTIVE_INTENTS = {
    "", "unknown", "silence", "talk_to_operator", "change_lang_ru",
    "change_lang_kz", "agree", "disagree", "dont_know", "repeat", "digits",
}


def redact(text: str) -> str:
    return DIGITS_RE.sub(lambda m: f"<DIGITS:{len(m.group(1))}>", text)


def redact_transcript(text: str) -> str:
    """Redact spoken digits without damaging call IDs, dates, or metadata."""
    output = []
    for line in text.splitlines():
        if line.startswith("=== CALL ") or META_RE.match(line):
            output.append(line)
        elif line.startswith("BOT:") or line.startswith("CLIENT:"):
            speaker, spoken = line.split(":", 1)
            output.append(f"{speaker}:{redact(spoken)}")
        else:
            output.append(redact(line))
    return "\n".join(output)


def scenario_from_step(step: str) -> str:
    if step.startswith("confirmation__"):
        parts = step.split("__")
        return parts[1] if len(parts) > 1 else "confirmation"
    return step.split("__", 1)[0] if "__" in step else "unknown"


def detect_language(text: str) -> str:
    lowered = text.lower()
    words = set(WORD_RE.findall(lowered))
    ru = 3 * len(RU_SPECIFIC_RE.findall(text)) + len(words & RU_WORDS)
    kz = 3 * len(KZ_SPECIFIC_RE.findall(text)) + len(words & KZ_WORDS)
    if ru >= 2 and kz >= 2:
        return "mixed"
    if kz >= 2 and kz > ru:
        return "kz"
    if ru >= 2 and ru > kz:
        return "ru"
    return "undetermined"


def iter_call_blocks(paths: list[Path]) -> Iterator[tuple[Path, list[str]]]:
    for path in paths:
        block: list[str] | None = None
        with path.open("r", encoding="utf-8-sig") as handle:
            for raw_line in handle:
                line = raw_line.rstrip("\r\n")
                if HEADER_RE.match(line):
                    if block is not None:
                        yield path, block
                    block = [line]
                elif block is not None:
                    block.append(line)
        if block is not None:
            yield path, block


def parse_call(path: Path, lines: list[str]) -> dict:
    header = HEADER_RE.match(lines[0])
    if not header:
        raise ValueError(f"Bad call header in {path}: {lines[0]!r}")
    call_index, start_time, call_id = header.groups()
    turns: list[dict] = []
    pending_meta: dict | None = None
    current: dict | None = None

    def flush() -> None:
        nonlocal current
        if current is not None:
            current["text"] = "\n".join(current.pop("parts")).strip()
            turns.append(current)
            current = None

    for line in lines[1:]:
        meta_match = META_RE.match(line)
        if meta_match:
            flush()
            time_text, dialog_step, intent = meta_match.groups()
            pending_meta = {
                "time": time_text,
                "dialog_step": dialog_step.strip(),
                "intent": intent.strip(),
            }
            continue
        if line.startswith("BOT:") or line.startswith("CLIENT:"):
            flush()
            speaker, text = line.split(":", 1)
            current = {
                **(pending_meta or {"time": None, "dialog_step": "unknown", "intent": "unknown"}),
                "speaker": speaker,
                "parts": [text.strip()],
            }
            pending_meta = None
        elif current is not None and line.strip():
            current["parts"].append(line.strip())
    flush()

    client_turns = [t for t in turns if t["speaker"] == "CLIENT"]
    bot_turns = [t for t in turns if t["speaker"] == "BOT"]
    content_turns = [t for t in client_turns if t["text"] and t["text"] != "<SILENCE>"]
    intents = [t["intent"] for t in client_turns]
    steps = [t["dialog_step"] for t in client_turns]
    scenarios = []
    for step in steps:
        scenario = scenario_from_step(step)
        if scenario not in NON_SERVICE_SCENARIOS and scenario not in scenarios:
            scenarios.append(scenario)

    substantive_intents = [
        t["intent"] for t in content_turns if t["intent"] not in NON_SUBSTANTIVE_INTENTS
    ]
    unknown_content_turns = sum(
        t["intent"] == "unknown" and len(WORD_RE.findall(t["text"])) >= 2
        for t in content_turns
    )
    silence_turns = sum(t["intent"] == "silence" or t["text"] == "<SILENCE>" for t in client_turns)
    operator_turns = sum(t["intent"] == "talk_to_operator" for t in client_turns)

    normalized_bots = [re.sub(r"\s+", " ", t["text"]).strip() for t in bot_turns if t["text"].strip()]
    repeated_bot_events = len(normalized_bots) - len(set(normalized_bots))
    max_bot_run = 0
    run = 0
    previous = None
    for text in normalized_bots:
        run = run + 1 if text == previous else 1
        max_bot_run = max(max_bot_run, run)
        previous = text

    max_step_run = 0
    run = 0
    previous = None
    for step in steps:
        run = run + 1 if step == previous else 1
        max_step_run = max(max_step_run, run)
        previous = step

    language_mismatches = []
    for index, turn in enumerate(turns[:-1]):
        if turn["speaker"] != "CLIENT" or turn["text"] == "<SILENCE>":
            continue
        next_bot = next((t for t in turns[index + 1:] if t["speaker"] == "BOT"), None)
        if next_bot is None:
            continue
        client_lang = detect_language(turn["text"])
        bot_lang = detect_language(next_bot["text"])
        if client_lang in {"ru", "kz"} and bot_lang in {"ru", "kz"} and client_lang != bot_lang:
            language_mismatches.append({
                "client_time": turn["time"], "client_lang": client_lang,
                "bot_lang": bot_lang, "step": turn["dialog_step"],
            })

    start_dt = dt.datetime.fromisoformat(start_time.strip())
    last_dt = start_dt
    if client_turns and client_turns[-1]["time"]:
        h, m, s = map(int, client_turns[-1]["time"].split(":"))
        last_dt = start_dt.replace(hour=h, minute=m, second=s)
        if last_dt < start_dt:
            last_dt += dt.timedelta(days=1)

    return {
        "call_id": call_id,
        "call_index": int(call_index),
        "call_start_time": start_time.strip(),
        "day": start_dt.date().isoformat(),
        "source_file": path.name,
        "client_turns": len(client_turns),
        "content_turns": len(content_turns),
        "bot_turns": len(bot_turns),
        "unknown_turns": sum(t["intent"] == "unknown" for t in client_turns),
        "unknown_content_turns": unknown_content_turns,
        "silence_turns": silence_turns,
        "operator_turns": operator_turns,
        "reask_turns": sum(t["dialog_step"].startswith("00_06_reask_before_operator") for t in client_turns),
        "language_ask": any(t["dialog_step"] == "00_00_continuity__language_ask" for t in turns),
        "repeated_bot_events": repeated_bot_events,
        "max_consecutive_same_bot": max_bot_run,
        "max_client_step_run": max_step_run,
        "language_mismatches": language_mismatches,
        "service_scenarios": scenarios,
        "first_service_scenario": scenarios[0] if scenarios else None,
        "substantive_intents": list(dict.fromkeys(substantive_intents)),
        "first_substantive_intent": substantive_intents[0] if substantive_intents else None,
        "first_client_intent": intents[0] if intents else None,
        "last_client_intent": intents[-1] if intents else None,
        "last_client_step": steps[-1] if steps else None,
        "last_turn_elapsed_seconds": max(0, int((last_dt - start_dt).total_seconds())),
        "turns": turns,
        "raw": "\n".join(lines),
    }


def slim(call: dict) -> dict:
    return {k: v for k, v in call.items() if k not in {"turns", "raw"}}


def aggregate(calls: list[dict]) -> dict:
    intent_counts = collections.Counter()
    substantive_intent_counts = collections.Counter()
    scenario_turn_counts = collections.Counter()
    day_stats: dict[str, collections.Counter] = collections.defaultdict(collections.Counter)
    feature_calls = collections.Counter()
    client_turns = 0
    content_turns = 0

    for call in calls:
        day = day_stats[call["day"]]
        day["calls"] += 1
        client_turns += call["client_turns"]
        content_turns += call["content_turns"]
        day["client_turns"] += call["client_turns"]
        day["unknown_turns"] += call["unknown_turns"]
        day["silence_turns"] += call["silence_turns"]
        # Reconstruct per-call intent counts from slim fields where possible is not
        # sufficient, so these counters are populated in main from full records.
        if call["content_turns"]:
            feature_calls["with_content"] += 1
        if call["unknown_content_turns"]:
            feature_calls["with_unknown_content"] += 1
        if call["unknown_content_turns"] >= 2:
            feature_calls["with_2plus_unknown_content"] += 1
        if call["silence_turns"]:
            feature_calls["with_silence"] += 1
        if call["silence_turns"] >= 2:
            feature_calls["with_2plus_silence"] += 1
        if call["operator_turns"]:
            feature_calls["with_operator_request"] += 1
        if call["reask_turns"]:
            feature_calls["with_operator_reask"] += 1
        if call["repeated_bot_events"]:
            feature_calls["with_repeated_bot_prompt"] += 1
        if call["max_consecutive_same_bot"] >= 2:
            feature_calls["with_consecutive_identical_bot_prompt"] += 1
        if call["language_mismatches"]:
            feature_calls["with_language_mismatch_heuristic"] += 1
        if call["service_scenarios"]:
            feature_calls["with_service_scenario"] += 1
        if len(call["service_scenarios"]) >= 2:
            feature_calls["with_multiple_service_scenarios"] += 1

    return {
        "scope": "All November 2026 transcript records; mechanical transcript metrics, not human quality judgments",
        "calls_total": len(calls),
        "client_turns_total": client_turns,
        "content_client_turns_total": content_turns,
        "feature_call_counts": dict(feature_calls),
        "feature_call_rates": {
            key: round(value / len(calls), 6) for key, value in feature_calls.items()
        },
        "daily": {
            key: {
                **dict(value),
                "unknown_share_of_client_turns": round(value["unknown_turns"] / value["client_turns"], 6)
                if value["client_turns"] else None,
            }
            for key, value in sorted(day_stats.items())
        },
        "intent_counts_placeholder": intent_counts,
        "substantive_intent_counts_placeholder": substantive_intent_counts,
        "scenario_turn_counts_placeholder": scenario_turn_counts,
    }


def choose_sample(calls: list[dict], size: int, seed: int) -> list[dict]:
    rng = random.Random(seed)
    eligible = [c for c in calls if c["content_turns"] > 0]
    selected: list[dict] = []
    selected_ids: set[str] = set()

    def take(candidates: list[dict], n: int, stratum: str, unique_service: bool = False) -> None:
        pool = [c for c in candidates if c["call_id"] not in selected_ids]
        rng.shuffle(pool)
        used_services = {c["first_service_scenario"] for c in selected}
        added = 0
        deferred = []
        for call in pool:
            if unique_service and call["first_service_scenario"] in used_services:
                deferred.append(call)
                continue
            item = slim(call)
            item["sample_stratum"] = stratum
            selected.append(item)
            selected_ids.add(call["call_id"])
            used_services.add(call["first_service_scenario"])
            added += 1
            if added == n:
                break
        if added < n:
            for call in deferred:
                item = slim(call)
                item["sample_stratum"] = stratum + "_secondary"
                selected.append(item)
                selected_ids.add(call["call_id"])
                added += 1
                if added == n:
                    break

    # A small probability sample provides an anchor; targeted strata deliberately
    # enrich failures and must never be used as prevalence estimates.
    take(eligible, 8, "random_baseline")

    service_counts = collections.Counter(
        c["first_service_scenario"] for c in eligible if c["first_service_scenario"]
    )
    common_services = {s for s, _ in service_counts.most_common(35)}
    take([
        c for c in eligible
        if c["first_service_scenario"] in common_services and c["client_turns"] >= 2
    ], 14, "service_journey", unique_service=True)

    take([
        c for c in eligible
        if c["unknown_content_turns"] >= 1 and not c["service_scenarios"]
    ], 8, "unknown_without_service")

    take([
        c for c in eligible
        if c["max_consecutive_same_bot"] >= 2 or c["max_client_step_run"] >= 4
    ], 6, "repetition_or_stuck")

    take([c for c in eligible if c["language_mismatches"]], 5, "language_mismatch_heuristic")

    take([
        c for c in eligible
        if len(c["service_scenarios"]) >= 2 or c["client_turns"] >= 8
    ], 5, "long_or_multi_topic")

    take([
        c for c in eligible
        if c["silence_turns"] >= 2 or (
            not c["service_scenarios"] and c["client_turns"] >= 2
            and c["last_client_intent"] in {"silence", "unknown"}
        )
    ], 4, "silence_or_unresolved")

    if len(selected) < size:
        take(eligible, size - len(selected), "random_fill")
    if len(selected) != size:
        raise RuntimeError(f"Requested {size} calls, selected {len(selected)}")

    stratum_order = {
        "random_baseline": 0, "service_journey": 1, "unknown_without_service": 2,
        "repetition_or_stuck": 3, "language_mismatch_heuristic": 4,
        "long_or_multi_topic": 5, "silence_or_unresolved": 6, "random_fill": 7,
    }
    selected.sort(key=lambda c: (stratum_order.get(c["sample_stratum"], 99), c["call_start_time"], c["call_id"]))
    for index, call in enumerate(selected, 1):
        call["sample_id"] = index
    return selected


def render_call(call: dict) -> str:
    features = (
        f"Stratum: {call['sample_stratum']} | client turns: {call['client_turns']} | "
        f"unknown-content turns: {call['unknown_content_turns']} | silence: {call['silence_turns']} | "
        f"repeated bot events: {call['repeated_bot_events']} | services: "
        f"{', '.join(call['service_scenarios']) or 'none'} | language mismatches: {len(call['language_mismatches'])}"
    )
    return (
        f"\n## SAMPLE {call['sample_id']} | CALL {call['call_index']} | "
        f"{call['call_start_time']} | {call['call_id']}\n\n{features}\n\n```text\n"
        f"{redact_transcript(call['raw'])}\n```\n"
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--calls-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--sample-size", type=int, default=50)
    parser.add_argument("--seed", type=int, default=20261118)
    args = parser.parse_args()

    paths = sorted(args.calls_dir.glob("*_dialog_chunks_intent_dialog_step_part_*.txt"))
    if not paths:
        raise FileNotFoundError(f"No transcript parts under {args.calls_dir}")
    args.output_dir.mkdir(parents=True, exist_ok=True)

    calls: list[dict] = []
    intent_counts = collections.Counter()
    substantive_intent_counts = collections.Counter()
    scenario_turn_counts = collections.Counter()
    state_stats: dict[str, collections.Counter] = collections.defaultdict(collections.Counter)
    first_content_intent_counts = collections.Counter()
    for path, block in iter_call_blocks(paths):
        call = parse_call(path, block)
        first_content_intent = None
        for turn in call["turns"]:
            if turn["speaker"] != "CLIENT":
                continue
            intent_counts[turn["intent"]] += 1
            if turn["text"] != "<SILENCE>" and first_content_intent is None:
                first_content_intent = turn["intent"]
            if turn["intent"] not in NON_SUBSTANTIVE_INTENTS and turn["text"] != "<SILENCE>":
                substantive_intent_counts[turn["intent"]] += 1
            scenario = scenario_from_step(turn["dialog_step"])
            scenario_turn_counts[scenario] += 1
            stats = state_stats[turn["dialog_step"]]
            stats["total"] += 1
            stats[f"intent::{turn['intent']}"] += 1
        if first_content_intent is not None:
            first_content_intent_counts[first_content_intent] += 1
        calls.append(slim(call))

    summary = aggregate(calls)
    summary.pop("intent_counts_placeholder")
    summary.pop("substantive_intent_counts_placeholder")
    summary.pop("scenario_turn_counts_placeholder")
    summary["client_intent_counts"] = dict(intent_counts.most_common())
    summary["substantive_client_intent_counts"] = dict(substantive_intent_counts.most_common())
    summary["client_scenario_turn_counts"] = dict(scenario_turn_counts.most_common())
    summary["top_client_intent_rates"] = {
        key: round(value / summary["client_turns_total"], 6)
        for key, value in intent_counts.most_common(30)
    }
    summary["first_content_intent_counts"] = dict(first_content_intent_counts.most_common())
    summary["client_state_stats"] = {
        step: {
            "total": stats["total"],
            "unknown": stats["intent::unknown"],
            "unknown_rate": round(stats["intent::unknown"] / stats["total"], 6),
            "silence": stats["intent::silence"],
            "talk_to_operator": stats["intent::talk_to_operator"],
            "top_intents": [
                [key.removeprefix("intent::"), value]
                for key, value in sorted(
                    ((k, v) for k, v in stats.items() if k.startswith("intent::")),
                    key=lambda item: (-item[1], item[0]),
                )[:8]
            ],
        }
        for step, stats in sorted(state_stats.items(), key=lambda item: (-item[1]["total"], item[0]))[:150]
    }

    selected = choose_sample(calls, args.sample_size, args.seed)
    selected_by_id = {c["call_id"]: c for c in selected}
    enriched: list[dict] = []
    for path, block in iter_call_blocks(paths):
        header = HEADER_RE.match(block[0])
        if header and header.group(3) in selected_by_id:
            full = parse_call(path, block)
            item = selected_by_id[full["call_id"]]
            item["raw"] = full["raw"]
            item["turns"] = full["turns"]
            enriched.append(item)
    if len(enriched) != len(selected):
        missing = set(selected_by_id) - {c["call_id"] for c in enriched}
        raise RuntimeError(f"Could not re-read selected calls: {sorted(missing)}")
    enriched.sort(key=lambda c: c["sample_id"])

    public_summary = json.loads(json.dumps(summary))
    (args.output_dir / "november_aggregate.json").write_text(
        json.dumps(public_summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    serializable = [
        {
            **c,
            "raw": redact_transcript(c["raw"]),
            "turns": [{**t, "text": redact(t["text"])} for t in c["turns"]],
        }
        for c in enriched
    ]
    (args.output_dir / "call_sample_50.json").write_text(
        json.dumps(serializable, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    header = (
        "# November 2026 call sample\n\n"
        f"Deterministic seed: {args.seed}. {args.sample_size} calls: 8 random baseline plus "
        "targeted service, unknown, repetition, language, multi-topic, and unresolved strata. "
        "This is an evaluation/discovery sample, not a representative prevalence sample. "
        "Long digit sequences are redacted in this derived file only.\n"
    )
    document = header + "".join(render_call(c) for c in enriched)
    (args.output_dir / "call_sample_50.md").write_text(document, encoding="utf-8")
    midpoint = (len(enriched) + 1) // 2
    for part, subset in ((1, enriched[:midpoint]), (2, enriched[midpoint:])):
        part_doc = header + "".join(render_call(c) for c in subset)
        (args.output_dir / f"call_sample_part_{part}.md").write_text(part_doc, encoding="utf-8")

    print(json.dumps({
        "calls_scanned": len(calls),
        "calls_sampled": len(enriched),
        "client_turns": summary["client_turns_total"],
        "output_dir": str(args.output_dir),
        "strata": dict(collections.Counter(c["sample_stratum"] for c in enriched)),
        "feature_call_counts": summary["feature_call_counts"],
        "top_intents": intent_counts.most_common(15),
        "top_service_scenarios": [(k, v) for k, v in scenario_turn_counts.most_common(25) if k not in NON_SERVICE_SCENARIOS][:15],
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
