#!/usr/bin/env python3
"""Dry-run-first OpenRouter Decisions pilot for redacted Verigram calls.

Default behavior performs NO network requests and writes one payload preview.
External inference requires both --send-data and OPENROUTER_API_KEY. Use only
after bank approval and verification of endpoint data policies.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import json
import os
import time
from pathlib import Path
from typing import Any

import requests

ENDPOINT = "https://openrouter.ai/api/alpha/decisions"
DEFAULT_MODELS = ["typesafe/jev-1.14", "google/gemini-decision-1", "cloudflare/clef"]
TRANSCRIPT_KEYS = {
    "sample_id", "sample_stratum", "call_index", "call_start_time", "day",
    "client_turns", "unknown_turns", "unknown_content_turns", "silence_turns",
    "operator_turns", "reask_turns", "repeated_bot_events", "service_scenarios",
    "first_substantive_intent", "last_client_intent", "last_client_step",
}


def transcript_without_header(raw: str) -> str:
    """Remove the UUID-bearing call header; keep turn evidence and timestamps."""
    lines = raw.splitlines()
    return "\n".join(lines[1:] if lines and lines[0].startswith("=== CALL ") else lines).strip()


def build_payload(call: dict, model: str, questions: dict, allow_non_zdr: bool = False) -> dict:
    state = {key: call[key] for key in TRANSCRIPT_KEYS if key in call}
    state["transcript"] = transcript_without_header(call["raw"])
    return {
        "model": model,
        "state": state,
        "questions": questions,
        # Never silently route to a fallback provider. Training remains denied;
        # --allow-non-zdr only relaxes the strict zero-retention requirement.
        "provider": {
            "allow_fallbacks": False,
            "data_collection": "deny",
            "zdr": not allow_non_zdr,
        },
    }


def completed_keys(path: Path) -> set[tuple[str, int]]:
    completed = set()
    if not path.exists():
        return completed
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            try:
                row = json.loads(line)
                if row.get("ok"):
                    completed.add((row["model"], int(row["sample_id"])))
            except (json.JSONDecodeError, KeyError, TypeError, ValueError):
                continue
    return completed


def infer_one(call: dict, model: str, questions: dict, api_key: str, timeout: int, allow_non_zdr: bool) -> dict:
    payload = build_payload(call, model, questions, allow_non_zdr)
    started = time.monotonic()
    last_error: Exception | None = None
    for attempt in range(5):
        try:
            response = requests.post(
                ENDPOINT,
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json",
                },
                json=payload,
                timeout=timeout,
            )
            if response.status_code == 429 or response.status_code >= 500:
                retry_after = response.headers.get("Retry-After")
                delay = float(retry_after) if retry_after and retry_after.isdigit() else min(20, 2 ** attempt)
                if attempt == 4:
                    raise RuntimeError(f"HTTP {response.status_code}: {response.text[:1000]}")
                time.sleep(delay)
                continue
            if not response.ok:
                # Do not retry policy/capability failures or disable privacy controls.
                raise RuntimeError(f"HTTP {response.status_code}: {response.text[:1000]}")
            body: dict[str, Any] = response.json()
            answers = body.get("answers")
            if not isinstance(answers, dict):
                raise RuntimeError("Response has no answers object")
            missing = sorted(set(questions) - set(answers))
            if missing:
                raise RuntimeError(f"Response is missing answers: {missing}")
            return {
                "ok": True,
                "sample_id": call["sample_id"],
                "call_id": call["call_id"],
                "model": model,
                "elapsed_seconds": round(time.monotonic() - started, 3),
                "response": body,
            }
        except (requests.RequestException, ValueError, RuntimeError) as exc:
            last_error = exc
            # A deterministic 4xx or schema error should not be retried. The HTTP
            # retry path above handles transient statuses before reaching here.
            if isinstance(exc, RuntimeError) or attempt == 4:
                break
            time.sleep(min(20, 2 ** attempt))
    return {
        "ok": False,
        "sample_id": call["sample_id"],
        "call_id": call["call_id"],
        "model": model,
        "elapsed_seconds": round(time.monotonic() - started, 3),
        "error": str(last_error),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, default=Path("analysis/call_sample_50.json"))
    parser.add_argument("--questions", type=Path, default=Path("decision_questions.json"))
    parser.add_argument("--output", type=Path, default=Path("analysis/decision_results.jsonl"))
    parser.add_argument("--preview", type=Path, default=Path("analysis/pilot_payload_preview.json"))
    parser.add_argument("--models", nargs="+", default=DEFAULT_MODELS)
    parser.add_argument("--limit", type=int, default=1)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--timeout", type=int, default=90)
    parser.add_argument("--send-data", action="store_true", help="Send redacted transcripts to OpenRouter after organizational approval")
    parser.add_argument("--allow-non-zdr", action="store_true", help="Allow endpoints that do not meet strict ZDR; training collection remains denied")
    args = parser.parse_args()

    calls = json.loads(args.input.read_text(encoding="utf-8"))
    questions = json.loads(args.questions.read_text(encoding="utf-8"))
    selected = calls[: max(0, args.limit)] if args.limit else calls
    if not selected:
        raise ValueError("No calls selected")

    args.preview.parent.mkdir(parents=True, exist_ok=True)
    preview = {
        "warning": "Preview only. Review data minimization and endpoint policy before external use.",
        "payload": build_payload(selected[0], args.models[0], questions, args.allow_non_zdr),
    }
    args.preview.write_text(json.dumps(preview, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Wrote payload preview: {args.preview}")

    if not args.send_data:
        print("Dry run only: no network inference requested. Re-run with --send-data only after approval.")
        return

    api_key = os.environ.get("OPENROUTER_API_KEY")
    if not api_key:
        raise RuntimeError("OPENROUTER_API_KEY is required with --send-data")

    args.output.parent.mkdir(parents=True, exist_ok=True)
    done = completed_keys(args.output)
    jobs = [
        (call, model)
        for call in selected
        for model in args.models
        if (model, int(call["sample_id"])) not in done
    ]
    print(f"Submitting {len(jobs)} inference requests; results: {args.output}")
    with args.output.open("a", encoding="utf-8") as handle:
        with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
            futures = [
                pool.submit(infer_one, call, model, questions, api_key, args.timeout, args.allow_non_zdr)
                for call, model in jobs
            ]
            for future in concurrent.futures.as_completed(futures):
                result = future.result()
                handle.write(json.dumps(result, ensure_ascii=False) + "\n")
                handle.flush()
                print(
                    f"sample={result['sample_id']} model={result['model']} "
                    f"ok={result['ok']} elapsed={result['elapsed_seconds']}s"
                )


if __name__ == "__main__":
    main()
