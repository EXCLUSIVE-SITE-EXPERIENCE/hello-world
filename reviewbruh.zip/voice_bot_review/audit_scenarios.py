#!/usr/bin/env python3
"""Read-only structural and coverage audit of Verigram production YAML scenarios."""

from __future__ import annotations

import argparse
import ast
import collections
import csv
import json
import re
from pathlib import Path
from typing import Any, Iterator

import yaml

INTENT_RE = re.compile(r"\bintent\s*==\s*[\"']([^\"']+)[\"']")
CROSS_RE = re.compile(r"^>>([^|]+)(?:\|(.*))?$")
TRUE_TRUE_RE = re.compile(r"^True\s*==\s*True$")
RUNTIME_INTENTS = {"unknown", "silence", "hangup"}


class UniqueKeyLoader(yaml.SafeLoader):
    pass


def construct_unique_mapping(loader: UniqueKeyLoader, node: yaml.Node, deep: bool = False) -> dict:
    mapping = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node, deep=deep)
        if key in mapping:
            raise ValueError(f"Duplicate YAML key {key!r} at line {key_node.start_mark.line + 1}")
        mapping[key] = loader.construct_object(value_node, deep=deep)
    return mapping


UniqueKeyLoader.add_constructor(
    yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, construct_unique_mapping
)


def flatten(items: Any) -> Iterator[Any]:
    if isinstance(items, list):
        for item in items:
            yield from flatten(item)
    else:
        yield items


def transitions(state: dict) -> list[dict]:
    return [t for t in flatten(state.get("transitions", [])) if isinstance(t, dict)]


def intents_in_condition(condition: Any) -> set[str]:
    return set(INTENT_RE.findall(str(condition)))


def split_target(target: str) -> tuple[str, str] | None:
    match = CROSS_RE.match(target)
    if not match:
        return None
    scenario, state = match.groups()
    return scenario, state or "start"


def issue(issue_type: str, severity: str, confidence: str, evidence: str,
          recommendation: str, file: str = "", state: str = "", target: str = "") -> dict:
    return {
        "issue_type": issue_type,
        "severity": severity,
        "confidence": confidence,
        "file": file,
        "state": state,
        "target": target,
        "evidence": evidence,
        "recommendation": recommendation,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--scenarios-dir", type=Path, required=True)
    parser.add_argument("--intent-config", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    config = json.loads(args.intent_config.read_text(encoding="utf-8"))
    model_intents = set(config["intent_names"])
    scenarios: dict[str, dict] = {}
    issues: list[dict] = []
    scenario_stats: list[dict] = []
    all_yaml_intents: dict[str, set[str]] = collections.defaultdict(set)
    cross_transition_count = 0
    intent_mention_count = 0
    scenario_intent_pair_count = 0

    for path in sorted(args.scenarios_dir.glob("*.yaml")):
        try:
            data = yaml.load(path.read_text(encoding="utf-8"), Loader=UniqueKeyLoader)
        except Exception as exc:
            issues.append(issue(
                "yaml_parse_error", "critical", "high", str(exc),
                "Fix the YAML syntax/duplicate key and reload in a test container.", path.name
            ))
            continue
        if not isinstance(data, dict) or "scenario_id" not in data:
            continue
        scenario_id = data["scenario_id"]
        states = data.get("states")
        if not isinstance(states, dict) or not states:
            issues.append(issue(
                "missing_states", "critical", "high", "Scenario has no states object.",
                "Define at least one valid state.", path.name
            ))
            continue
        if scenario_id in scenarios:
            issues.append(issue(
                "duplicate_scenario_id", "critical", "high",
                f"Duplicate scenario_id also in {scenarios[scenario_id]['path'].name}",
                "Give every scenario a unique ID.", path.name
            ))
            continue
        if scenario_id != path.stem:
            issues.append(issue(
                "scenario_filename_mismatch", "medium", "high",
                f"scenario_id={scenario_id!r}, filename={path.stem!r}",
                "Align scenario_id and filename to prevent routing mistakes.", path.name
            ))
        scenarios[scenario_id] = {"path": path, "data": data, "states": states}

    for scenario_id, scenario in scenarios.items():
        path = scenario["path"]
        states = scenario["states"]
        scenario_intents: set[str] = set()
        for state_name, state in states.items():
            if not isinstance(state, dict):
                issues.append(issue(
                    "invalid_state", "critical", "high", f"State is {type(state).__name__}, not an object.",
                    "Make every state a mapping.", path.name, state_name
                ))
                continue
            state_transitions = transitions(state)
            if not state_transitions and not state.get("final"):
                issues.append(issue(
                    "nonfinal_state_without_transitions", "high", "medium",
                    "A non-final state has no transitions; callback-driven behavior cannot be ruled out from YAML alone.",
                    "Add an explicit exit/fallback or document the runtime mechanism that exits this state.",
                    path.name, state_name
                ))
            seen_conditions: set[str] = set()
            unconditional_seen = False
            for position, transition in enumerate(state_transitions, 1):
                condition_raw = transition.get("condition", "")
                condition = str(condition_raw).strip()
                target_raw = transition.get("next_state")
                target = str(target_raw).strip() if target_raw is not None else ""
                mentioned = intents_in_condition(condition)
                intent_mention_count += len(mentioned)
                scenario_intents.update(mentioned)
                for intent in mentioned:
                    all_yaml_intents[intent].add(scenario_id)
                if unconditional_seen:
                    issues.append(issue(
                        "transition_after_unconditional", "high", "high",
                        f"Transition {position} follows an earlier True == True transition, so it is unreachable in ordered evaluation.",
                        "Move specific transitions before the unconditional fallback or remove dead rules.",
                        path.name, state_name, target
                    ))
                normalized_condition = re.sub(r"\s+", " ", condition)
                if normalized_condition in seen_conditions:
                    issues.append(issue(
                        "duplicate_transition_condition", "medium", "high",
                        f"Condition {normalized_condition!r} is repeated in the same state; only the first can match.",
                        "Remove or differentiate duplicate ordered conditions.", path.name, state_name, target
                    ))
                seen_conditions.add(normalized_condition)
                if TRUE_TRUE_RE.match(normalized_condition):
                    unconditional_seen = True
                if condition and not TRUE_TRUE_RE.match(normalized_condition):
                    try:
                        ast.parse(condition, mode="eval")
                    except SyntaxError as exc:
                        issues.append(issue(
                            "invalid_condition_syntax", "critical", "high", str(exc),
                            "Fix the condition using the engine's supported expression grammar.",
                            path.name, state_name, target
                        ))
                if not target:
                    issues.append(issue(
                        "missing_next_state", "critical", "high",
                        f"Transition with condition {condition!r} has no next_state.",
                        "Add an explicit target.", path.name, state_name
                    ))
                    continue
                cross = split_target(target)
                if cross:
                    cross_transition_count += 1
                elif target != "<<" and target not in states:
                    issues.append(issue(
                        "missing_local_state", "critical", "high",
                        f"Local target {target!r} is absent from {scenario_id}.",
                        "Add the target state or correct next_state.", path.name, state_name, target
                    ))

        scenario_intent_pair_count += len(scenario_intents)
        scenario_stats.append({
            "scenario_id": scenario_id,
            "file": path.name,
            "state_count": len(states),
            "transition_count": sum(len(transitions(s)) for s in states.values() if isinstance(s, dict)),
            "intent_count": len(scenario_intents),
            "intents": sorted(scenario_intents),
            "has_start": "start" in states,
            "final_states": [name for name, state in states.items() if isinstance(state, dict) and state.get("final")],
            "has_explicit_yaml_repeat_handler": any(
                "repeat" in intents_in_condition(t.get("condition", ""))
                for state in states.values() if isinstance(state, dict) for t in transitions(state)
            ),
            "has_agree_handler": any(
                "agree" in intents_in_condition(t.get("condition", ""))
                for state in states.values() if isinstance(state, dict) for t in transitions(state)
            ),
            "has_disagree_handler": any(
                "disagree" in intents_in_condition(t.get("condition", ""))
                for state in states.values() if isinstance(state, dict) for t in transitions(state)
            ),
            "operator_states": [
                name for name, state in states.items()
                if isinstance(state, dict) and ("operator_phones" in state or "operator" in name)
            ],
        })

    # In >>target|resume_state, target enters at its own start, while
    # resume_state belongs to the CURRENT/source scenario (engine.py and
    # managers.py). Validate the two sides separately.
    incoming_states: dict[str, set[str]] = collections.defaultdict(set)
    main_routes: list[dict] = []
    for scenario_id, scenario in scenarios.items():
        for state_name, state in scenario["states"].items():
            if not isinstance(state, dict):
                continue
            for transition in transitions(state):
                target = str(transition.get("next_state", "")).strip()
                cross = split_target(target)
                if not cross:
                    continue
                target_scenario, resume_state = cross
                incoming_states[target_scenario].add("start")
                incoming_states[scenario_id].add(resume_state)
                condition = str(transition.get("condition", ""))
                route = {
                    "source_scenario": scenario_id,
                    "source_state": state_name,
                    "condition": condition,
                    "intents": sorted(intents_in_condition(condition)),
                    "target_scenario": target_scenario,
                    "target_state": resume_state,
                }
                if scenario_id == "00_00_continuity" and state_name == "main":
                    main_routes.append(route)
                if target_scenario not in scenarios:
                    issues.append(issue(
                        "missing_cross_scenario", "critical", "high",
                        f"Target scenario {target_scenario!r} has no loaded YAML file.",
                        "Add the scenario or correct the route.", scenario["path"].name, state_name, target
                    ))
                elif "start" not in scenarios[target_scenario]["states"]:
                    issues.append(issue(
                        "missing_target_start_state", "critical", "high",
                        f"Target scenario {target_scenario!r} has no start state; cross-scenario entry uses start.",
                        "Add a start state to the target scenario.", scenario["path"].name, state_name, target
                    ))
                if resume_state not in scenario["states"]:
                    issues.append(issue(
                        "missing_source_resume_state", "critical", "high",
                        f"Resume state {resume_state!r} is absent from source scenario {scenario_id}. "
                        "The engine applies it to the calling scenario before pushing the target.",
                        "Add the resume state to the source scenario or correct the route.",
                        scenario["path"].name, state_name, target
                    ))

    # Detect informational entry intents that simply re-enter the same state. This
    # is valid for repeat but often wrong for a new followup classified the same way.
    for route in main_routes:
        target_scenario = route["target_scenario"]
        target_state = route["target_state"]
        if target_scenario not in scenarios:
            continue
        states = scenarios[target_scenario]["states"]
        # Also inspect start because logs suggest the runtime may fall back to it
        # when the explicitly named state is missing.
        candidate_states = [target_state] if target_state in states else []
        if "start" in states and "start" not in candidate_states:
            candidate_states.append("start")
        for candidate in candidate_states:
            state = states[candidate]
            for transition in transitions(state):
                local_target = str(transition.get("next_state", "")).strip()
                repeated_intents = sorted(set(route["intents"]) & intents_in_condition(transition.get("condition", "")))
                if repeated_intents and local_target == candidate:
                    issues.append(issue(
                        "entry_intent_self_repeat", "medium", "medium",
                        f"Main intent(s) {repeated_intents} enter {target_scenario}__{candidate}; "
                        "the same intent loops to that state. A followup classified like the entry request repeats the generic answer. "
                        f"The caller-side resume state is {target_state!r}; target entry is start.",
                        "Separate initial-answer, repeat, and followup states; add expected answer-type intents and "
                        "an escape/operator path. Validate against real followups.",
                        scenarios[target_scenario]["path"].name, candidate, local_target
                    ))

    for intent in sorted(model_intents - set(all_yaml_intents)):
        issues.append(issue(
            "model_label_not_referenced", "low", "high",
            f"Model label {intent!r} is absent from every positive YAML intent == condition.",
            "Confirm whether it is intentionally unused/special and wire a route if desired. The supplied NLU "
            "uses state/main candidate subsets, so an unreferenced label does not directly compete there. "
            "Do not alter config indices independently of the trained model.", "", "", intent
        ))
    for intent in sorted(set(all_yaml_intents) - model_intents - RUNTIME_INTENTS):
        issues.append(issue(
            "yaml_intent_absent_from_model", "medium", "high",
            f"YAML references {intent!r} in {', '.join(sorted(all_yaml_intents[intent]))}, "
            "but the deployed config has no such class. Other disjuncts may keep the transition reachable.",
            "Test an existing semantically appropriate label (for other_bank, evaluate other_bank_general) "
            "or deliberately add/train a distinct class. Change only the unsupported disjunct.",
            "", "", intent
        ))

    # Local reachability is informative only: cross-scenario entry states and
    # callback/special-manager entry points are not fully represented in YAML.
    for stats in scenario_stats:
        scenario_id = stats["scenario_id"]
        states = scenarios[scenario_id]["states"]
        roots = ({"start"} if "start" in states else set()) | incoming_states.get(scenario_id, set())
        reachable = set(roots)
        changed = True
        while changed:
            changed = False
            for name in list(reachable):
                state = states.get(name)
                if not isinstance(state, dict):
                    continue
                for transition in transitions(state):
                    target = str(transition.get("next_state", "")).strip()
                    if target in states and target not in reachable:
                        reachable.add(target)
                        changed = True
        stats["locally_reachable_states"] = sorted(reachable)
        stats["locally_unreachable_states_review"] = sorted(set(states) - reachable)

    issues.sort(key=lambda x: (
        {"critical": 0, "high": 1, "medium": 2, "low": 3}.get(x["severity"], 9),
        x["issue_type"], x["file"], x["state"], x["target"],
    ))
    issue_counts = collections.Counter(x["issue_type"] for x in issues)
    summary = {
        "scenario_count": len(scenarios),
        "model_intent_count": len(model_intents),
        "yaml_intent_count": len(all_yaml_intents),
        "cross_scenario_transition_count": cross_transition_count,
        "transition_intent_mention_count": intent_mention_count,
        "scenario_intent_pair_count": scenario_intent_pair_count,
        "runtime_intents_referenced": sorted(set(all_yaml_intents) & RUNTIME_INTENTS),
        "main_route_count": len(main_routes),
        "issue_count": len(issues),
        "issue_counts": dict(sorted(issue_counts.items())),
        "severity_counts": dict(collections.Counter(x["severity"] for x in issues)),
        "thin_scenarios_1_to_3_states": [x["scenario_id"] for x in scenario_stats if x["state_count"] <= 3],
        "scenarios_without_explicit_yaml_repeat_handler": [x["scenario_id"] for x in scenario_stats if not x["has_explicit_yaml_repeat_handler"]],
        "notes": [
            "Structural target errors are deterministic from the supplied snapshot.",
            "Self-repeat and locally-unreachable findings require runtime/business review; they are not automatically defects.",
            "The repeat-handler list covers explicit YAML conditions only; the supplied loader can inject repeat handling at runtime.",
            "Nested transition lists are supported by the supplied loader and are not malformed YAML.",
            "Callback registry and special runtime managers were not supplied, so callback-driven routes cannot be fully validated.",
            "The production snapshot is dated 2026-11-06; it may differ from the scenario version loaded for every November call.",
        ],
    }
    (args.output_dir / "yaml_audit_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (args.output_dir / "yaml_audit_issues.json").write_text(
        json.dumps(issues, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (args.output_dir / "yaml_scenario_stats.json").write_text(
        json.dumps(scenario_stats, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    with (args.output_dir / "yaml_scenario_stats.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        fields = [
            "scenario_id", "file", "state_count", "transition_count", "intent_count",
            "has_start", "has_explicit_yaml_repeat_handler", "has_agree_handler", "has_disagree_handler",
            "final_states", "operator_states", "locally_unreachable_states_review", "intents",
        ]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for stats in scenario_stats:
            writer.writerow({key: ";".join(value) if isinstance(value, list) else value for key, value in ((f, stats[f]) for f in fields)})
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
