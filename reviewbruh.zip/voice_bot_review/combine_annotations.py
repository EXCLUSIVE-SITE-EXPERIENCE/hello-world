#!/usr/bin/env python3
"""Validate and combine the two independently reviewed 25-call annotation sets."""

from __future__ import annotations

import collections
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent / "analysis"
OUTCOMES = {"resolved", "partially_resolved", "transferred", "abandoned", "unresolved", "unclear"}
TAGS = {
    "none", "nlu_miss", "nlu_wrong_intent", "scenario_missing",
    "scenario_state_coverage", "scenario_logic", "language_mismatch",
    "asr_suspected", "prompt_ux", "operator_friction", "state_context", "no_progress",
}


def main() -> None:
    annotations = []
    for name in ("call_annotations_01_25.json", "call_annotations_26_50.json"):
        annotations.extend(json.loads((ROOT / name).read_text(encoding="utf-8")))
    sample = json.loads((ROOT / "call_sample_50.json").read_text(encoding="utf-8"))
    source = {call["sample_id"]: call for call in sample}

    assert len(annotations) == 50
    assert {row["sample_id"] for row in annotations} == set(range(1, 51))
    for row in annotations:
        original = source[row["sample_id"]]
        assert row["call_index"] == original["call_index"]
        assert row["call_id"] == original["call_id"]
        assert row["outcome"] in OUTCOMES
        assert row["severity"] in {"high", "medium", "low", "none"}
        assert row["confidence"] in {"high", "medium", "low"}
        assert set(row["failure_tags"]) <= TAGS
        assert not ("none" in row["failure_tags"] and len(row["failure_tags"]) > 1)
        for field in ("caller_goal", "evidence", "recommendation"):
            assert isinstance(row[field], str) and row[field].strip()
    annotations.sort(key=lambda row: row["sample_id"])

    tag_counts = collections.Counter(tag for row in annotations for tag in row["failure_tags"])
    nlu = {"nlu_miss", "nlu_wrong_intent"}
    scenario = {"scenario_missing", "scenario_state_coverage", "scenario_logic", "state_context"}
    summary = {
        "scope": "Qualitative review of the enriched 50-call discovery sample; not production prevalence estimates",
        "calls": len(annotations),
        "outcomes": dict(collections.Counter(row["outcome"] for row in annotations)),
        "severity": dict(collections.Counter(row["severity"] for row in annotations)),
        "confidence": dict(collections.Counter(row["confidence"] for row in annotations)),
        "failure_tags": dict(tag_counts.most_common()),
        "with_nlu_miss_or_wrong_intent": sum(bool(nlu & set(row["failure_tags"])) for row in annotations),
        "with_scenario_or_state_issue": sum(bool(scenario & set(row["failure_tags"])) for row in annotations),
        "with_both_nlu_and_scenario_issue": sum(
            bool(nlu & set(row["failure_tags"])) and bool(scenario & set(row["failure_tags"]))
            for row in annotations
        ),
        "sample_ids_by_tag": {
            tag: [row["sample_id"] for row in annotations if tag in row["failure_tags"]]
            for tag in sorted(TAGS)
        },
        "notes": [
            "AI-assisted qualitative annotations, not human-adjudicated gold labels; validate before retraining or accuracy reporting.",
            "Transferred means a handoff was announced, not that the banking task was resolved.",
            "asr_suspected is based on garbled text only and is not a proven acoustic/ASR diagnosis.",
            "The sample was enriched for failures and must not be used to estimate production rates.",
        ],
    }
    (ROOT / "call_annotations_50.json").write_text(
        json.dumps(annotations, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (ROOT / "call_review_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
